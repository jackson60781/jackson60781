<?php include_once "vendor/config/config.php"; 
function GetIP()
{
    foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $key)
    {
        if (array_key_exists($key, $_SERVER) === true)
        {
            foreach (array_map('trim', explode(',', $_SERVER[$key])) as $ip)
            {
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false)
                {
                    return $ip;
                }
            }
        }
    }
}
$conn->query("INSERT INTO requests (user, ip, request) VALUES ('".$_SESSION['username']."', '".GetIP()."', '".$_SERVER['REQUEST_URI']."')");
$conn->query("DELETE FROM requests WHERE `time` < (NOW() - INTERVAL 10 MINUTE)");
$loggedin = false;
if (isset($_POST['username'])) {
	$username = strip_tags(htmlentities(urldecode($_POST['username'])));
	$req = file_get_contents("https://api.roblox.com/users/get-by-username?username=".$username);
	if ($req != '{"success":false,"errorMessage":"User not found"}') {
		$aaa = json_decode($req, true);
		$result = $conn->query("SELECT * FROM users WHERE `uid`=".$aaa['Id']);
		if ($result->num_rows == 0) {
			$b = strtolower($username);
			if (!isset($_COOKIE['ref'])) {
				$conn->query("INSERT INTO users (uid, username, ip, bounty_streak) VALUES ('".$aaa['Id']."', '$b', '".GetIP()."', '1')");
			} else {
				$conn->query("INSERT INTO users (uid, username, ip, bounty_streak, ref) VALUES ('".$aaa['Id']."', '$b', '".GetIP()."', '1', '".$_COOKIE['ref']."')");
			}
			$_SESSION['username'] = $username;
			$usr['id'] = $conn->insert_id;
			$usr['uid'] = $aaa['Id'];
			$usr['username'] = strtolower($username);
			$usr['balance'] = 0;
			$usr['last_logged'] = date('Y-m-d H:i:s');
			$usr['ip'] = GetIP();
			$usr['bounty_logged'] = date('Y-m-d H:i:s');
			$usr['bounty_streak'] = 1;
			$_SESSION['usr'] = $usr;
			$loggedin= true;
			$new = true;
		} else {
			while($row = $result->fetch_assoc()) {
				$_SESSION['username'] = $username;
				$_SESSION['usr'] = $row;
				$loggedin = true;
				mysqli_query($conn,"UPDATE `users` SET `last_logged`='".date('Y-m-d H:i:s')."' WHERE `id`=".$row['id']);
			}
		}
	}
}

if(isset($_SESSION['usr']['id'])){
    $data = mysqli_fetch_row(mysqli_query($conn,"SELECT * FROM `users` WHERE `id`=".$_SESSION['usr']['id']));
    $datenow = date_create(date('Y-m-d H:i:s'));
    $datethen = date_create($data[6]);
    $timebetween = date_diff($datenow,$datethen);
    $days = $timebetween->format('%d');
    if($days >= "1" && $days <= ($daystoexpire+1)){
		$newbounty = $_SESSION['usr']['bounty_streak']+1;
        mysqli_query($conn,"UPDATE `users` SET `bounty_streak`=$newbounty,`bounty_logged`='".date('Y-m-d H:i:s')."' WHERE `id`=".$_SESSION['usr']['id']);
		$_SESSION['usr']['bounty_streak'] = $_SESSION['usr']['bounty_streak']+1;
		$bountycode = 1;
    } elseif ($days > $daystoexpire) {
        mysqli_query($conn,"UPDATE `users` SET `bounty_streak`=1,`bounty_logged`='".date('Y-m-d H:i:s')."' WHERE `id`=".$_SESSION['usr']['id']);
		$_SESSION['usr']['bounty_streak'] = 1;
		$bountycode = 2;
    }
    if($_SESSION['usr']['bounty_streak'] >= $bountydays){
		mysqli_query($conn,"UPDATE `users` SET `bounty_streak`=1,`bounty_logged`='".date('Y-m-d H:i:s')."' WHERE `id`=".$_SESSION['usr']['id']);
		$newbal = $_SESSION['usr']['balance']+$bountypayout;
		mysqli_query($conn,"UPDATE `users` SET `balance`=$newbal WHERE `id`=".$_SESSION['usr']['id']);
		$_SESSION['usr']['bounty_streak'] = 1;
		$bountycode = 3;
    }
}

if (isset($_GET['ref'])) {
	setcookie("ref",$_GET['ref'],time()+31556926 ,'/');
	header("Location: index.php");
}
/*foreach($groupids as $id){
    $GroupURL = "http://www.roblox.com/groups/group.aspx?gid=" . $id;
    $GroupPage = file_get_contents($GroupURL);
    $Start = strpos($GroupPage,'<span class="text-robux-lg ng-binding" ng-bind="currencyInRobux | abbreviate">');
    $End = strpos(substr($GroupPage,$Start),"</span>");
    $robux = substr($GroupPage,$Start,$End);
    $robux = str_replace(',','',$robux);
    $availablefunds+=$robux;
}*/
?>
<!DOCTYPE html>
<html lang="en">

<head>


  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>RBLXCity | Free Robux | Instant Payouts</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/notyf.min.css" rel="stylesheet">
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
  
  <!-- Extra scripts -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

      <!-- FACEBOOK META -->
      <meta name="language" content="EN">
      <meta name="keywords" content="roblox robux blox cards giftcard giftcards">
      <meta property="og:type" content="website">
      <meta property="og:url" content="https://rbx.world/">
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
      <meta property="og:title" content="RBX.WORLD">
      <meta property="og:image" content="/img/android-icon-192x192.jpg">
      <meta property="og:site_name" content="RBX.WORLD">
      <meta property="og:description" content="Complete quick surveys to cash out R$ today!">
      <!-- END OF FACEBOOK META -->

<link rel="icon" type="image/png" href="/img/android-icon-192x192.jpg">


</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

<?php include_once "vendor/sidebar.php"; ?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Alerts -->
            <li class="nav-item dropdown no-arrow mx-1">
              <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-bell fa-fw"></i>
                <!-- Counter - Alerts -->
                <span class="badge badge-danger badge-counter">0</span>
              </a>
              <!-- Dropdown - Alerts -->
              <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="alertsDropdown">
                <h6 class="dropdown-header">
                  Alerts Center
                </h6>
                <!--<a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="mr-3">
                    <div class="icon-circle bg-primary">
                      <i class="fas fa-file-alt text-white"></i>
                    </div>
                  </div>
                  <div>
                    <div class="small text-gray-500">December 12, 2019</div>
                    <span class="font-weight-bold">A new monthly report is ready to download!</span>
                  </div>
                </a>-->
                <a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
              </div>
            </li>

            <!-- Nav Item - Messages -->
            <li class="nav-item dropdown no-arrow mx-1">
              <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-envelope fa-fw"></i>
                <!-- Counter - Messages -->
                <span class="badge badge-danger badge-counter">0</span>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="messagesDropdown">
                <h6 class="dropdown-header">
                  Updates Center
                </h6>
                <!--<a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="dropdown-list-image mr-3">
                    <img class="rounded-circle" src="https://source.unsplash.com/fn_BT9fwg_E/60x60" alt="">
                    <div class="status-indicator bg-success"></div>
                  </div>
                  <div class="font-weight-bold">
                    <div class="text-truncate">Hi there! I am wondering if you can help me with a problem I've been having.</div>
                    <div class="small text-gray-500">Emily Fowler · 58m</div>
                  </div>
                </a>-->
                <a class="dropdown-item text-center small text-gray-500" href="#">Read More Messages</a>
              </div>
            </li>

            <div class="topbar-divider d-none d-sm-block"></div>
            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php if (!isset($_SESSION['username'])) { echo "Guest"; } else { echo $_SESSION['username']; } ?></span>
                <img class="img-profile rounded-circle" src="<?php if (!isset($_SESSION['usr']['uid'])) { echo "https://www.roblox.com/headshot-thumbnail/image?userId=1&width=60&height=60&format=png"; } else { echo "https://www.roblox.com/headshot-thumbnail/image?userId=".$_SESSION['usr']['uid']."&width=60&height=60&format=png"; } ?>">
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="#">
                  <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                  Request a withdraw
                </a>
                <a class="dropdown-item" href="#">
                  <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                  Activity Log
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#modal" onclick="logoutmodal();">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- rbxworld -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-1198743441435740"
     data-ad-slot="5496294790"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Content Row -->
          <div class="row">

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Your earnings</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800" id="earn">0 R$</div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-dollar-sign fa-2x text-primary"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Robux stock</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800" id="stock"><?php echo $availablefunds;?> R$</div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-dollar-sign fa-2x text-success"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Paid Out</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800" id="completed">0</div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-unlock-alt fa-2x text-info"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Pending Requests Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Online now</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800" id="online">0</div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-users fa-2x text-warning"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
		  
		  <div class="row">
              <!-- Default Card Example -->
              <div class="card mb-4" style="width: 100%;">
                <div class="card-header">
					<ul class="nav nav-pills">
						<li class="nav-item">
                            <a class="nav-link active" data-toggle="pill" href="#adgate">Source 1(Popular)</a>
                        </li>&nbsp;&nbsp;
					<li class="nav-item">
                            <a class="nav-link" data-toggle="pill" href="#adscend1">Source 2(Top Earning)</a>
                        </li>&nbsp;&nbsp;	
                         <li class="nav-item">
                            <a class="nav-link" data-toggle="pill" href="#offertoro">Source 3</a>
                        </li>&nbsp;&nbsp;
						<li class="nav-item">
                            <a data-toggle="pill" href="#adscend" class="nav-link">Mobile Offers</a>
                        </li>
					</ul>
                </div>
                <div class="card-body">
					<div class="tab-content">
						<div id="home" class="tab-pane fade">
							<h3>Choose a offerwall to start!</h3>
						</div>
						<div id="adscend" class="tab-pane fade">
							<h3>Source 3</h3>
							<p><iframe src="<?php echo $siteurl; ?>/ogads.php?userid=<?php if (isset($_SESSION['usr']['id'])) { echo $_SESSION['usr']['id']; } else { echo '1'; } ?>" frameborder="0" width="100%" height="2400" ></iframe></p>
						</div>
<div id="adscend1" class="tab-pane fade">
							<h3>Source 24</h3>
							<p><iframe src="<?php echo $adscend; ?>?subid1=<?php echo $_SESSION['usr']['id']; ?>" frameborder="0" width="100%" height="2400" ></iframe></p>
						</div>
						<div id="offertoro" class="tab-pane fade">
							<h3>Mobile Offers</h3>
							<p><iframe src="https://www.offertoro.com/ifr/show/20243/<?php if (isset($_SESSION['usr']['id'])) { echo $_SESSION['usr']['id']; } else { echo '1'; } ?>/7736" frameborder="0" width="100%" height="2400" ></iframe></p>
						</div>
						<div id="adgate" class="tab-pane fade show active">
							<h3>Source 1</h3>
							<p><iframe src="<?php echo $adgate; ?><?php if (isset($_SESSION['usr']['id'])) { echo $_SESSION['usr']['id']; } else { echo '1'; } ?>" frameborder="0" width="100%" height="2400" ></iframe></p>
						</div>
					</div>
				</div>
              </div>
		  </div>
		  <br><br>
		  <div id="facts"></div>
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- rbxworld -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-1198743441435740"
     data-ad-slot="5496294790"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; <?php echo $sitename; ?> 2019<?php if (date("Y") != "2019") { echo " - ".date("Y"); } ?></span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="top: 20%">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"></h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body"></div>
        <div class="modal-footer">
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script>
 <script src="js/notyf.min.js" type="text/javascript"></script>
</body>

</html>
<script>
var notyf = new Notyf();
function logoutmodal() {
	document.getElementsByClassName('modal-title')[0].innerHTML = "Ready to Leave?";
	document.getElementsByClassName('modal-body')[0].innerHTML = 'Select "Logout" below if you are ready to end your current session.';
	document.getElementsByClassName('modal-footer')[0].innerHTML = '<button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button><a class="btn btn-primary" href="logout.php">Logout</a>';
}
function httpGet(theUrl) {
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "GET", theUrl, false );
    xmlHttp.send( null );
    return xmlHttp.responseText;
}
function checkinfo() {
	var obj = JSON.parse(httpGet("<?php echo $siteurl; ?>/api/info.php"));
    //if(obj.earn)!="undefined"{
        document.getElementById("earn").innerHTML = obj.earn + " R$";
    /*} else {
        document.getElementById("earn").innerHTML = "0 R$"; 
    }*/
	document.getElementById("stock").innerHTML = obj.stock + " R$";
	document.getElementById("completed").innerHTML = obj.completed+" R$";
	document.getElementById("online").innerHTML = obj.online;
}
function checkloggedin() {
	var response = httpGet("<?php echo $siteurl; ?>/api/checksession.php");
	if (response == "not logged in") {
		if ($("modal").data('bs.modal') && $("modal").data('bs.modal').isShown) {
			console.log("its open!1!1!!!");
		} else {
			document.getElementsByClassName('modal-title')[0].innerHTML = '<center><!--<img src="img/red-cross.png" width="100" length="100">--><br>We need your username so we reward your earned ROBUX! We'+"'"+'ll never ask you for your password!</center>';
			document.getElementsByClassName('modal-body')[0].innerHTML = '<form method="POST"><center><input type="text" class="form-control form-control-user" name="username" placeholder="Roblox username here"></center><br><button class="btn btn-primary" type="submit">Login</button></form>';
			document.getElementsByClassName('modal-footer')[0].innerHTML = '<small>We will never ask you for your password</small>';
			$("#modal").modal();
		}
	}
}
<?php
if (isset($bountycode)) {
	if ($bountycode == 1) {
		echo "document.getElementsByClassName('modal-title')[0].innerHTML = 'Bounty info';";?>
		<?php
		echo "document.getElementsByClassName('modal-body')[0].innerHTML = '".'<center><img src="img/green-check.png" width="100" length="100"></center><br>'."<h4>A new day!</h4>You are on time for your bounty! You are now at day ".$_SESSION['usr']['bounty_streak']." of ".$bountydays." to receive <b>free</b> ".$bountypayout." R$!<br>Check back tomorrow!';";?>
		<?php
		echo "document.getElementsByClassName('modal-footer')[0].innerHTML = '".'<button class="btn btn-primary" type="button" data-dismiss="modal">Close</button>'."';";?>
		<?php
		echo '$("#modal").modal();';?>
		<?php
	} elseif ($bountycode == 2) {
		echo "document.getElementsByClassName('modal-title')[0].innerHTML = 'Bounty info';";?>
		<?php
		echo "document.getElementsByClassName('modal-body')[0].innerHTML = '".'<center><img src="img/red-cross.png" width="100" length="100"></center><br>'."<h4>You are too late!</h4>You are not on time for your bounty! You have been set back to day ".$_SESSION['usr']['bounty_streak']." of ".$bountydays." to receive <b>free</b> ".$bountypayout." R$!<br>Check back tomorrow!';";?>
		<?php
		echo "document.getElementsByClassName('modal-footer')[0].innerHTML = '".'<button class="btn btn-primary" type="button" data-dismiss="modal">Close</button>'."';";?>
		<?php
		echo '$("#modal").modal();';?>
		<?php
	} elseif ($bountycode == 3) {
		echo "document.getElementsByClassName('modal-title')[0].innerHTML = 'Bounty info';";?>
		<?php
		echo "document.getElementsByClassName('modal-body')[0].innerHTML = '".'<center><img src="img/green-check.png" width="100" length="100"></center><br>'."<h4>You have earned ".$bountypayout." R$!</h4>You have been set back to day ".$_SESSION['usr']['bounty_streak']." of ".$bountydays." to receive <b>free</b> ".$bountypayout." R$!<br>Check back tomorrow!';";?>
		<?php
		echo "document.getElementsByClassName('modal-footer')[0].innerHTML = '".'<button class="btn btn-primary" type="button" data-dismiss="modal">Close</button>'."';";?>
		<?php
		echo '$("#modal").modal();';?>
		<?php
	}
} elseif ($loggedin) {
echo "document.getElementsByClassName('modal-title')[0].innerHTML = 'Bounty info';";
echo "document.getElementsByClassName('modal-body')[0].innerHTML = '<h4>Welcome back!</h4>You are at day ".$_SESSION['usr']['bounty_streak']." of ".$bountydays." to receive <b>free</b> ".$bountypayout." R$!<br>Check back in 24 hours!';";
echo "document.getElementsByClassName('modal-footer')[0].innerHTML = '".'<button class="btn btn-primary" type="button" data-dismiss="modal">Close</button>'."';";
echo '$("#modal").modal();';
}
?>

checkinfo();
checkloggedin();
var done = 0;
setInterval(function() {
  if (done == 0) {
	  done = done+1;
  }
  if (done == 1) {
	  //document.getElementById("facts").innerHTML = httpGet("<?php echo $siteurl; ?>/api/facts.php");
	  done = done+1;
  }
}, 15000);
setInterval(function() {
  checkinfo();
}, 5000);
setInterval(function() {
  checkloggedin();
},20000);
setInterval(function() {
  httpGet("<?php echo $siteurl; ?>/api/online.php");
},300000);


function randRange(data) {
var newTime = data[Math.floor(data.length * Math.random())];
return newTime;
}
function toggleSomething() {
var timeArray = new Array(1000, 2000, 3000, 4000, 5000, 500);
notyf.success(httpGet("<?php echo $siteurl; ?>/api/notyf.php"));
clearInterval(timer);
timer = setInterval(toggleSomething, randRange(timeArray));
}
var timer = setInterval(toggleSomething, 1000);
</script>