<?php
if ($_GET['code'] != "fdgusdykfgyubsdfhyubgeui") { die("nope."); }
include_once "../vendor/config/config.php";
$result = $conn->query("SELECT * FROM users WHERE `id`=".$_GET['userid']);
if ($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
		$newbal = round($row['balance']+$_GET['amount']);
		$conn->query("UPDATE users SET balance='$newbal' WHERE id=".$_GET['userid']);
		$conn->query("INSERT INTO offersdone (uid, username, amount) VALUES ('".$_GET['userid']."', '".$row['username']."', '".$_GET['amount']."')");
		$usr = $row;
	}
}
if ($usr['ref'] != null) {
	$result = $conn->query("SELECT * FROM users WHERE `id`=".$usr['ref']);
	while($row = $result->fetch_assoc()) {
		$refcom = round($_GET['amount']/100*$refpercentage);
		if ($refcom > 0) {
			$newbal = $row['balance']+$refcom;
			$conn->query("UPDATE users SET balance='$newbal' WHERE id=".$usr['ref']);
			$conn->query("INSERT INTO ref (uid, refid, amount, username) VALUES ('".$row['uid']."', '".$usr['uid']."', '$refcom', '".$usr['username']."')");
		}
	}
}
echo "1";
?>