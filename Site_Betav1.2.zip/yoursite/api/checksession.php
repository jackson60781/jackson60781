<?php
include_once "../vendor/config/config.php";
$a = true;
if (isset($_SESSION['username'])) {
	if (isset($_SESSION['usr']['uid'])) {
		$a = false;
	}
}
if ($a) {
	die("not logged in");
} else {
	die("logged in");
}
?>