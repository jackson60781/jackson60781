<?php
$userid = $_GET["userid"];
$amount = $_GET["amount"];
$profit = $_GET["ourprofit"];
echo "1";
?>