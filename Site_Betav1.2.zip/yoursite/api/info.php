<?php
include_once "../vendor/config/config.php";
$response = array();
if (isset($_SESSION['usr']['id'])){
	$result = $conn->query("SELECT * FROM `users` WHERE `id`=".$_SESSION['usr']['id']);
	while($row = $result->fetch_assoc()) {
		$_SESSION['usr'] = $row;
		$response['earn'] = $row['balance'];
	}
}
$response['completed'] = 0;
$result = $conn->query("SELECT * FROM `offersdone`");
while($row = $result->fetch_assoc()) {
	$response['completed'] = $response['completed']+$row['amount'];
}
$result = $conn->query("SELECT * FROM groupinfo");
while($row = $result->fetch_assoc()) {
	$groupamount = $row['amount'];
}
$response['stock'] = $groupamount;
$result = $conn->query("SELECT DISTINCT `ip` FROM requests WHERE `time` >= NOW() - INTERVAL 10 MINUTE");
$count = 0;
while($row = $result->fetch_assoc()) {
	$count++;
}
$response['online'] = $count;
die(json_encode($response));
?>