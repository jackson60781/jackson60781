<?php
include_once "../vendor/config/config.php";
$result = $conn->query("SELECT username, amount FROM offersdone ORDER BY RAND() LIMIT 1");
while($row = $result->fetch_assoc()) {
die($row['username']." earned <b>".$row['amount']." R$</b>!");
}
?>