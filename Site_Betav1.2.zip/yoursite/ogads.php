<?php error_reporting(E_ALL); ini_set('display_errors', 1); ?>
<html>
<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
</head>
<?php
function ipCheck() {
    foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $key)
    {
        if (array_key_exists($key, $_SERVER) === true)
        {
            foreach (array_map('trim', explode(',', $_SERVER[$key])) as $ip)
            {
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false)
                {
                    return $ip;
                }
            }
        }
    }
}

//setup required variables
$ip = ipCheck();
//url to request
$url = "https://mobverify.com/api/v1/?affiliateid=180286&ctype=1&ip=".urlencode($ip)."&aff_sub4=".$_GET['userid'];

//initialize curl
$ch = curl_init();

//setup curl options
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

//make request
$response = curl_exec($ch);

if($response === false) {
    //curl error occurred, handle it how you like
    echo curl_error($ch);
}

//close the curl object
curl_close($ch);

if($response !== false) {
    //curl request was successful

    //decode the json response into a php array
    $json = json_decode($response, true);

    if($json === false) {
        //failed to decode json response
        echo json_last_error_msg();

    } elseif($json['success']) {
        foreach($json['offers'] as $offer) {
        $payout = $offer['payout'];
        $link = $offer['link'];
        $p = 50;
$url = preg_replace("/^http:/i", "https:", $link);
            echo '<hr><div class="row"><div class="col-8"><h3 class="card-title">Offer #' .$offer['offerid']. ' - '.$offer['name_short'].'</h3><p class="card-text">'.$offer['name'].'</p></div><div class="col"><a href="'.$url.'" class="btn btn-primary" target="_blank">'.round($payout * $p).' Robux</a></div></div>';
        }

    } else {
        //api error occurred, handle it how you like
        echo $json['error'];
    }

}

?>

</html>