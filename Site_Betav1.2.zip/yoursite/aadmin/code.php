<?php
$string = strtotime(date('Y-m-d H:i:s'));
$count = 0;
do {
	$count++;
	$string = md5($string);
} while ($count < 50);
echo $string;
?>
<br><br>This code will be valid for 10 seconds.