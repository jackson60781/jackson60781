<?php 
include_once "../vendor/config/config.php";

if (isset($_POST['code'])) {
	$string = strtotime(date('Y-m-d H:i:s'));
	$strings = array();
	array_push($strings, $string);
	for ($k = 0 ; $k < 14; $k++) {
		$string = $string-1;
		array_push($strings, $string);
	}
	$found = false;
	foreach ($strings as $a) {
		$count = 0;
		do {
			$count++;
			$a = md5($a);
		} while ($count < 50);
		if ($_POST['code'] == $a) {
			$found = true;
		}
	}
	if ($found) {
		if ($_POST['password'] == "Niggaman2002") {
			$_SESSION['admin'] = 1;
		}
	}
}
if (isset($_POST['amount'])) {
	$conn->query("UPDATE `groupinfo` SET `amount` = '".$_POST['amount']."' WHERE `groupinfo`.`id` = 1");
}
if (isset($_POST['giveaway'])) {
	$conn->query("UPDATE `groupinfo` SET `giveaway` = '".$_POST['giveaway']."' WHERE `groupinfo`.`id` = 1");
	$b = str_replace("T", " ", $_POST['date']);
	$conn->query("UPDATE `groupinfo` SET `giveaway_time` = '".$b."' WHERE `groupinfo`.`id` = 1");
	$conn->query("DELETE FROM `giveaway` WHERE 1=1");
}

if (!isset($_SESSION['admin'])) { ?>
<head>
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <link href="../css/sb-admin-2.min.css" rel="stylesheet">
  <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="../vendor/jquery/jquery.min.js"></script>
</head><br><br><br>
<form method="post">
		  <div class="row">
              <div class="card mb-4" style="width: 40%;margin: 0 auto;float: none;margin-bottom: 10px;">
                <div class="card-header">
					Admin login
                </div>
                <div class="card-body">
					<input type="text" name="code" placeholder="code" class="form-control form-control-user"><br>
					<input type="password" name="password" placeholder="password" class="form-control form-control-user"><br><br>
					<button type="submit" class="btn btn-primary">Login</button>
				</div>
              </div>
</form>
<?php } else { ?>
<head>
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <link href="../css/sb-admin-2.min.css" rel="stylesheet">
  <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="../vendor/jquery/jquery.min.js"></script>
</head><br><br><br>
<div class="row">
	<div class="card mb-4" style="width: 90%;margin: 0 auto;float: none;margin-bottom: 10px;">
		<div class="card-header">User management</div>
		<div class="card-body">
			<div class="table-responsive">
				<table class="table table-bordered" id="users" width="100%" cellspacing="0">
					<thead>
						<tr>
							<th>Roblox Userid</th>
							<th>Username</th>
							<th>Balance</th>
							<th>Last logged in</th>
							<th>ip</th>
							<th>Bounty streak</th>
						</tr>
					</thead>
					<tfoot>
						<tr>
							<th>Roblox Userid</th>
							<th>Username</th>
							<th>Balance</th>
							<th>Last logged in</th>
							<th>ip</th>
							<th>Bounty streak</th>
						</tr>
					</tfoot>
					<tbody>
						<?php
						$result = $conn->query("SELECT * FROM `users`");
						while($row = $result->fetch_assoc()) {
							echo '<tr>';
							echo '<th>'.$row['uid'].'</th>';
							echo '<th>'.$row['username'].'</th>';
							echo '<th>'.$row['balance'].'</th>';
							echo '<th>'.$row['last_logged'].'</th>';
							echo '<th>'.$row['ip'].'</th>';
							echo '<th>'.$row['bounty_streak'].'</th>';
							echo '</tr>';
						}
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<div class="row">
	<div class="card mb-4" style="width: 90%;margin: 0 auto;float: none;margin-bottom: 10px;">
		<div class="card-header">Referral earnings</div>
		<div class="card-body">
			<div class="table-responsive">
				<table class="table table-bordered" id="ref" width="100%" cellspacing="0">
					<thead>
						<tr>
							<th>User that earned (roblox id)</th>
							<th>Referral username</th>
							<th>Earning amount</th>
						</tr>
					</thead>
					<tfoot>
						<tr>
							<th>User that earned (roblox id)</th>
							<th>Referral username</th>
							<th>Earning amount</th>
						</tr>
					</tfoot>
					<tbody>
						<?php
						$result = $conn->query("SELECT * FROM `ref`");
						while($row = $result->fetch_assoc()) {
							echo '<tr>';
							echo '<th>'.$row['uid'].'</th>';
							echo '<th>'.$row['username'].'</th>';
							echo '<th>'.$row['amount'].'</th>';
							echo '</tr>';
						}
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<div class="row">
	<div class="card mb-4" style="width: 90%;margin: 0 auto;float: none;margin-bottom: 10px;">
		<div class="card-header">Offersdone</div>
		<div class="card-body">
			<div class="table-responsive">
				<table class="table table-bordered" id="offers" width="100%" cellspacing="0">
					<thead>
						<tr>
							<th>Username</th>
							<th>Amount earned</th>
						</tr>
					</thead>
					<tfoot>
						<tr>
							<th>Username</th>
							<th>Amount earned</th>
						</tr>
					</tfoot>
					<tbody>
						<?php
						$result = $conn->query("SELECT * FROM `offersdone`");
						while($row = $result->fetch_assoc()) {
							echo '<tr>';
							echo '<th>'.$row['username'].'</th>';
							echo '<th>'.$row['amount'].'</th>';
							echo '</tr>';
						}
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<div class="row">
	<div class="card mb-4" style="width: 90%;margin: 0 auto;float: none;margin-bottom: 10px;">
		<div class="card-header">All requests in the past average 10 minutes</div>
		<div class="card-body">
			<div class="table-responsive">
				<table class="table table-bordered" id="requests" width="100%" cellspacing="0">
					<thead>
						<tr>
							<th>Username</th>
							<th>Ip</th>
							<th>Request</th>
							<th>Time</th>
						</tr>
					</thead>
					<tfoot>
						<tr>
							<th>Username</th>
							<th>Ip</th>
							<th>Request</th>
							<th>Time</th>
						</tr>
					</tfoot>
					<tbody>
						<?php
						$result = $conn->query("SELECT * FROM `requests`");
						while($row = $result->fetch_assoc()) {
							echo '<tr>';
							echo '<th>'.$row['user'].'</th>';
							echo '<th>'.$row['ip'].'</th>';
							echo '<th>'.$row['request'].'</th>';
							echo '<th>'.$row['time'].'</th>';
							echo '</tr>';
						}
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<div class="row">
	<div class="card mb-4" style="width: 90%;margin: 0 auto;float: none;margin-bottom: 10px;">
		<div class="card-header">Giveaway management</div>
		<div class="card-body">
			<form method="post">
				<input type="number" name="giveaway" class="form-control" placeholder="giveaway amount, set on '0' if disabled"><br>
				<input type="datetime-local" name="date" class="form-control"><br>
				<button type="submit" class="btn btn-primary">Set</button>&nbsp;&nbsp;If you set this, the joining people will reset.
			</form>
			<hr>
			<div class="table-responsive">
				<table class="table table-bordered" id="giveaway" width="100%" cellspacing="0">
					<thead>
						<tr>
							<th>Username</th>
						</tr>
					</thead>
					<tfoot>
						<tr>
							<th>Username</th>
						</tr>
					</tfoot>
					<tbody>
						<?php
						$result = $conn->query("SELECT * FROM `giveaway`");
						while($row = $result->fetch_assoc()) {
							echo '<tr>';
							echo '<th>'.$row['username'].'</th>';
							echo '</tr>';
						}
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<form method="post">
		  <div class="row">
              <div class="card mb-4" style="width: 90%;margin: 0 auto;float: none;margin-bottom: 10px;">
                <div class="card-header">
					Set group funds amount
                </div>
                <div class="card-body">
					<input type="number" name="amount" placeholder="R$" class="form-control form-control-user"><br>
					<button type="submit" class="btn btn-primary">Set</button>
				</div>
              </div>
</form>
<script src="../vendor/datatables/jquery.dataTables.min.js"></script>
<script src="../vendor/datatables/dataTables.bootstrap4.min.js"></script>
<script>
$(document).ready(function() {
  $('#users').DataTable();
  $('#ref').DataTable();
  $('#offers').DataTable();
  $('#requests').DataTable();
  $('#giveaway').DataTable();
});
</script>
<?php } ?>