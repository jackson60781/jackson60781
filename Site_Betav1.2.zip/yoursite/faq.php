<?php 
include_once "vendor/config/config.php"; 
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
				<meta name="description" content="">
					<meta name="author" content="">
						<title>
							<?php echo $sitename; ?> - Faq
						</title>
						<!-- Custom fonts for this template-->
						<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
							<link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
								<!-- Custom styles for this template-->
								<link href="css/sb-admin-2.min.css" rel="stylesheet">
									<!-- Extra scripts -->
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({
          google_ad_client: "ca-pub-1198743441435740",
          enable_page_level_ads: true
     });
</script>
									<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
									<script src="vendor/jquery/jquery.min.js"></script>
								</head>
								<body id="page-top">
									<!-- Page Wrapper -->
									<div id="wrapper">
										<?php include_once "vendor/sidebar.php"; ?>
										<!-- Content Wrapper -->
										<div id="content-wrapper" class="d-flex flex-column">
											<!-- Main Content -->
											<div id="content">
												<!-- Topbar -->
												<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
													<!-- Sidebar Toggle (Topbar) -->
													<button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
														<i class="fa fa-bars"></i>
													</button>
													<!-- Topbar Navbar -->
													<ul class="navbar-nav ml-auto">
														<!-- Nav Item - Alerts -->
														<li class="nav-item dropdown no-arrow mx-1">
															<a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
																<i class="fas fa-bell fa-fw"></i>
																<!-- Counter - Alerts -->
																<span class="badge badge-danger badge-counter">0</span>
															</a>
															<!-- Dropdown - Alerts -->
															<div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="alertsDropdown">
																<h6 class="dropdown-header">
                  Alerts Center
                </h6>
																<!--<a class="dropdown-item d-flex align-items-center" href="#"><div class="mr-3"><div class="icon-circle bg-primary"><i class="fas fa-file-alt text-white"></i></div></div><div><div class="small text-gray-500">December 12, 2019</div><span class="font-weight-bold">A new monthly report is ready to download!</span></div></a>-->
																<a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
															</div>
														</li>
														<!-- Nav Item - Messages -->
														<li class="nav-item dropdown no-arrow mx-1">
															<a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
																<i class="fas fa-envelope fa-fw"></i>
																<!-- Counter - Messages -->
																<span class="badge badge-danger badge-counter">0</span>
															</a>
															<!-- Dropdown - Messages -->
															<div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="messagesDropdown">
																<h6 class="dropdown-header">
                  Updates Center
                </h6>
																<!--<a class="dropdown-item d-flex align-items-center" href="#"><div class="dropdown-list-image mr-3"><img class="rounded-circle" src="https://source.unsplash.com/fn_BT9fwg_E/60x60" alt=""><div class="status-indicator bg-success"></div></div><div class="font-weight-bold"><div class="text-truncate">Hi there! I am wondering if you can help me with a problem I've been having.</div><div class="small text-gray-500">Emily Fowler · 58m</div></div></a>-->
																<a class="dropdown-item text-center small text-gray-500" href="#">Read More Messages</a>
															</div>
														</li>
														<div class="topbar-divider d-none d-sm-block"></div>
														<!-- Nav Item - User Information -->
														<li class="nav-item dropdown no-arrow">
															<a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
																<span class="mr-2 d-none d-lg-inline text-gray-600 small">
																	<?php if (!isset($_SESSION['username'])) { echo "Guest"; } else { echo $_SESSION['username']; } ?>
																</span>
																<img class="img-profile rounded-circle" src="
																	<?php if (!isset($_SESSION['usr']['uid'])) { echo "https://www.roblox.com/headshot-thumbnail/image?userId=1&width=60&height=60&format=png"; } else { echo "https://www.roblox.com/headshot-thumbnail/image?userId=".$_SESSION['usr']['uid']."&width=60&height=60&format=png"; } ?>">
																</a>
																<!-- Dropdown - User Information -->
																<div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
																	<a class="dropdown-item" href="#">
																		<i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                  Request a withdraw
                
																	</a>
																	<a class="dropdown-item" href="#">
																		<i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                  Activity Log
                
																	</a>
																	<div class="dropdown-divider"></div>
																	<a class="dropdown-item" href="#" data-toggle="modal" data-target="#modal" onclick="logoutmodal();">
																		<i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                
																	</a>
																</div>
															</li>
														</ul>
													</nav>
													<!-- End of Topbar -->
													<!-- Begin Page Content -->
													<div class="container-fluid">
														<div class="row">
															<div class="col-md-3"></div>
															<div class="col-md-6">
																<div class="card">
																	<div class="card-body">
																		<article class="media">
																			<div class="media-body">
																				<div class="content">
																					<p class="h5">How Does this Work?</p>
																					<p>This website pays users for completing offers. This website is intended to be used by mobile users as there is more offers for mobile such as downloading apps. Desktop users can still use this site and complete things such as surveys.</p>
																				</div>
																			</div>
																		</article>
																	</div>
																</div>
                                                                <br><br>
																<div class="card">
																	<div class="card-body">
																		<article class="media">
																			<div class="media-body">
																				<div class="content">
																					<p class="h5">How do I Claim my Robux?</p>
																					<p>To claim your robux, press on the "claim" tab, then it should show your balance total for all the surveys you have completed.
Once you want to claim, press on "Claim Rewards" and it should lead you to a group to join.</p>
																				</div>
																			</div>
																		</article>
																	</div>
																</div>
                                                                <br><br>
																<div class="card">
																	<div class="card-body">
																		<article class="media">
																			<div class="media-body">
																				<div class="content">
																					<p class="h5">How do referrals work on this site?</p>
																					<p>Basically, there is a percentage of earnings whenever you refer a user. Say you refer a friend, and they complete an offer, you will receive a % of whatever amount the offer was worth. Our current site referral percent is 5. This means that if your friend did a R$100 offer, then you will receive R$5 to your withdraw box. You will be able to withdraw that instantly to your account.</p>
																				</div>
																			</div>
																		</article>
																	</div>
																</div>
                                                                <br><br>
																<div class="card">
																	<div class="card-body">
																		<article class="media">
																			<div class="media-body">
																				<div class="content">
																					<p class="h5">I did not get my Robux! Is this site a scam?</p>
																					<p>Our website is 100% legitimate. Before anything, make sure you actually completed the offer. This includes: read the description of the offer, make sure app is downloaded, or make sure you finished the survey. Many users complain before they read everything. If you did everything right, it will be a bug from our source or offer wall companies. Please redo the offer or do another one.</p>
																				</div>
																			</div>
																		</article>
																	</div>
																</div>
                                                                <br><br>
																<div class="card">
																	<div class="card-body">
																		<article class="media">
																			<div class="media-body">
																				<div class="content">
																					<p class="h5">Do you guys own the images?</p>
																					<p>We do not own any images associated with other parties such as ROBLOX.com. We are a friendly third party website that helps its users earn robux without actually spending money to purchase it. Any logos or trademarks are used for reference purposes only. By using our website, you agree to our terms and services. We are friendly and hope you enjoy.</p>
																				</div>
																			</div>
																		</article>
																	</div>
																</div>
                                                                <br><br>
																<div class="card">
																	<div class="card-body">
																		<article class="media">
																			<div class="media-body">
																				<div class="content">
																					<p class="h5">Have a problem with the site?</p>
																					<p>If you have a problem with the site or you have a question please contact our Discord. </p>
																				</div>
																			</div>
																		</article>
																	</div>
																</div>
                                                                <br><br>
																<div class="card">
																	<div class="card-body">
																		<article class="media">
																			<div class="media-body">
																				<div class="content">
																					<p class="h5">Do you guys sponsor youtubers?</p>
																					<p>Yes, please reach us via discord to inquire about sponsorships.</p>
																				</div>
																			</div>
																		</article>
																	</div>
																</div>
                                                                <br><br>
																<div class="card">
																	<div class="card-body">
																		<article class="media">
																			<div class="media-body">
																				<div class="content">
																					<p class="h5">Does this site need my password?</p>
																					<p>No. We would never ask you for anything personal. We do not need passwords for our website. You simply need to enter your username and then you can complete offers and start earning yourself some robux. It is very easy and simple to do our offers. Most include surveys or downloading apps. Please use a phone for downloading apps.</p>
																				</div>
																			</div>
																		</article>
																	</div>
																</div>
                                                                <br><br>
																<div class="card">
																	<div class="card-body">
																		<article class="media">
																			<div class="media-body">
																				<div class="content">
																					<p class="h5">When do you restock?</p>
																					<p>Every day. May take up to 3 days at some times.</p>
																				</div>
																			</div>
																		</article>
																	</div>
																</div>
															</div>
														</div>
													</div>
                                                    <br><br>
													<!-- /.container-fluid -->
												</div>
												<!-- End of Main Content -->
<div class="card">
<div class="card-body>
<article class="media">                                                    <div class="media-body">                                                        <div class="content">
<h2>Apple Card vs Bitcoin, this is what the community says: 'Jobs is Satoshi?'</h2>
<h4><b>Apple's announcement that it will be releasing the Apple Card this summer in the United States has made some cryptocurrency enthusiast worried and others excited. Is Apple Card a threat to Bitcoin and other cryptocurrencies trying to become a widely adopted payment method? This is what the community says. </b></h4>
<h5>The Apple Card is a creditcard created in partnership with Goldman Sachs and Mastercard, and is being built into the Apple Wallet app on the iPhone, with no fees, lower interest and 'a new level of privacy and security'. The unique card number is stored safely in Secure Element, a special security chip, and because of the 'unique security and privacy architecture' Apple claims it will never know where a customer shopped, what they bought or how much they paid. </h5></div></div>
</article>
</div>
</div>

												<!-- End of Footer -->
											</div>
											<!-- End of Content Wrapper -->
										</div>
										<!-- End of Page Wrapper -->
										<!-- Scroll to Top Button-->
										<a class="scroll-to-top rounded" href="#page-top">
											<i class="fas fa-angle-up"></i>
										</a>
										<!-- Logout Modal-->
										<div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="top: 20%">
											<div class="modal-dialog" role="document">
												<div class="modal-content">
													<div class="modal-header">
														<h5 class="modal-title" id="exampleModalLabel"></h5>
														<button class="close" type="button" data-dismiss="modal" aria-label="Close">
															<span aria-hidden="true">×</span>
														</button>
													</div>
													<div class="modal-body"></div>
													<div class="modal-footer"></div>
												</div>
											</div>
										</div>
										<!-- Bootstrap core JavaScript-->
										<script src="vendor/jquery/jquery.min.js"></script>
										<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
										<!-- Core plugin JavaScript-->
										<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
										<!-- Custom scripts for all pages-->
										<script src="js/sb-admin-2.min.js"></script>
										<!-- Page level plugins -->
										<script src="vendor/chart.js/Chart.min.js"></script>
										<!-- Page level custom scripts -->
										<script src="js/demo/chart-area-demo.js"></script>
										<script src="js/demo/chart-pie-demo.js"></script>
									</body>
								</html>