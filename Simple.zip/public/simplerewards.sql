-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Värd: 127.0.0.1
-- Tid vid skapande: 30 okt 2018 kl 20:53
-- Serverversion: 10.1.33-MariaDB
-- PHP-version: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databas: `simplerewards`
--

-- --------------------------------------------------------

--
-- Tabellstruktur `site`
--

CREATE TABLE `site` (
  `id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `rbx_group` int(11) NOT NULL,
  `rbx_stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `site`
--

INSERT INTO `site` (`id`, `name`, `rbx_group`, `rbx_stock`) VALUES
(1, 'sitenamehere', 1, 1);

-- --------------------------------------------------------

--
-- Tabellstruktur `users`
--

CREATE TABLE `users` (
  `username` varchar(25) NOT NULL,
  `balance` varchar(25) NOT NULL,
  `earned` varchar(256) NOT NULL,
  `rank` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `users`
--

INSERT INTO `users` (`username`, `balance`, `earned`, `rank`) VALUES
('qwe', '0', '0', '0');

-- --------------------------------------------------------

--
-- Tabellstruktur `withdrawals`
--

CREATE TABLE `withdrawals` (
  `id` varchar(25) NOT NULL,
  `date` varchar(256) NOT NULL,
  `username` varchar(25) NOT NULL,
  `ammount` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Index för dumpade tabeller
--

--
-- Index för tabell `site`
--
ALTER TABLE `site`
  ADD PRIMARY KEY (`id`);

--
-- Index för tabell `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`);

--
-- Index för tabell `withdrawals`
--
ALTER TABLE `withdrawals`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
