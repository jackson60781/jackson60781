<?php 
include('../api/config.php'); 
$link= mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);
session_start();

if ( isset( $_SESSION['user'] ) ) {
	// Do nothing
} else {
    header("Location: index.php");
}

$user = $_SESSION['user'];
$q ="SELECT * FROM users WHERE username='$user'";
$res=mysqli_query($link,$q);
$row=mysqli_fetch_assoc($res);

$user = $_SESSION['user'];
$q2 ="SELECT * FROM site WHERE id=1";
$res2=mysqli_query($link,$q2);
$site=mysqli_fetch_assoc($res2);

?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php echo (SITE_NAME);?></title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css" integrity="sha384-/rXc/GQVaYpyDdyxK+ecHPVYJSN9bmVFBvjA/9eOB+pb3F2w2N6fc5qB9Ew5yIns" crossorigin="anonymous">
    <!-- Bootstrap core CSS -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="../assets/css/mdb.min.css" rel="stylesheet">
    <link href="../assets/css/style.min.css" rel="stylesheet">
</head>

<body class="grey lighten-3">

    <!--Main Navigation-->
    <header>

        <!-- Navbar -->
        <nav class="navbar fixed-top navbar-expand-lg navbar-light white scrolling-navbar">
            <div class="container-fluid">

                <!-- Brand -->
                <a class="navbar-brand waves-effect" href="#" target="_blank">
                    <strong class="blue-text"><?php echo htmlspecialchars(SITE_NAME);?></strong>
                </a>

                <!-- Collapse -->
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <!-- Links -->
                <div class="collapse navbar-collapse" id="navbarSupportedContent">

                    <!-- Left -->
                    <ul class="navbar-nav mr-auto"></ul>

                    <!-- Right -->
                    <ul class="navbar-nav nav-flex-icons">
                        <li class="nav-item">
                            <a href="../api/logout.php" class="nav-link border border-light rounded waves-effect"><i class="fa fa-user mr-2"></i>Logout</a>
                        </li>
                    </ul>

                </div>

            </div>
        </nav>
        <!-- Navbar -->

        <!-- Sidebar -->
        <div class="sidebar-fixed position-fixed">

            <div class="justify-content-center text-center">
				<br/>
                <img src="https://www.roblox.com/Thumbs/Avatar.ashx?x=150&y=150&Format=Png&username=<?php echo($user);?>">
                <h3><?php echo($user);?></h3>
				<h3><img src="../assets/img/robux.png" width="15%"> <font id="updateable"><?php echo ($row['balance']); ?></font></h3>
				<br/>
			</div>
				
            <div class="list-group list-group-flush">
                <a href="./index.php" class="list-group-item list-group-item-action waves-effect">
                    <i class="fa fa-home mr-3"></i>Dashboard</a>
                <a href="./earn.php" class="list-group-item list-group-item-action waves-effect">
                    <i class="fa fa-edit mr-3"></i>Surveys</a>
                <a href="./withdraw.php" class="list-group-item active waves-effect">
                    <i class="fa fa-shopping-cart mr-3"></i>Withdraw</a>
                <a href="#" class="list-group-item list-group-item-action waves-effect">
                    <i class="fab fa-discord mr-3"></i>Discord</a>
            </div>

        </div>
        <!-- Sidebar -->

    </header>
    <!--Main Navigation-->

    <!--Main layout-->
    <main class="pt-5 mx-lg-5">
		
        <div class="container-fluid mt-5">
                        <div class="card text-center">
									<div class="card-header primary-color white-text">
										<h4>Instant Withdrawal</h4>
									</div>
									<div class="card-body">
                                            <img src="../assets/img/roblox.png" width="50%" border="0" alt="ROBLOX Logo"><br>
                                        <form action="../api/withdraw.php" method="post">
                                        <select name="ammount" class="browser-default custom-select">
                                            <option selected>Ammount</option>
                                            <option value="10">10 R$</option>
                                            <option value="25">25 R$</option>
                                            <option value="50">50 R$</option>
                                            <option value="75">75 R$</option>
                                            <option value="100">100 R$</option>
                                            <option value="150">150 R$</option>
                                            <option value="250">250 R$</option>
                                            <option value="500">500 R$</option>
                                            <option value="1000">1 000 R$</option>
                                            <option value="2500">2 500 R$</option>
                                        </select><br>
                                            <h5>Make sure you join the group!</h5>
                                            <a href="https://www.roblox.com/groups/group.aspx?gid=<?php echo ($site['rbx_group']); ?>" target="_blank" type="submit" style="height: 5%;" class="btn-block btn-success">Join group</a><br>
                                            <button type="submit" class="btn btn-success">Withdraw</button>
                                        </form>
									</div>
								</div>
                                <br><br>
                                <table class="table">
                                    <thead class="black white-text">
                                        <tr>
                                            <th scope="col">Date</th>
                                            <th scope="col">ID</th>
                                            <th scope="col">Username</th>
                                            <th scope="col">Ammount</th>
                                        </tr>
                                    </thead>
                                        <tbody>
                                            <?php   
                                            function tableitem($date, $id, $username, $ammount) {
                                                echo('
                                                <tr>
                                                    <th scope="row">' . $date . '</th>
                                                    <td>' . $id . '</td>
                                                    <td>' . $username . '</td>
                                                    <td class="text-success">' . $ammount . ' R$</td>
                                                </tr>
                                                ');
                                            }

                                            $sql2 = "SELECT * FROM withdrawals WHERE `username` = '$user' ORDER BY `date` DESC";
                                            $result2 = mysqli_query($link,$sql2);
                                            $tables = mysqli_fetch_all($result2,MYSQLI_ASSOC);

                                            foreach ($tables as $table) {
                                                tableitem($table['date'], $table['id'], $table['username'], $table['ammount']);
                                            }

                                            ?>
                                        </tbody>
                                    </table>
         </div>
        
			
    </main>
    <!--Main layout-->

    <!-- SCRIPTS -->
    <!-- JQuery -->
    <script type="text/javascript" src="../assets/js/jquery-3.3.1.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="../assets/js/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="../assets/js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="../assets/js/mdb.min.js"></script>
    <!-- Initializations -->
    <script type="text/javascript">
        // Animations initialization
        new WOW().init();
    </script>
</body>

</html>
