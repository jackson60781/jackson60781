<?php 
include('../api/config.php'); 
$link= mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);
session_start();

if ( isset( $_SESSION['user'] ) ) {
	// Do nothing
} else {
    header("Location: index.php");
}

$user = $_SESSION['user'];
$q ="SELECT * FROM users WHERE username='$user'";
$res=mysqli_query($link,$q);
$row=mysqli_fetch_assoc($res);


?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php echo (SITE_NAME);?></title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css" integrity="sha384-/rXc/GQVaYpyDdyxK+ecHPVYJSN9bmVFBvjA/9eOB+pb3F2w2N6fc5qB9Ew5yIns" crossorigin="anonymous">
    <!-- Bootstrap core CSS -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="../assets/css/mdb.min.css" rel="stylesheet">
    <link href="../assets/css/style.min.css" rel="stylesheet">
</head>

<body class="grey lighten-3">

    <!--Main Navigation-->
    <header>

        <!-- Navbar -->
        <nav class="navbar fixed-top navbar-expand-lg navbar-light white scrolling-navbar">
            <div class="container-fluid">

                <!-- Brand -->
                <a class="navbar-brand waves-effect" href="#" target="_blank">
                    <strong class="blue-text"><?php echo htmlspecialchars(SITE_NAME);?></strong>
                </a>

                <!-- Collapse -->
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <!-- Links -->
                <div class="collapse navbar-collapse" id="navbarSupportedContent">

                    <!-- Left -->
                    <ul class="navbar-nav mr-auto"></ul>

                    <!-- Right -->
                    <ul class="navbar-nav nav-flex-icons">
                        <li class="nav-item">
                            <a href="../api/logout.php" class="nav-link border border-light rounded waves-effect"><i class="fa fa-user mr-2"></i>Logout</a>
                        </li>
                    </ul>

                </div>

            </div>
        </nav>
        <!-- Navbar -->

        <!-- Sidebar -->
        <div class="sidebar-fixed position-fixed">

            <div class="justify-content-center text-center">
				<br/>
                <img src="https://www.roblox.com/Thumbs/Avatar.ashx?x=150&y=150&Format=Png&username=<?php echo($user);?>">
                <h3><?php echo($user);?></h3>
				<h3><img src="../assets/img/robux.png" width="15%"> <font id="updateable"><?php echo ($row['balance']); ?></font></h3>
				<br/>
			</div>
				
            <div class="list-group list-group-flush">
                <a href="./index.php" class="list-group-item list-group-item-action waves-effect">
                    <i class="fa fa-home mr-3"></i>Dashboard</a>
                <a href="./earn.php" class="list-group-item active waves-effect">
                    <i class="fa fa-edit mr-3"></i>Surveys</a>
                <a href="./withdraw.php" class="list-group-item list-group-item-action waves-effect">
                    <i class="fa fa-shopping-cart mr-3"></i>Withdraw</a>
                <a href="#" class="list-group-item list-group-item-action waves-effect">
                    <i class="fab fa-discord mr-3"></i>Discord</a>
            </div>

        </div>
        <!-- Sidebar -->

    </header>
    <!--Main Navigation-->

    <!--Main layout-->
    <main class="pt-5 mx-lg-5">
        <div class="container-fluid mt-5">
		
		<section>

            <ul class="nav md-pills nav-justified pills-secondary">
                <li class="nav-item">
                    <a class="nav-link active" data-toggle="tab" href="#panel11" role="tab">Offerwall 1</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#panel12" role="tab">Offerwall 2</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#panel13" role="tab">Offerwall 3</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#panel14" role="tab">Offerwall 4</a>
                </li>
            </ul>

            <!-- Tab panels -->
            <div class="tab-content">

                <!--Panel 1-->
                <div class="tab-pane fade in show active" id="panel11" role="tabpanel">
				<center>
				<iframe src="<?php echo 'https://www.offertoro.com/ifr/show/18604/' . $_SESSION['user'] . '/6861' ?>" frameborder="0" width="100%" height="2400" ></iframe> 
				</center>
                </div>
                <!--/.Panel 1-->

                <!--Panel 2-->
                <div class="tab-pane fade" id="panel12" role="tabpanel">
                    <br>

                    <p>2</p>

                </div>
                <!--/.Panel 2-->

                <!--Panel 3-->
                <div class="tab-pane fade" id="panel13" role="tabpanel">
                    <br>

                    <p>3</p>

                </div>
                <!--/.Panel 3-->

                <!--Panel 4-->
                <div class="tab-pane fade" id="panel14" role="tabpanel">
                    <br>

                    <p>4</p>

                </div>
                <!--/.Panel 4-->

            </div>

        </section>
		
        </div>
    </main>
    <!--Main layout-->

    <!-- SCRIPTS -->
    <!-- JQuery -->
    <script type="text/javascript" src="../assets/js/jquery-3.3.1.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="../assets/js/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="../assets/js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="../assets/js/mdb.min.js"></script>
    <!-- Initializations -->
    <script type="text/javascript">
        // Animations initialization
        new WOW().init();
    </script>
</body>

</html>