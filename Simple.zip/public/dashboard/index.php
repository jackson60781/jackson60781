<?php 
include('../api/config.php'); 
$link= mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);
session_start();

if ( isset( $_SESSION['user'] ) ) {
	// Do nothing
} else {
    header("Location: index.php");
}

$user = $_SESSION['user'];
$q ="SELECT * FROM users WHERE username='$user'";
$res=mysqli_query($link,$q);
$row=mysqli_fetch_assoc($res);

$user = $_SESSION['user'];
$q2 ="SELECT * FROM site WHERE id=1";
$res2=mysqli_query($link,$q2);
$site=mysqli_fetch_assoc($res2);

?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php echo (SITE_NAME);?></title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css" integrity="sha384-/rXc/GQVaYpyDdyxK+ecHPVYJSN9bmVFBvjA/9eOB+pb3F2w2N6fc5qB9Ew5yIns" crossorigin="anonymous">
    <!-- Bootstrap core CSS -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="../assets/css/mdb.min.css" rel="stylesheet">
    <link href="../assets/css/style.min.css" rel="stylesheet">
</head>

<body class="grey lighten-3">

    <!--Main Navigation-->
    <header>

        <!-- Navbar -->
        <nav class="navbar fixed-top navbar-expand-lg navbar-light white scrolling-navbar">
            <div class="container-fluid">

                <!-- Brand -->
                <a class="navbar-brand waves-effect" href="#" target="_blank">
                    <strong class="blue-text"><?php echo htmlspecialchars(SITE_NAME);?></strong>
                </a>

                <!-- Collapse -->
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <!-- Links -->
                <div class="collapse navbar-collapse" id="navbarSupportedContent">

                    <!-- Left -->
                    <ul class="navbar-nav mr-auto"></ul>

                    <!-- Right -->
                    <ul class="navbar-nav nav-flex-icons">
                        <li class="nav-item">
                            <a href="../api/logout.php" class="nav-link border border-light rounded waves-effect"><i class="fa fa-user mr-2"></i>Logout</a>
                        </li>
                    </ul>

                </div>

            </div>
        </nav>
        <!-- Navbar -->

        <!-- Sidebar -->
        <div class="sidebar-fixed position-fixed">

            <div class="justify-content-center text-center">
				<br/>
                <img src="https://www.roblox.com/Thumbs/Avatar.ashx?x=150&y=150&Format=Png&username=<?php echo($user);?>">
                <h3><?php echo($user);?></h3>
				<h3><img src="../assets/img/robux.png" width="15%"> <font id="updateable"><?php echo ($row['balance']); ?></font></h3>
				<br/>
			</div>
				
            <div class="list-group list-group-flush">
                <a href="./index.php" class="list-group-item active waves-effect">
                    <i class="fa fa-home mr-3"></i>Dashboard</a>
                <a href="./earn.php" class="list-group-item list-group-item-action waves-effect">
                    <i class="fa fa-edit mr-3"></i>Surveys</a>
                <a href="./withdraw.php" class="list-group-item list-group-item-action waves-effect">
                    <i class="fa fa-shopping-cart mr-3"></i>Withdraw</a>
                <a href="#" class="list-group-item list-group-item-action waves-effect">
                    <i class="fab fa-discord mr-3"></i>Discord</a>
            </div>

        </div>
        <!-- Sidebar -->

    </header>
    <!--Main Navigation-->

    <!--Main layout-->
    <main class="pt-5 mx-lg-5">
	
	<!-- Cards -->
        <div class="container-fluid mt-5">
                <!-- First column -->
			    <div class="row mt-lg-5">
                <div class="col">
                    <!--Card-->
                    <div class="card card-cascade cascading-admin-card">

                        <!--Card Data-->
                        <div class="admin-up">
                            <i class="fa fa-money-bill-alt primary-color"></i>
                            <div class="data">
                                <p>Balance</p>
                                <h3 class="font-weight-bold dark-grey-text"><?php echo ($row['balance']); ?> R$</h3>
                            </div>
                        </div>
                        <!--/.Card Data-->

                        <!--Card content-->
                        <div class="card-body">
                            <!--Text-->
                            <p class="card-text">Your current balance.</p>
                        </div>
                        <!--/.Card content-->

                    </div>
                    <!--/.Card-->
                </div>

                <!-- Second column -->
                <div class="col">
                    <!--Card-->
                    <div class="card card-cascade cascading-admin-card">

                        <!--Card Data-->
                        <div class="admin-up">
                            <i class="fa fa-money-bill-wave success-color"></i>
                            <div class="data">
                                <p>Total Earned</p>
                                <h3 class="font-weight-bold dark-grey-text"><?php echo ($row['earned']); ?> R$</h3>
                            </div>
                        </div>
                        <!--/.Card Data-->

                        <!--Card content-->
                        <div class="card-body">
                            <!--Text-->
                            <p class="card-text">Your lifetime earnings.</p>
                        </div>
                        <!--/.Card content-->

                    </div>
                    <!--/.Card-->
                </div>

                <!-- Third column -->
                <div class="col">
                    <!--Card-->
                    <div class="card card-cascade cascading-admin-card">

                        <!--Card Data-->
                        <div class="admin-up">
                            <i class="fa fa-money-bill-wave warning-color"></i>
                            <div class="data">
                                <p>Stock</p>
                                <h3 class="font-weight-bold dark-grey-text"><?php echo ($site['rbx_stock']); ?> R$</h3>
                            </div>
                        </div>
                        <!--/.Card Data-->

                        <!--Card content-->
                        <div class="card-body">
                            <!--Text-->
                            <p class="card-text">Total R$ stock.</p>
                        </div>
                        <!--/.Card content-->

                    </div>
                    <!--/.Card-->
                </div>
            </div>
		</div>
	<!--/.Cards -->
		
            <section class="mb-5">
                <div class="container-fluid mt-5">
                    <div class="row">
					
						<!-- Dice -->
                        <div class="col-md-8">
                            <div class="card white text-center z-depth-2">
                                <div class="card-body">
                                    <p class=" mb-0">Giveaway here</p>
                                </div>
                            </div>
                        </div>
						<!--/.Dice -->

						<!-- Leaderboard -->
						<div class="col-md-4 card card-cascade narrower z-depth-1">
									<div class="view gradient-card-header blue-gradient narrower py-2 mx-4 mb-3 d-flex justify-content-center align-items-center">
										<a href="" class="white-text mx-3">Top Earners</a>
									</div>
									<div class="px-4">
										<div class="table-responsive">
											<!--Table-->
											<table class="table table-hover mb-0">

												<!--Table head-->
												<thead>
													<tr>
														<th class="th"><a href="">#</a></th>							
														<th class="th-lg"><a href="">Username</a></th>
														<th class="th"><a href="">Earned</a></th>
													</tr>
												</thead>
												<!--Table head-->

												<!--Table body-->
												<tbody>
                                                    <?php
                                                    function newrow($place, $username, $earned) {
                                                        echo('
                                                    <tr>
														<td>' . $place . '</td>
														<td>' . $username . '</td>
														<td>' . $earned . '</td>
													</tr>
                                                        ');
                                                    }

                                                    $sql="SELECT * FROM users ORDER BY earned ASC LIMIT 5";
                                                    $result=mysqli_query($link,$sql);
                                                    $users = mysqli_fetch_all($result,MYSQLI_ASSOC);
                                                    $x = 1;
                                                    while ($x < 5) {
                                                        foreach ($users as $user) {
                                                            newrow($x, $user['username'], $user['earned']);
                                                            $x++;
                                                        }
                                                    }
                                                    ?>
												</tbody>
												<!--Table body-->
											</table>
											<!--Table-->
										</div>
									  <hr class="my-0">
									</div>
											</div>
							<!-- Leaderboard -->
										</div>
									</div>
								</div>
							</section>
			
    </main>
    <!--Main layout-->

    <!-- SCRIPTS -->
    <!-- JQuery -->
    <script type="text/javascript" src="../assets/js/jquery-3.3.1.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="../assets/js/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="../assets/js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="../assets/js/mdb.min.js"></script>
    <!-- Initializations -->
    <script type="text/javascript">
        // Animations initialization
        new WOW().init();
    </script>
</body>

</html>
