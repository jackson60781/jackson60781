<?php include('./api/config.php'); ?>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php echo (SITE_NAME);?></title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="assets/css/mdb.min.css" rel="stylesheet">
    <style type="text/css">
        html,
        body,
        header,
        .intro-2 {
          height: 100%;
        }

		body {
	width: automatic;
	height: automatic;
	color: #ffff;
	background: linear-gradient(-45deg, #EE7752, #E73C7E, #23A6D5, #23D5AB);
	background-size: 400% 400%;
	-webkit-animation: Gradient 15s ease infinite;
	-moz-animation: Gradient 15s ease infinite;
	animation: Gradient 15s ease infinite;
}

@-webkit-keyframes Gradient {
	0% {
		background-position: 0% 50%
	}
	50% {
		background-position: 100% 50%
	}
	100% {
		background-position: 0% 50%
	}
}

@-moz-keyframes Gradient {
	0% {
		background-position: 0% 50%
	}
	50% {
		background-position: 100% 50%
	}
	100% {
		background-position: 0% 50%
	}
}

@keyframes Gradient {
	0% {
		background-position: 0% 50%
	}
	50% {
		background-position: 100% 50%
	}
	100% {
		background-position: 0% 50%
	}
}
		
        @media (max-width: 740px) {
          html,
          body,
          header,
          .intro-2 {
            height: 900px;
          }
        }

        @media (min-width: 800px) and (max-width: 850px) {
            html,
            body,
            header,
            .intro-2 {
              height: 980px;
            }
        }
        @media (min-width: 800px) and (max-width: 850px) {
            .navbar:not(.top-nav-collapse) {
                background: #5991fb!important;
            }
            .navbar {
              box-shadow: 0 2px 5px 0 rgba(0,0,0,.16), 0 2px 10px 0 rgba(0,0,0,.12) !important;
            }
        }
    </style>
</head>

<body>

<!--Modal: Login with Avatar Form-->
<div style="position: absolute; top: 50%; transform: translateY(-50%)" class="modal fade" id="modalLogin" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog cascading-modal modal-avatar modal-sm" role="document">
	
        <!--Content-->
        <div class="modal-content">
            <!--Header-->
            <div class="modal-header">
                <img style="" src="https://t3.rbxcdn.com/9c8a62e77cd835b563d04181814dec82" alt="avatar" class="rounded-circle img-responsive">
            </div>
			
            <!--Body-->
            <div class="modal-body text-center mb-1">

                <h5 class="mt-1 mb-2">Login</h5>

                <div class="md-form ml-0 mr-0">
				<form action="api/login.php" method="post">
                    <input type="text" type="text" name="unm" placeholder="ROBLOX Username" class="form-control form-control-sm validate ml-0">
					<input class="btn btn-cyan mt-1" type="submit" value="Submit">
				</form>	
                </div>
		
            </div>

        </div>
        <!--/.Content-->
    </div>
</div>
<!--Modal: Login with Avatar Form-->

    <header>
        <!--Head Section-->
        <section class="view intro-3">
            <div class="container h-100 d-flex justify-content-center align-items-center">
                <div class="row">
                    <div class="offset-lg-1 text-center text-md-left margins">
                        <div class="white-text">
                            <h1 class="h1-responsive intro-title font-weight-bold mt-sm-5 mt-0 mb-4 wow fadeInLeft" data-wow-delay="0.3s">Earn Robux like never before</h1>

                            <h6 class="wow fadeInLeft" data-wow-delay="0.3s"><?php echo (SITE_NAME);?> is a survey site where you can earn ROBUX for compleating simple surveys, watching videos & downloading apps.
                            </h6>
                            <br>
                            <a class="btn btn-white btn-rounded orange-text font-weight-bold ml-lg-0 wow fadeInLeft" data-toggle="modal" data-target="#modalLogin" data-wow-delay="0.4s">
                                Get started</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </header>
    <!-- Head Section -->

    <!-- Main content -->
    <main>

        <!--Information container-->
        <div class="container-fluid" style="background-color: #f4f4fa">
            <div class="container py-4">

                <!--Section: Services-->
                <section class="section mt-3 mb-3 pb-3">

                    <!-- Section heading -->
                    <h3 class="text-center title my-5 pt-4 pb-5 dark-grey-text font-weight-bold wow fadeIn" data-wow-delay="0.2s">
                        <strong>How to get started</strong>
                    </h3>

                    <!-- First row -->
                    <div class="row wow fadeIn" data-wow-delay="0.4s">

                        <!-- First column -->
                        <div class="col-md-4 mb-5 text-center">

                            <!--Panel-->
                            <div class="card card-body text-left white hoverable">
                                <p class="feature-title title font-weight-bold dark-grey-text text-uppercase spacing mt-4 mx-4">
                                    <i class="fa fa-square orange-text mr-2" aria-hidden="true"></i>
                                    <strong>01 Login</strong>
                                </p>
                                <p class="grey-text font-small mx-4">Easily login with your ROBLOX username and start earning, no other information is required</p>
                            </div>
                            <!--/.Panel-->

                        </div>
                        <!-- /First column -->

                        <!-- Second column -->
                        <div class="col-md-4 mb-5 text-center">

                            <!--Panel-->
                            <div class="card card-body text-left white hoverable">
                                <p class="feature-title title font-weight-bold dark-grey-text text-uppercase spacing mt-4 mx-4">
                                    <i class="fa fa-square orange-text mr-2" aria-hidden="true"></i>
                                    <strong>02 Earn</strong>
                                </p>
                                <p class="grey-text font-small mx-4">Watch videos, Download apps and compleate simple surveys to earn ROBUX with our advanced offerwalls</p>
                            </div>
                            <!--/.Panel-->

                        </div>
                        <!-- /.Second column -->

                        <!-- Third column -->
                        <div class="col-md-4 mb-5 text-center">

                            <!--Panel-->
                            <div class="card card-body text-left white hoverable">
                                <p class="feature-title title font-weight-bold dark-grey-text text-uppercase spacing mt-4 mx-4">
                                    <i class="fa fa-square orange-text mr-2" aria-hidden="true"></i>
                                    <strong>03 Claim</strong>
                                </p>
                                <p class="grey-text font-small mx-4">Join our ROBLOX group and withdraw your ROBUX easily with our automatic payout system</p>
                            </div>
                            <!--/.Panel-->

                        </div>
                        <!-- /.Third column -->

                    </div>
                    <!-- /.First row -->

                </section>
        </div>

    </main>
    <!-- Main content -->

    <!--Footer-->
	
        <!-- Copyright-->
        <div class="footer-copyright text-center py-3">
            <div class="container-fluid">
                © 2018 Copyright: <a> <?php echo (SITE_HOST);?> </a>
            </div>
        </div>
        <!--/.Copyright -->

    </footer>
    <!--/.Footer-->

    <!-- JQuery -->
    <script type="text/javascript" src="assets/js/jquery-3.3.1.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="assets/js/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="assets/js/mdb.min.js"></script>
    <script>
        //Animation init
        new WOW().init();

        // Material Select Initialization
        $(document).ready(function () {
            $('.mdb-select').material_select();
        });
    </script>

</body>
</html>