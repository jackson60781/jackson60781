<?php
session_start();
include('config.php');
$link= mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);

   if (!empty($_POST)) 
   {
        extract($_POST);

        if (empty($unm))
        {
            header("location:../index.php");
        }
        else 
         {

                $q ="SELECT * FROM users WHERE username='$unm'";
                $res=mysqli_query($link,$q);
                $row=mysqli_fetch_assoc($res);

                if (empty($row))
                {

                    $sql = "INSERT INTO users (username, balance, earned, rank)
                            VALUES ('$unm', '0', '0', '0')";

                    $result = mysqli_query($link, $sql)
                    or die(header("location:../index.php"));
    
                    if ($result) {

                        $_SESSION['user']=$unm;
                    
                        header("location:../dashboard");
                    } 
                    else {
                        header("location:../index.php");
                    }
        
                }
                else if (!empty($row)) {
                    $_SESSION['user']=$row['username'];
                    header("location:../dashboard");
                }
            }
     }
   else
   {
        header("location:../index.php");
   }

?>