<?php
// Website
define('SITE_HOST', 'localhost'); // Your website url.
define('SITE_NAME', 'SimpleRewards'); // Your website url.
define('SITE_API', 'askmismoforthisyounoob'); // Your website api key.
define('SITE_SECRET', 'generateasecrethere!'); // Your website secret.

// ROBLOX Info
define('_COOKIE', 'X'); 
define('_GROUPID', '0'); 

// Database
define('DB_HOST', 'localhost'); // Your database host (usually 127.0.0.1).
define('DB_USER', 'root'); // Your database user.
define('DB_PASSWORD', ''); // Your database password.
define('DB_NAME', 'simplerewards'); // Your database name.

?>