<?php

// Config
include('config.php');
$secret = SITE_SECRET;

// Parameters
$key = $_GET['key']; 
$offerid = $_GET['offerid']; 
$user = $_GET['user']; 
$ammount = $_GET['ammount']; 

if ($key != $secret) {
  exit;
}

	try 
	{
		// Connect to Database.
		$dbh = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";port=3306", DB_USER, DB_PASSWORD, array( PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING ));
		$stmt = $dbh->prepare("SELECT balance FROM users WHERE username=:username");
		$stmt->bindParam(':username', $user, PDO::PARAM_STR);
		$stmt->execute();
		$oldbal = $stmt->fetchColumn(0);

             if ($oldbal) {

            } else {
              $oldbal = 0;
            } 
		$newbal = $oldbal + $ammount;
		$query = $dbh->prepare("UPDATE users SET `username` = :username, `balance` = :balance WHERE username = :username");
		$query->bindParam(':username', $user, PDO::PARAM_STR);
		$query->bindParam(':balance', $newbal, PDO::PARAM_INT);

		if ($query->execute()) {
			echo "1";
			
			
		} else { 
			echo "0";
		}

	}
	catch (PDOException $e) 
	{
		exit($e->getMessage());
	}

?>