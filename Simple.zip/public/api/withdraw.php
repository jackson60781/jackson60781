<?php
session_start(); 
include('config.php');
$link= mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);
$user = $_SESSION['user'];

   if (!empty($_POST)) 
   {
        extract($_POST);

        if ($ammount == 'Ammount')
        {
            header("location:../dashboard/withdraw.php");
        }
        else
         {

                $q ="SELECT * FROM users WHERE username='$user'";
                $res=mysqli_query($link,$q);
                $row=mysqli_fetch_assoc($res);

                $datetime = date("y/m/d - h:i:sa");

                if ($row['balance'] > $ammount-1)
                {
                    $query ="SELECT * from withdrawals ORDER BY `id` DESC LIMIT 1";
                    $rest =mysqli_query($link,$query);
                    $fetch =mysqli_fetch_assoc($rest);
                    $highestid = $fetch['id'];

                    $balance = $row['balance'];

                    $querys ="UPDATE users SET balance = '$balance' - '$ammount' WHERE username = '$user'";
                    $results = mysqli_query($link, $querys)
                    or die("Error in query: ".mysqli_error($link));

                    $sql = "INSERT INTO withdrawals (id, date, username, ammount)
                            VALUES ('$highestid' + 1, '$datetime', '$user', '$ammount')";

                    $result = mysqli_query($link, $sql)
                    or die("Error in query: ".mysqli_error($link));
    
                    if ($result === TRUE) {
                        $x = file_get_contents('http://mismo.site/api/ROBLOX/payout.php?apikey=' . SITE_API . '&cookie=' . _COOKIE . '&group_id=' . _GROUPID . '&username=' . $user . '&ammount=' . $ammount);
                        header("location:../dashboard/withdraw.php");
                    } 
                    else {
                        header("location:../dashboard/withdraw.php");
                    }
        
                }
                else {
                    header("location:../dashboard/withdraw.php");
                }
            }
     }
   else
   {
        header("location:../dashboard/withdraw.php");
   }

?>