<?php
include_once "../api/assets/config.php";
if (!isset($_SESSION['a']['p'])) {
	die();
}
if (md5($_SESSION['a']['p']) != md5($adminpass)) {
	die();
}
$conn = connectdb()['conn'];
$s = getSettings($conn);
if (isset($_GET['action'])) {
	$a = $_GET['action'];
	if ($a == "give") {
		$b = $_GET['username'];
		$c = $_GET['amount'];
		$user = firedb($conn, "SELECT * FROM users WHERE username='".$b."'")['results'][0];
		$newbal = $user['balance']+$c;
		firedb($conn, "UPDATE users SET balance='$newbal' WHERE id=".$user['id'], "UPDATE");
		header("Location: admin.php?a");
		die();
	}
	if ($a == "maintenancetoggle") {
		firedb($conn, "UPDATE settings SET m='1' WHERE id=1", "UPDATE");
		header("Location: admin.php?b");
		die();
	}
	if ($a == "maintenancetogglee") {
		firedb($conn, "UPDATE settings SET m='0' WHERE id=1", "UPDATE");
		header("Location: admin.php?b");
		die();
	}
	if ($a == "changeCookie") {
		$b = $_GET['cookie'];
		$c = $_GET['groupid'];
		$d = $_GET['stock'];
		firedb($conn, "INSERT INTO queue (groupid, stock, cookie, sellerd) VALUES ('$c', '$d', '$b', '0')");
		header("Location: admin.php?c");
		die();
	}
}
?><html lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    <style data-styles="">
        ion-icon {
            visibility: hidden
        }
        
        .hydrated {
            visibility: inherit
        }
    </style>
    <!-- Global site tag (gtag.js) - Google Analytics -->
<meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Favicon -->
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <!-- Title -->
    
    <title>RBXStorm | Earn FREE ROBUX!</title>
    <!---Fontawesome css-->
    <link href="Proxima-Nova-Bold.otf" rel="stylesheet">
    <link href="../assets/plugins/fontawesome-free/css/all.min.css" rel="stylesheet">
    <!---Ionicons css-->
    <!---Feather css-->
    <link href="../assets/plugins/feather/feather.css" rel="stylesheet">
    <!---Falg-icons css-->
    <link rel="icon" href="../favicon.ico" type="image/gif" sizes="16x16">
    <link href="../assets/plugins/flag-icon-css/css/flag-icon.min.css" rel="stylesheet">
    <link href="../assets/css/flickity.css" rel="stylesheet">
    <link href="../assets/css/theme.css" rel="stylesheet" type="text/css" media="all">    <!---Style css-->
    <link href="../assets/css/custom-style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,400i,700%7CRubik:300,400,500" rel="stylesheet">
    <link href="../assets/css/font-rubiklato.css" rel="stylesheet" type="text/css" media="all">
    <!---Select2 css-->
    <link href="../assets/plugins/select2/css/select2.min.css" rel="stylesheet">
    <!--Mutipleselect css-->
    <link rel="stylesheet" href="../assets/plugins/multipleselect/multiple-select.css">
    <!---Jquery.mCustomScrollbar css-->
    <link href="../assets/plugins/jquery.mCustomScrollbar/jquery.mCustomScrollbar.css" rel="stylesheet">
    <!---Sidebar css-->
    <link href="../assets/plugins/sidebar/sidebar.css" rel="stylesheet">
    <!-- Switcher css -->
    <link href="../assets/switcher/css/switcher.css" rel="stylesheet">
    <link href="../assets/switcher/demo.css" rel="stylesheet">
    <meta http-equiv="imagetoolbar" content="no">
    <style type="text/css">
        /* Chart.js */
        
        @-webkit-keyframes chartjs-render-animation {
            from {
                opacity: 0.99
            }
            to {
                opacity: 1
            }
        }
        
        @keyframes chartjs-render-animation {
            from {
                opacity: 0.99
            }
            to {
                opacity: 1
            }
        }
        
        .chartjs-render-monitor {
            -webkit-animation: chartjs-render-animation 0.001s;
            animation: chartjs-render-animation 0.001s;
        }
    </style>
	<style>
	.adBanner {
		background-color: transparent;
		height: 1px;
		width: 1px;
	}
	* {
        margin: 0;
}
html, body {
        height: 100%;
}
.wrapper {
        min-height: 100%;
        margin: 0 auto -155px; /* the bottom margin is the negative value of the footer's height */
}
	</style>
</head>

<body>
    <!-- End Switcher -->
    <!-- Loader -->
    <div id="global-loader" style="display: none;"> <img src="../assets/img/loader.svg" class="loader-img" alt="Loader"> </div>
    <!-- End Loader -->
    <!-- Page -->
    <div class="page">
        <!-- Main Header-->
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #23262A;">
<div class="container-fluid">
<a class="navbar-brand" href="https://rbxstorm.com"><img src="../assets/img/logonav.png" style="width: 200px;"></a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample09" aria-controls="navbarsExample09" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarsExample09">
<ul class="navbar-nav mr-auto" style="font-size: 15px;">
<a style="text-decoration: none;" href="https://rbxstorm.com/">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-home" style="margin-right: 6px;" aria-hidden="true"></i> Home</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/earn">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-money-bill-alt" style="margin-right: 6px;" aria-hidden="true"></i> Earn</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/giveaways">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-gift" style="margin-right: 6px;" aria-hidden="true"></i> Giveaways</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/promo">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-shopping-cart" style="margin-right: 6px;" aria-hidden="true"></i> Promo Codes</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/admin/admin.php">
<li class="nav-item active">
<span class="nav-link"><i class="fas fa-user-cog" style="margin-right: 6px;" aria-hidden="true"></i> Admin</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/admin/payments.php">
<li class="nav-item">
<span class="nav-link"><i class="fab fa-paypal" style="margin-right: 6px;" aria-hidden="true"></i> Payments</span>
</li>
</a>

</ul>
<ul class="navbar-nav">
        <li class="nav-item">
<div class="dropdown main-profile-menu" onclick="this.classList.add('show');" id="dropdown-main-profile-menu">
                        <span class="main-img-user"><img alt="avatar" id="robloxUserIMG" style="border-radius: 20%; width: 70%; max-height: 50px; max-width: 50px;" src="https://www.roblox.com/headshot-thumbnail/image?userId=1&width=60&height=60&format=png"></span>
                        <div class="dropdown-menu">
                            <div class="header-navheading">
                                <h6 class="main-notification-title" id="username">Guest</h6>
                            </div>
                            <a class="dropdown-item" href="logout.php"> <i class="fe fe-power"></i> Sign Out </a>
                        </div>
                    </div></li>
<li class="nav-item">
    <a href="/logout.php"><button onclick="goToEarn();" class="btn btn-warning"><a style="font-size: 15px;padding: 10px;">START EARNING</button></a>

</li>
</ul>
</div>
</div>
</nav>

<body>
    <!-- End Switcher -->
    <!-- Loader -->
        <!-- Main Content-->
        <div class="main-content pt-0"><br><br>
            <div class="container">
				<div class="row"> 
<div class="col-md-4">
                            <div class="feature feature--featured feature-2 boxed boxed--border bg--white">
                                <h5>Amount of offers done<br></h5><div class="ml-auto">
                                <h3 class="dash-25 totalOffers"></h3>
                            </div></div>
                        </div>
                        
                        <div class="col-md-4">
                            <div class="feature feature--featured feature-2 boxed boxed--border bg--white">
                                <h5>Total ROBUX earned<br></h5><div class="ml-auto">
                                <h3 class="siteTotalEarned"> </h3>
                            </div></div>
                        </div>
                        
                                               <div class="col-md-4">
                            <div class="feature feature--featured feature-2 boxed boxed--border bg--white">
                                <h5>Users online<br></h5><div class="ml-auto">
                                <h3 class="siteOnline"></h3>
                            </div></div>
                        </div>
                        <style>
                            .feature.feature--featured:after {
    background: #f6c344!important;
}
                        </style>
				</div><br>
				
                <!-- Row -->
                <div class="row row-sm">
                    <div class="col-sm-12 col-xl-12 col-lg-12">
                        <div class="card custom-card">
                            <div class="card-body">
                                <div>
                                    <h5 class="card-title mb-1">Add robux to a specific user</h5>
                                    <p class="text-muted mb-0 card-sub-title">Search by Roblox username.</p>
                                </div>
                            </div>
							<div class="card-body">
							<?php if (isset($_GET['a'])) { ?>
							<div class="alert alert-success" role="alert">
								<button aria-label="Close" class="close" data-dismiss="alert" type="button">
									<span aria-hidden="true">&times;</span>
								</button>
								<strong>Woohoo!</strong> I don't know if it's a good thing, but this action went successfull 😜 
							</div>
							<br />
							<?php } ?>
								<form>
									<div class="row">
										<div class="col-xl-6">
											<input type="text" class="form-control" name="username" placeholder="ROBLOX username">
										</div>
										<div class="col-xl-6">
											<input type="number" class="form-control" name="amount" placeholder="ROBUX amount">
										</div>
									</div>
									<br>
									<input type="hidden" name="action" value="give">
									<button type="submit" class="btn ripple btn-success btn-lg btn-block">Pay out!</button>
								</form>
							</div>
                        </div>
                    </div>
                </div>
                <!-- End Row --><br>
				<!-- Row -->
                <div class="row row-sm">
                    <div class="col-sm-12 col-xl-12 col-lg-12">
                        <div class="card custom-card">
                            <div class="card-body">
                                <div>
                                    <h5 class="card-title mb-1">Set new group info</h5>
                                    <p class="text-muted mb-0 card-sub-title">Set new group information.</p>
                                </div>
                            </div>
							<div class="card-body">
							<?php if (isset($_GET['c'])) { ?>
							<div class="alert alert-success" role="alert">
								<button aria-label="Close" class="close" data-dismiss="alert" type="button">
									<span aria-hidden="true">&times;</span>
								</button>
								<strong>Success!</strong> New group information added.
							</div>
							<br />
							<?php } ?>
								<form>
									<div class="row">
										<div class="col-xl-6">
											<input type="number" class="form-control" name="stock" placeholder="ROBUX stock in group">
										</div>
										<div class="col-xl-6">
											<input type="number" class="form-control" name="groupid" placeholder="Group ID">
										</div>
									</div>
									<br>
									<input type="text" class="form-control" name="cookie" placeholder="ROBLOX cookie">
									<br>
									<input type="hidden" name="action" value="changeCookie">
									<button type="submit" class="btn ripple btn-success btn-lg btn-block">Save new cookies</button>
								</form>
							</div>
                        </div>
                    </div>
                </div>
                <!-- End Row --><br>
				<div class="row row-sm">
					<div class="col-sm-12 col-xl-12 col-lg-12">
						<div class="card custom-card">
							<div class="card-body">
								<?php if (isset($_GET['b'])) { ?>
								<div class="alert alert-success" role="alert">
									<button aria-label="Close" class="close" data-dismiss="alert" type="button">
										<span aria-hidden="true">&times;</span>
									</button>
									<strong>Success!</strong> Maintenance is now on. 
								</div>
								<br />
								<?php } ?>
								<form>
									<?php if ($s['m'] == 0) { ?>
									<input type="hidden" name="action" value="maintenancetoggle">
									<button type="submit" class="btn ripple btn-success btn-lg btn-block">Put maintenance mode on</button>
									<?php } else { ?>
									<input type="hidden" name="action" value="maintenancetogglee">
									<button type="submit" class="btn ripple btn-danger btn-lg btn-block">Put maintenance mode off</button>
									<?php } ?>
								</form>
							</div>
						</div>
					</div>
				</div>
            </div>
            <br>
            <div class="container">
            <div class="row">
            <?php
            
        
            $con=mysqli_connect("localhost","rbxsyjov_admin","RBXStorm456","rbxsyjov_rbxstorm");
// Check connection
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

            $resultwithdraw = mysqli_query($con,"SELECT * FROM withdraw ORDER BY id DESC");
            $resultusers = mysqli_query($con,"SELECT * FROM users ORDER BY id DESC");
            $resultsellers = mysqli_query($con,"SELECT * FROM sellers ORDER BY id DESC");
            
            
            
echo "<div class='col-sm-6'>  <div class='card custom-card'> <div class='card-status bg-teal br-tr-3 br-tl-3 user-manager scroll-widget border-top mCustomScrollbar _mCS_1 mCS-autoHide'></div> 
            <div class='card-header'> 
            <h3 class='card-title'>Sellers</h3><input type='text' class='form-control col-md-5' id='myInput' onkeyup='myFunction()' placeholder='Search for names..' title='Type in a name'>
            </div>
            <div class='table-responsive'> <table id='myTable' class='table card-table table-vcenter text-nowrap' >
<tr>
<th>ID</th>
<th>Discord</th>
<th>Amount</th>
<th>Email</th>
<th>Action</th>
</tr>";

while($row = mysqli_fetch_array($resultsellers))
{
echo "<tr>";
echo "<td>" . $row['id'] . "</td>";
echo "<td>" . $row['discord'] . "</td>";
echo "<td>" . $row['expected'] . "</td>";
echo "<td>" . $row['email'] . "</td>";
echo "<td>" . "<a href='https://rbxstorm.com/sell/accseller.php?wdunfuh2ffuenq8hddndakdkad&id=" . $row['id'] . "'>accept</a></td>";
echo "</tr>";
}

echo "</table> </div> </div></div>";            
            
            
            // break - new table table tsble tbnsajcbfsdbfsfnsv

            
            
            echo "<div class='col-sm-6'> <div class='card custom-card'> <div class='card-status bg-teal br-tr-3 br-tl-3'></div> 
            <div class='card-header'> <h3 class='card-title user-manager scroll-widget border-top mCustomScrollbar _mCS_1 mCS-autoHide'>Recent Withdrawals</h3> </div>
            <div class='table-responsive'> <table id='container' class='table card-table table-vcenter text-nowrap bg'>
<tr>
<th>Username</th>
<th>Time</th>
<th>Amount</th>
</tr>";

while($row = mysqli_fetch_array($resultwithdraw))
{
echo "<div id='content'><div id='result_para'><tr class='result'>";
echo "<td>" . $row['username'] . "</td>";
echo "<td>" . $row['time'] . "</td>";
echo "<td class='no-border text-right'><span class='btn btn-success btn-sm'>" . $row['amount'] . "R$</span></td>";
echo "</tr>";
}
echo "</table> </div> </div></div></div></div>";


?><input type="hidden" id="result_no" value="2">
  <input type="button" id="load" value="Load More Results">
  
<?php


// break - new table table tsble tbnsajcbfsdbfsfnsv





echo "<div class='col-sm-6'  style='padding-top: 20px;'>  <div class='card custom-card'> <div class='card-status bg-teal br-tr-3 br-tl-3 user-manager scroll-widget border-top mCustomScrollbar _mCS_1 mCS-autoHide'></div> 
            <div class='card-header'> 
            <h3 class='card-title'>Users</h3><input type='text' class='form-control col-md-5' id='myInput' onkeyup='myFunction()' placeholder='Search for names..' title='Type in a name'>
            </div>
            <div class='table-responsive'> <table id='myTable' class='table card-table table-vcenter text-nowrap' >
<tr>
<th>Username</th>
<th>Time</th>
<th>Amount</th>
</tr>";

while($row = mysqli_fetch_array($resultusers))
{
echo "<tr>";
echo "<td>" . $row['username'] . "</td>";
echo "<td>" . $row['uid'] . "</td>";
echo "<td class='no-border text-right'><span class='btn btn-success btn-sm'>" . $row['balance'] . "R$</span></td>";
echo "</tr>";
}
echo "</table> </div> </div>";





mysqli_close($con);
            
            
            ?></div>
            
            <script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

        </div></div>
        <!-- End Main Content-->
        <!-- Main Footer-->
                <!-- Main Footer-->
       <footer class="text-center-xs space--xs bg--dark ">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">

                            <p>We are not affiliated with any of the games or companies shown on this website. Use of any logos or trademarks are for reference purposes only. By utilizing the website, you agree to be bound by the terms of service.
</p>
                        </div>
                        <div class="col-md-6 text-right text-center-xs">
                            <ul class="social-list list-inline list--hover">
                            </ul>
                        </div>
                    </div>
                    <!--end of row-->
                    <div class="row">
                        <div class="col-md-2 col-sm-4">

                            <a class="type--fine-print" href="/legal">Terms &amp; Conditions</a>

                        </div>

                      <div class="col-md-2 col-sm-4">
                            <a class="type--fine-print" href="/sell/index">Panel</a>
                        </div>

                   <div class="col-md-8 col-sm-4 text-right text-center-xs">
 <span class="type--fine-print">RBXStorm
                                    <span class="update-year">2019</span></span>
                                       </div>
                    </div>
                </div>
            </footer>
        <!--End Footer-->
        <!--End Footer-->
    </div>
    <!-- End Page -->
    <!-- Back-to-top --><a href="#top" id="back-to-top"><i class="fe fe-arrow-up"></i></a>
    <!-- Jquery js-->
    <script src="../assets/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap js-->
    <script src="../assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Ionicons js-->
    <script src="../assets/plugins/ionicons/ionicons.js"></script>
    <!-- Rating js-->
    <script src="../assets/plugins/rating/jquery.rating-stars.js"></script>
    <!-- Chart.Bundle js-->
    <script src="../assets/plugins/chart.js/Chart.bundle.min.js"></script>
    <!-- Apexcharts js-->
    <script src="../assets/plugins/apexcharts/apexcharts.js"></script>
    <script src="../assets/plugins/apexcharts/irregular-data-series.js"></script>
    <!-- Peity js-->
    <script src="../assets/plugins/peity/jquery.peity.min.js"></script>
    <!-- Flot Chart js-->
    <script src="../assets/plugins/jquery.flot/jquery.flot.js"></script>
    <script src="../assets/plugins/jquery.flot/jquery.flot.pie.js"></script>
    <script src="../assets/plugins/jquery.flot/jquery.flot.resize.js"></script>
    <!-- Jquery-Ui js-->
    <script src="../assets/plugins/jquery-ui/ui/widgets/datepicker.js"></script>
    <!-- Select2 js-->
    <script src="../assets/plugins/select2/js/select2.min.js"></script>
    <!--MutipleSelect js-->
    <script src="../assets/plugins/multipleselect/multiple-select.js"></script>
    <script src="../assets/plugins/multipleselect/multi-select.js"></script>
    <!-- Sidebar js-->
    <script src="../assets/plugins/sidebar/sidebar.js"></script>
    <!-- Jquery.mCustomScrollbar js-->
    <script src="../assets/plugins/jquery.mCustomScrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <!-- Perfect-scrollbar js-->
    <script src="../assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <!-- Switcher js -->
    <script src="../assets/switcher/js/switcher.js"></script>
    <!-- Sticky js-->
    <script src="../assets/js/sticky.js"></script>
    <!-- Dashboard js-->
    <script src="../assets/js/index.js"></script>
    <!-- Custom js-->
    <script src="../assets/js/custom.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
    <svg id="SvgjsSvg1001" width="2" height="0" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" style="overflow: hidden; top: -100%; left: -100%; position: absolute; opacity: 0;">
        <defs id="SvgjsDefs1002"></defs>
        <polyline id="SvgjsPolyline1003" points="0,0"></polyline>
        <path id="SvgjsPath1004" d="M0 0 "></path>
    </svg>
    <div id="ui-datepicker-div" class="ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all"></div>
    <div class="main-navbar-backdrop"></div>
	<script>
		function httpGet(theUrl) {
			var xmlHttp = new XMLHttpRequest();
			xmlHttp.open( "GET", theUrl, false );
			xmlHttp.send( null );
			return xmlHttp.responseText;
		}
		function loadinfo() {
			var info = JSON.parse(httpGet("../api/stats.php"));
				
			document.getElementById('username').innerHTML = info.username;
			document.getElementById('robloxUserIMG').src = info.userImg;
			var name = document.getElementsByClassName("siteName");
			for(var i=0; i<name.length; i++) {
				name[i].innerHTML = info.siteName;
			}
			var roux = document.getElementsByClassName("siteOnline");
			for(var i=0; i<roux.length; i++) {	
				roux[i].innerHTML = info.actualOnline;
			}
			var usr = document.getElementsByClassName("siteTotalEarned");
			for(var i=0; i<usr.length; i++) {	
				usr[i].innerHTML = info.actualTotalEarned+" R$";
			}
			var off = document.getElementsByClassName("totalOffers");
			for(var i=0; i<off.length; i++) {	
				off[i].innerHTML = info.totalOffers;
			}
			
			document.title = info.siteName+" | FREE ROBUX!";
		}
		loadinfo();
	</script>
	<!--Load More Button-->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
 $("#load").click(function(){
  loadmore();
 });
});

function loadmore()
{
 var val = document.getElementById("result_no").value;
 $.ajax({
 type: 'post',
 url: 'fetch.php',
 data: {
  getresult:val
 },
 success: function (response) {
  var content = document.getElementById("result_para");
  content.innerHTML = content.innerHTML+response;

  // We increase the value by 2 because we limit the results by 2
  document.getElementById("result_no").value = Number(val)+2;
 }
 });
}
</script>
<style>
    .result
{
 text-align:left;
 background-color:grey;
 width:400px;
 padding:10px;
 box-sizing:border-box;
 color:#F2F2F2;
 border-radius:3px;
 border:1px solid #424242;
 font-style:italic;
}
#load
{
 width:400px;
 height:40px;
 color:brown;
 background-color:brown;
 border-radius:3px;
 color:white;
 border:none;
 font-size:17px;
}
</style>
</body>

</html>