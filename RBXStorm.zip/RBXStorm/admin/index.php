<?php
session_start();
if (isset($_GET['p'])) {
	$_SESSION['a']['p'] = $_GET['p'];
	header('Location: https://rbxstorm.com/admin/payments.php');
}
?>
<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <style>
        body {
            margin-top: 65px;
        }
    </style>
</head>

<body>

    <div class="container">
        <div class="card col-5" style="margin: auto; background: rgba(0,0,0,.03); padding-bottom: 20px;">

            <form id="your_form" onsubmit="yourFunction()">
                <img src="http://rbxstorm.com/logo.png" width="95%" height="auto" style="margin: auto;">
                <div style="margin-top: 10px;">
                    <label>Password</label>
                    <div style="width: 100%;">
                        <input type="text" name="p" class="form-control">
                    </div>
                </div>
                <button type="submit" value="search" class="btn btn-lg btn-block" style="background-color: rgb(2, 183, 87); color: rgb(255, 255, 255); margin-top: 24px;">Login</button>
            </form>
        </div>
    </div>

</body>
<script>
    function yourFunction() {

        var action_src = $("p").val();
        var your_form = $('your_form').val();

        var urlLink = "http://rbxstorm.com/admin/index.php";
        urlLink = urlLink + action_src;

        your_form.action = urlLink;

    }
</script>

</html>