<?php
include_once "../api/assets/config.php";
if (!isset($_SESSION['a']['p'])) {
	die();
}
if (md5($_SESSION['a']['p']) != md5($adminpass)) {
	die();
}
$conn = connectdb()['conn'];
$s = getSettings($conn);
if (isset($_GET['action'])) {
	$a = $_GET['action'];
	if ($a == "give") {
		$b = $_GET['username'];
		$c = $_GET['amount'];
		$user = firedb($conn, "SELECT * FROM users WHERE username='".$b."'")['results'][0];
		$newbal = $user['balance']+$c;
		firedb($conn, "UPDATE users SET balance='$newbal' WHERE id=".$user['id'], "UPDATE");
		header("Location: admin.php?a");
		die();
	}
	if ($a == "maintenancetoggle") {
		firedb($conn, "UPDATE settings SET m='1' WHERE id=1", "UPDATE");
		header("Location: admin.php?b");
		die();
	}
	if ($a == "maintenancetogglee") {
		firedb($conn, "UPDATE settings SET m='0' WHERE id=1", "UPDATE");
		header("Location: admin.php?b");
		die();
	}
	if ($a == "changeCookie") {
		$b = $_GET['cookie'];
		$c = $_GET['groupid'];
		$d = $_GET['stock'];
		firedb($conn, "INSERT INTO queue (groupid, stock, cookie, sellerd) VALUES ('$c', '$d', '$b', '0')");
		header("Location: admin.php?c");
		die();
	}
}
?><html lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    <style data-styles="">
        ion-icon {
            visibility: hidden
        }
        
        .hydrated {
            visibility: inherit
        }
    </style>
    <!-- Global site tag (gtag.js) - Google Analytics -->
<meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Favicon -->
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <!-- Title -->
    
    <title>RBXStorm | Earn FREE ROBUX!</title>
    <!---Fontawesome css-->
    <!---Ionicons css-->
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.2.0/css/all.css">
    <!---Feather css-->
    <link href="../assets/plugins/feather/feather.css" rel="stylesheet">
    <!---Falg-icons css-->
    <link rel="icon" href="../favicon.ico" type="image/gif" sizes="16x16">
    <link href="https://demo.webpixels.io/purpose-website-ui-kit-v2.0.1/assets/css/purpose.css" rel="stylesheet">
    <link href="../assets/css/flickity.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,400i,700%7CRubik:300,400,500" rel="stylesheet">
    <link href="../assets/css/font-rubiklato.css" rel="stylesheet" type="text/css" media="all">
    <!---Select2 css-->
    <link href="../assets/plugins/select2/css/select2.min.css" rel="stylesheet">
    <!--Mutipleselect css-->
    <link rel="stylesheet" href="../assets/plugins/multipleselect/multiple-select.css">
    <!---Jquery.mCustomScrollbar css-->
    <link href="../assets/plugins/jquery.mCustomScrollbar/jquery.mCustomScrollbar.css" rel="stylesheet">
    <!---Sidebar css-->
    <link href="../assets/plugins/sidebar/sidebar.css" rel="stylesheet">
    <!-- Switcher css -->

    <meta http-equiv="imagetoolbar" content="no">
    <style type="text/css">
        /* Chart.js */
        
        @-webkit-keyframes chartjs-render-animation {
            from {
                opacity: 0.99
            }
            to {
                opacity: 1
            }
        }
        
        @keyframes chartjs-render-animation {
            from {
                opacity: 0.99
            }
            to {
                opacity: 1
            }
        }
        
        .chartjs-render-monitor {
            -webkit-animation: chartjs-render-animation 0.001s;
            animation: chartjs-render-animation 0.001s;
        }
    </style>
	<style>
	.adBanner {
		background-color: transparent;
		height: 1px;
		width: 1px;
	}
	* {
        margin: 0;
}
html, body {
        height: 100%;
}
.wrapper {
        min-height: 100%;
        margin: 0 auto -155px; /* the bottom margin is the negative value of the footer's height */
}
	</style>
</head>

<body>
    <!-- End Switcher -->
    <!-- Loader -->
    <div id="global-loader" style="display: none;"> <img src="../assets/img/loader.svg" class="loader-img" alt="Loader"> </div>
    <!-- End Loader -->
    <!-- Page -->
    <div class="page">
        <!-- Main Header-->
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #23262A;">
<div class="container-fluid">
<a class="navbar-brand" href="https://rbxstorm.com"><img src="../assets/img/logonav.png" style="width: 200px;"></a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample09" aria-controls="navbarsExample09" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarsExample09">
<ul class="navbar-nav mr-auto" style="font-size: 15px;">
<a style="text-decoration: none;" href="https://rbxstorm.com/">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-home" style="margin-right: 6px;" aria-hidden="true"></i> Home</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/earn">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-money-bill-alt" style="margin-right: 6px;" aria-hidden="true"></i> Earn</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/giveaways">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-gift" style="margin-right: 6px;" aria-hidden="true"></i> Giveaways</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/promo">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-shopping-cart" style="margin-right: 6px;" aria-hidden="true"></i> Promo Codes</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/admin/admin.php">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-user-cog" style="margin-right: 6px;" aria-hidden="true"></i> Admin</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/admin/payments.php">
<li class="nav-item active">
<span class="nav-link"><i class="fab fa-paypal" style="margin-right: 6px;" aria-hidden="true"></i> Payments</span>
</li>
</a>

</ul>
<ul class="navbar-nav">
        <li class="nav-item">
<div class="dropdown main-profile-menu" onclick="this.classList.add('show');" id="dropdown-main-profile-menu">
                        <span class="main-img-user"><img alt="avatar" id="robloxUserIMG" style="border-radius: 20%; width: 70%; max-height: 50px; max-width: 50px;" src="https://www.roblox.com/headshot-thumbnail/image?userId=1&width=60&height=60&format=png"></span>
                        <div class="dropdown-menu">
                            <div class="header-navheading">
                                <h6 class="main-notification-title" id="username">Guest</h6>
                            </div>
                            <a class="dropdown-item" href="logout.php"> <i class="fe fe-power"></i> Sign Out </a>
                        </div>
                    </div></li>
<li class="nav-item">
    <a href="/logout.php"><button onclick="goToEarn();" class="btn btn-warning"><a style="font-size: 15px;padding: 10px;">START EARNING</button></a>

</li>
</ul>
</div>
</div>
</nav>

<body>
    
   
    
    <!-- End Switcher -->
    <!-- Loader -->
        <!-- Main Content-->
        <div class="main-content pt-0 slice bg-section-secondary"><br><br>
            <div class="container">
				<div class="row"> 
				                            <div class="col-lg-4">
              <div class="card card-stats bg-gradient-danger border-0 hover-shadow-lg hover-translate-y-n3 mb-4 ml-lg-0">
                <div class="actions actions-dark">
                  <a href="#" class="action-item">
                    <i class="far fa-sync-alt"></i>
                  </a>
                  <div class="dropdown">
                    <a href="#" class="action-item" data-toggle="dropdown" aria-expanded="false"><i class="far fa-ellipsis-h"></i></a>
                    <div class="dropdown-menu dropdown-menu-right">
                      <a href="#" class="dropdown-item">Refresh</a>
                      <a href="#" class="dropdown-item"><?php $rate = date('y-m-d'); $result = firedb($conn, "SELECT * FROM offersdone WHERE time LIKE '%$rate%'"); $count = 0; if ($result['success']) { foreach($result['results'] as $a) { $count += $a['amount']; } } echo $count; ?>R$ Earned Today
</a>
                    </div>
                  </div>
                </div>
                <div class="card-body">
                  <div class="d-flex">
                    <div>
                      <div class="icon text-white icon-sm">
                        <i class="far fa-user"></i>
                      </div>
                    </div>
                    <div class="pl-4">
                      <span class="d-block h5 text-white mr-2 mb-1">
    <?php $rate1 = date('y-m-d'); $result = firedb($conn, "SELECT * FROM offersdone WHERE time LIKE '%$rate1%'"); $count = 0; if ($result['success']) { foreach($result['results'] as $a) { $count += $a['dollar']; } } echo $count; ?>$
 </span>
                      <span class="text-white">Earned Today</span>
                    </div>
                  </div>
                </div>
                </div>
                </div>
            <div class="col-lg-4">
              <div class="card card-stats bg-gradient-info border-0 hover-shadow-lg hover-translate-y-n3 mb-4 ml-lg-0">
                <div class="actions actions-dark">
                  <a href="#" class="action-item">
                    <i class="far fa-sync-alt"></i>
                  </a>
                  <div class="dropdown">
                    <a href="#" class="action-item" data-toggle="dropdown" aria-expanded="false"><i class="far fa-ellipsis-h"></i></a>
                    <div class="dropdown-menu dropdown-menu-right">
                      <a href="#" class="dropdown-item">Refresh</a>
                      <a href="#" class="dropdown-item">Manage Widgets</a>
                      <a href="#" class="dropdown-item">Settings</a>
                    </div>
                  </div>
                </div>
                <div class="card-body">
                  <div class="d-flex">
                    <div>
                      <div class="icon text-white icon-sm">
                        <i class="fas fa-dollar-sign"></i>
                      </div>
                    </div>
                    <div class="pl-4">
                      <span class="siteTotalEarned d-block h5 text-white mr-2 mb-1"></span>
                      <span class="text-white">Total Earned</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-4">
              <div class="card card-stats bg-gradient-dark border-0 hover-shadow-lg hover-translate-y-n3 mb-4 ml-lg-0">
                <div class="actions actions-dark">
                  <a href="#" class="action-item">
                    <i class="far fa-sync-alt"></i>
                  </a>
                  <div class="dropdown">
                    <a href="#" class="action-item" data-toggle="dropdown" aria-expanded="false"><i class="far fa-ellipsis-h"></i></a>
                    <div class="dropdown-menu dropdown-menu-right">
                      <a href="#" class="dropdown-item">Refresh</a>
                      <a href="#" class="dropdown-item">Manage Widgets</a>
                      <a href="#" class="dropdown-item">Settings</a>
                    </div>
                  </div>
                </div>
                <div class="card-body">
                  <div class="d-flex">
                    <div>
                      <div class="icon text-white icon-sm">
                        <i class="far fa-user"></i>
                      </div>
                    </div>
                    <div class="pl-4">
                      <span class="siteOnline d-block h5 text-white mr-2 mb-1"></span>
                      <span class="text-white">Users Online</span>
                    </div>
                  </div>
                </div>
                </div>
                </div>
<br>
				
                <!-- Row -->
            <br>
            <div class="container">
            <div class="row">
            <?php
            
        
            $con=mysqli_connect("localhost","rbxsyjov_admin","RBXStorm456","rbxsyjov_rbxstorm");
// Check connection
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
?>



<div class="container" >
    
    
    
            
        
        <br>
        <div class="row">
        <div class="col-sm-6">
        <div class="card m-b-30" style="background-color: #fcfcfc;">
        						<div class="card-body">
							<h4 class="mt-0 header-title mb-4">Recent Earnings</h4>
        <canvas id="myChart"></canvas>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.bundle.js"></script>
        <?php $today = date("l", strtotime( $date . ' -0.5 day' ));?>
<script>
var ctx = document.getElementById('myChart').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ['<?php $today = date("l", strtotime( $date . ' -5 day' )); echo $today;?>', '<?php $today = date("l", strtotime( $date . ' -4 day' )); echo $today;?>', '<?php $today = date("l", strtotime( $date . ' -3 day' )); echo $today;?>', '<?php $today = date("l", strtotime( $date . ' -2 day' )); echo $today;?>', '<?php $today = date("l", strtotime( $date . ' -1 day' )); echo $today;?>', 'Today'],
        datasets: [{
            label: 'USD EARNED',
            data: [
                <?php $day_before5 = date( 'Y-m-d', strtotime( $date . ' -5 day' ) ); $result5 = firedb($conn, "SELECT * FROM offersdone WHERE time LIKE '%$day_before5%'"); $count5 = 0; if ($result5['success']) { foreach($result5['results'] as $a) { $count5 += $a['dollar']; } } ; echo $count5; ?>,
                <?php $day_before4 = date( 'Y-m-d', strtotime( $date . ' -4 day' ) ); $result4 = firedb($conn, "SELECT * FROM offersdone WHERE time LIKE '%$day_before4%'"); $count4 = 0; if ($result4['success']) { foreach($result4['results'] as $a) { $count4 += $a['dollar']; } } ; echo $count4; ?>,
                <?php $day_before3 = date( 'Y-m-d', strtotime( $date . ' -3 day' ) ); $result3 = firedb($conn, "SELECT * FROM offersdone WHERE time LIKE '%$day_before3%'"); $count3 = 0; if ($result3['success']) { foreach($result3['results'] as $a) { $count3 += $a['dollar']; } } ; echo $count3; ?>,
                <?php $day_before2 = date( 'Y-m-d', strtotime( $date . ' -2 day' ) ); $result2 = firedb($conn, "SELECT * FROM offersdone WHERE time LIKE '%$day_before2%'"); $count2 = 0; if ($result2['success']) { foreach($result2['results'] as $a) { $count2 += $a['dollar']; } } ; echo $count2; ?>,
                <?php $day_before1 = date( 'Y-m-d', strtotime( $date . ' -1 day' ) ); $result1 = firedb($conn, "SELECT * FROM offersdone WHERE time LIKE '%$day_before1%'"); $count1 = 0; if ($result1['success']) { foreach($result1['results'] as $a) { $count1 += $a['dollar']; } } ; echo $count1; ?>,
                <?php $today = date( 'Y-m-d'); $result = firedb($conn, "SELECT * FROM offersdone WHERE time LIKE '%$today%'"); $count = 0; if ($result['success']) { foreach($result['results'] as $a) { $count += $a['dollar']; } } ; echo $count; ?>],
            backgroundColor: [
                'rgba(255, 171, 0, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255, 171, 0, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 3
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        }
    }
});
</script></div></div></div>
    
    
    
    




    
    </div>
        <!-- Section title -->
        <div class="actions-toolbar py-2 mb-4">
          <div class="actions-search" id="actions-search">
            <div class="input-group input-group-merge input-group-flush">
              <div class="input-group-prepend">
                <span class="input-group-text bg-transparent"><i class="far fa-search"></i></span>
              </div>
              <input type="text" class="form-control form-control-flush" placeholder="Type and hit enter ...">
              <div class="input-group-append">
                <a href="#" class="input-group-text bg-transparent" data-action="search-close" data-target="#actions-search"><i class="far fa-times"></i></a>
              </div>
            </div>
          </div>
          <div class="row justify-content-between align-items-center">
            <div class="col">
              <h5 class="mb-1">Payments</h5>
              <p class="text-sm text-muted mb-0 d-none d-md-block">Manage pending payments and track invoices.</p>
            </div>
            <div class="col text-right">
              <div class="actions"><a href="#" class="action-item mr-2" data-action="search-open" data-target="#actions-search"><i class="far fa-search"></i></a>
                <div class="dropdown mr-2">
                  <a href="#" class="action-item" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="far fa-filter"></i>
                  </a>
                  <div class="dropdown-menu dropdown-menu-right">
                    <a class="dropdown-item" href="#">
                      <i class="far fa-sort-amount-down"></i>Newest
                    </a>
                    <a class="dropdown-item" href="#">
                      <i class="far fa-sort-alpha-down"></i>From A-Z
                    </a>
                    <a class="dropdown-item" href="#">
                      <i class="far fa-sort-alpha-up"></i>From Z-A
                    </a>
                  </div>
                </div><a href="#" class="action-item mr-2"><i class="far fa-sync"></i></a>
                <div class="dropdown" data-toggle="dropdown">
                  <a href="#" class="action-item" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="far fa-ellipsis-h"></i>
                  </a>
                  <div class="dropdown-menu dropdown-menu-right">
                    <a href="#" class="dropdown-item">Refresh</a>
                    <a href="#" class="dropdown-item">Manage Widgets</a>
                    <a href="#" class="dropdown-item">Settings</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      
        <!-- Orders table -->
        <div class="table-responsive">
          <table class="table table-cards align-items-center">
            <thead>
              <tr>
                <th scope="col">Invoice</th>
                <th scope="col" class="sort">Order</th>
                <th scope="col" class="sort">Value</th>
                <th scope="col" class="sort">Client</th>
                <th scope="col" class="sort">Delivery</th>
                <th scope="col" class="sort">Status</th>
                <th scope="col"></th>
              </tr>
            </thead>
         <tbody>
<?php
$result = firedb($conn, "SELECT * FROM seller_withdraw ORDER BY `id` DESC");
if ($result['success']) {
	foreach ($result['results'] as $a) {
?>
										<tr>
											<th scope="row">                  <button type="button" class="btn btn-sm btn-secondary btn-icon rounded-pill">
                    <span class="btn-inner--icon"><i class="far fa-download"></i></span>
                    <span class="btn-inner--text">Invoice</span>
                  </button></th>
											<td class="order">
                  <span class="h6 text-sm font-weight-bold mb-0"><?php echo $a['time']; ?></span>
                  <span class="d-block text-sm text-muted">Date of payment</span>
                </td>
											<td><?php echo $a['usd']; ?></td>
											<td><?php echo $a['discord']; ?></td>
											<td><span class="value text-sm mb-0"><?php echo $a['method']; ?></span></td>
											<td><?php if ($a['status'] == 0) { ?><form method="post"><button type="submit" class="btn btn-sm btn-soft-warning btn-icon rounded-pill" name="action" value="paytrue-<?php echo $a['id']; ?>"><span class="btn-inner--icon"><i class="far fa-plus"></i></span><span class="btn-inner--text">Pay</span></button></form><?php } else { ?> <button type="button" class="btn btn-sm btn-soft-success btn-icon rounded-pill">
                      <span class="btn-inner--icon"><i class="far fa-check"></i></span>
                      <span class="btn-inner--text">Paid</span>
                    </button> <?php } ?></td><tr class="table-divider"></tr>
										</tr></div>
<?php
	}
}
?>
                                    </tbody>
          </table>
        </div>
      </div>

<div class="col-sm-6">
<div class="card m-b-30" style="background-color: #fcfcfc;">
						<div class="card-body">
							<h4 class="mt-0 header-title mb-4">Active Queue</h4>
							<div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th scope="col">Status</th>
											<th scope="col">R$ Stock</th>
                                            <th scope="col">Group ID</th>
											<th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
$result = firedb($conn, "SELECT * FROM queue WHERE status=1");
if ($result['success']) {
	foreach ($result['results'] as $a) {
?>
										<tr>
											<td><?php if ($a['status'] == 200) { ?>Paused<?php } else { ?>Active<?php } ?></td>
											<td><?php echo $a['stock']; ?></td>
											<td><?php echo $a['groupid']; ?></td>
											<td><?php if ($a['status'] == 200) { ?><form method="post"><button type="submit" class="btn btn-warning" name="action" style="padding-left:10px;padding-right:10px;" value="resume-<?php echo $a['id']; ?>">Resume</button></form><?php } else { ?> No actions available <?php } ?></td>
										</tr>
<?php
	}
}
?>
                                    </tbody>
                                </table>
                            </div>
						</div>
					</div>
</div>
				
				
				
				<div class="col-sm-6">
<div class="card m-b-30" style="background-color: #fcfcfc;">
						<div class="card-body">
							<h4 class="mt-0 header-title mb-4">Seller Applications</h4>
							<div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th scope="col">Application</th>
											<th scope="col">R$ Stock</th>
                                            <th scope="col">Info</th>
											<th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
$result = firedb($conn, "SELECT * FROM sellers");
if ($result['success']) {
	foreach ($result['results'] as $a) {
?>
										<tr>
											<td><button type="button" class="btn btn-sm btn-secondary btn-icon rounded-pill">
                      <span class="btn-inner--icon"><i class="far fa-paper-plane"></i></span>
                      <span class="btn-inner--text">Application</span>
                    </button></td>
											<td><?php echo $a['expected']; ?></td>
											<td>
                  <span class="h6 text-sm font-weight-bold mb-0"><?php echo $a['username']; ?></span>
                  <span class="d-block text-sm text-muted"><?php echo $a['discord']; ?></span>
                </td>
											<td><?php if ($a['status'] == 0) { ?><?php echo "<td>" . "<a class='btn btn-sm btn-soft-warning btn-icon rounded-pill' href='https://rbxstorm.com/sell/accseller.php?wdunfuh2ffuenq8hddndakdkad&id=" . $a['id'] . "'><span class='btn-inner--icon'><i class='far fa-plus'></i></span><span class='btn-inner--text'>Accept</span></a></td>"; ?>
<?php } else { echo "<td>" . "<a class='btn btn-sm btn-soft-success btn-icon rounded-pill' href='https://rbxstorm.com/sell/accseller.php?wdunfuh2ffuenq8hddndakdkad&id=" . $a['id'] . "'><span class='btn-inner--icon'><i class='far fa-receipt'></i></span><span class='btn-inner--text'>Check Password</span></a></td>"; } ?></td>
                    
                    </tr>
<?php
	}
}
?>
                                    </tbody>
                                </table>
                            </div>
						</div>
					</div>
				</div>
</div>

            				<div class="col-lg-4">
              <div class="card card-stats bg-gradient-primary border-0 hover-shadow-lg hover-translate-y-n3 mb-4 ml-lg-0">
                <div class="actions actions-dark">
                  <a href="#" class="action-item">
                    <i class="far fa-sync-alt"></i>
                  </a>
                  <div class="dropdown">
                    <a href="#" class="action-item" data-toggle="dropdown" aria-expanded="false"><i class="far fa-ellipsis-h"></i></a>
                    <div class="dropdown-menu dropdown-menu-right">
                      <a href="#" class="dropdown-item">Refresh</a>
                      <a href="#" class="dropdown-item">Manage Widgets</a>
                      <a href="#" class="dropdown-item">Settings</a>
                    </div>
                  </div>
                </div>
                <div class="card-body">
                  <div class="d-flex">
                    <div>
                      <div class="icon text-white icon-sm">
                        <i class="far fa-credit-card"></i>
                      </div>
                    </div>
                    <div class="pl-4">
                      <span class="totalOffers d-block h5 text-white mr-2 mb-1"></span>
                      <span class="text-white">Amount of offers done</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>


				
			<?php
			
			$_SESSION['pay'] = firedb($conn, "SELECT * FROM seller_withdraw");
if (isset($_POST['action'])) {
	$a = explode('-', $_POST['action']);
	if ($a[0] == "paytrue") {
		firedb($conn, "UPDATE seller_withdraw SET status='1' WHERE id=".$a[1]);
		header("Location: payments.php");
		die();
	}
}

?>

				<br>
				<br>
				</div>
				</div>
			</div></div>
            
            <script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

        </div></div>
        <!-- End Main Content-->
        <!-- Main Footer-->
                <!-- Main Footer-->
                <div id="footers-footer-2">
          <footer class="footer p-0 footer-dark bg-gradient-dark" id="footer-main">
            <div class="container">
              <div class="py-4">
                <div class="row align-items-md-center">
                  <div class="col-md-4 mb-4 mb-md-0">
                    <div class="d-flex align-items-center">
                      <p class="text-sm mb-0">© RBXStorm. 2019 RBXStorm. All rights reserved.<br>We are not affiliated with any of the games or companies shown on this website. Use of any logos or trademarks are for reference purposes only. By utilizing the website, you agree to be bound by the terms of service.
</p>
                    </div>
                  </div>
                  <div class="col-sm-6 col-md-4 mb-4 mb-sm-0">
                    <ul class="nav justify-content-center">
                      <li class="nav-item">
                        <a class="nav-link" href="https://rbxstorm.com/legal.html">Terms</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="https://rbxstorm.com/sell.html">Panel</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="https://rbxstorm.com/privacy-policy.php">Privacy</a>
                      </li>
                    </ul>
                  </div>
                  <div class="col-sm-6 col-md-4">
                    <ul class="nav justify-content-center justify-content-md-end mt-3 mt-md-0">
                      <li class="nav-item">
                        <a class="nav-link" href="https://dribbble.com/webpixels" target="_blank">
                          <i class="fab fa-dribbble"></i>
                        </a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="https://www.instagram.com/webpixelsofficial" target="_blank">
                          <i class="fab fa-instagram"></i>
                        </a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="https://github.com/webpixels" target="_blank">
                          <i class="fab fa-github"></i>
                        </a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="https://www.facebook.com/webpixels" target="_blank">
                          <i class="fab fa-facebook"></i>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </footer>
        </div>
        <!--End Footer-->
        <!--End Footer-->
    </div>
    <!-- End Page -->
    <!-- Back-to-top --><a href="#top" id="back-to-top"><i class="fe fe-arrow-up"></i></a>
    <!-- Jquery js-->
    <script src="../assets/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap js-->
    <script src="../assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Ionicons js-->
    <script src="../assets/plugins/ionicons/ionicons.js"></script>
    <!-- Rating js-->
    <script src="../assets/plugins/rating/jquery.rating-stars.js"></script>
    <!-- Chart.Bundle js-->
    <script src="../assets/plugins/chart.js/Chart.bundle.min.js"></script>
    <!-- Apexcharts js-->
    <script src="../assets/plugins/apexcharts/apexcharts.js"></script>
    <script src="../assets/plugins/apexcharts/irregular-data-series.js"></script>
    <!-- Peity js-->
    <script src="../assets/plugins/peity/jquery.peity.min.js"></script>
    <!-- Flot Chart js-->
    <script src="../assets/plugins/jquery.flot/jquery.flot.js"></script>
    <script src="../assets/plugins/jquery.flot/jquery.flot.pie.js"></script>
    <script src="../assets/plugins/jquery.flot/jquery.flot.resize.js"></script>
    <!-- Jquery-Ui js-->
    <script src="../assets/plugins/jquery-ui/ui/widgets/datepicker.js"></script>
    <!-- Select2 js-->
    <script src="../assets/plugins/select2/js/select2.min.js"></script>
    <!--MutipleSelect js-->
    <script src="../assets/plugins/multipleselect/multiple-select.js"></script>
    <script src="../assets/plugins/multipleselect/multi-select.js"></script>
    <!-- Sidebar js-->
    <script src="../assets/plugins/sidebar/sidebar.js"></script>
    <!-- Jquery.mCustomScrollbar js-->
    <script src="../assets/plugins/jquery.mCustomScrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <!-- Perfect-scrollbar js-->
    <script src="../assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <!-- Switcher js -->
    <script src="../assets/switcher/js/switcher.js"></script>
    <!-- Sticky js-->
    <script src="../assets/js/sticky.js"></script>
    <script src="https://demo.webpixels.io/purpose-website-ui-kit-v2.0.1/assets/js/purpose.js"></script>
    <!-- Dashboard js-->
    <script src="../assets/js/index.js"></script>
    <!-- Custom js-->
    <script src="../assets/js/custom.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
    <svg id="SvgjsSvg1001" width="2" height="0" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" style="overflow: hidden; top: -100%; left: -100%; position: absolute; opacity: 0;">
        <defs id="SvgjsDefs1002"></defs>
        <polyline id="SvgjsPolyline1003" points="0,0"></polyline>
        <path id="SvgjsPath1004" d="M0 0 "></path>
    </svg>
    <div id="ui-datepicker-div" class="ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all"></div>
    <div class="main-navbar-backdrop"></div>
	<script>
		function httpGet(theUrl) {
			var xmlHttp = new XMLHttpRequest();
			xmlHttp.open( "GET", theUrl, false );
			xmlHttp.send( null );
			return xmlHttp.responseText;
		}
		function loadinfo() {
			var info = JSON.parse(httpGet("../api/stats.php"));
				
			document.getElementById('username').innerHTML = info.username;
			document.getElementById('robloxUserIMG').src = info.userImg;
			var name = document.getElementsByClassName("siteName");
			for(var i=0; i<name.length; i++) {
				name[i].innerHTML = info.siteName;
			}
			var roux = document.getElementsByClassName("siteOnline");
			for(var i=0; i<roux.length; i++) {	
				roux[i].innerHTML = info.actualOnline;
			}
			var usr = document.getElementsByClassName("siteTotalEarned");
			for(var i=0; i<usr.length; i++) {	
				usr[i].innerHTML = info.actualTotalEarned+" R$";
			}
			var off = document.getElementsByClassName("totalOffers");
			for(var i=0; i<off.length; i++) {	
				off[i].innerHTML = info.totalOffers;
			}
			
			document.title = info.siteName+" | FREE ROBUX!";
		}
		loadinfo();
	</script>
</body>

</html>