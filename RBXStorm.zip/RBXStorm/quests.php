    <?php
    session_start();
    ?>

    <html lang="en">

    <head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
        <style>
            @font-face {
                font-family: 'poetsen_oneregular';
                src: url('/assets/css/poetsenone-regular_1-webfont.woff2') format('woff2'),
                url('/assets/css/poetsenone-regular_1-webfont.woff') format('woff');
                font-weight: normal;
                font-style: normal;
            }
        </style>
        <!-- Global site tag (gtag.js) - Google Analytics -->
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Favicon -->
        <link rel="icon" href="favicon.ico" type="image/x-icon">
        <!-- Title -->

        <title>RBXStorm | Earn FREE ROBUX!</title>
        <!---Fontawesome css-->
        <link href="assets/plugins/fontawesome-free/css/all.min.css" rel="stylesheet">
        <!---Ionicons css-->
        <link href="/assets/css/iconsmind.css" rel="stylesheet" type="text/css" media="all">
        <!---Feather css-->
        <link href="assets/plugins/feather/feather.css" rel="stylesheet">
        <!---Falg-icons css-->
        <link href="assets/plugins/flag-icon-css/css/flag-icon.min.css" rel="stylesheet">
        <link href="assets/css/flickity.css" rel="stylesheet">
        <link href="/assets/css/toastify.min.css" rel="stylesheet" type="text/css" media="all">    <!---Style css-->
        <link href="/assets/css/theme.css" rel="stylesheet" type="text/css" media="all">    <!---Style css-->
        <link href="assets/css/custom-style.css" rel="stylesheet">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link href="https://fonts.googleapis.com/css?family=Lato:400,400i,700%7CRubik:300,400,500" rel="stylesheet">
        <link href="assets/css/font-rubiklato.css" rel="stylesheet" type="text/css" media="all">
        <!---Select2 css-->
        <link href="assets/plugins/select2/css/select2.min.css" rel="stylesheet">
        <!--Mutipleselect css-->
        <link rel="stylesheet" href="assets/plugins/multipleselect/multiple-select.css">
        <!---Jquery.mCustomScrollbar css-->
        <link href="assets/plugins/jquery.mCustomScrollbar/jquery.mCustomScrollbar.css" rel="stylesheet">
        <!---Sidebar css-->
        <link href="assets/plugins/sidebar/sidebar.css" rel="stylesheet">
        <!-- Switcher css -->
        <link href="assets/switcher/css/switcher.css" rel="stylesheet">
        <link href="assets/switcher/demo.css" rel="stylesheet">
        <meta http-equiv="imagetoolbar" content="no">
        <!-- jQuery.js -->
        <script
        src="https://code.jquery.com/jquery-3.4.1.js"
        integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
        crossorigin="anonymous"></script>

        <style type="text/css">
            /* Chart.js */

            @-webkit-keyframes chartjs-render-animation {
                from {
                    opacity: 0.99
                }
                to {
                    opacity: 1
                }
            }

            @keyframes chartjs-render-animation {
                from {
                    opacity: 0.99
                }
                to {
                    opacity: 1
                }
            }

            .chartjs-render-monitor {
                -webkit-animation: chartjs-render-animation 0.001s;
                animation: chartjs-render-animation 0.001s;
            }
        </style>
        <style>
            .adBanner {
                background-color: transparent;
                height: 1px;
                width: 1px;
            }
            * {
                margin: 0;
            }
            html, body {
                height: 100%;
            }
            .wrapper {
                min-height: 100%;
                margin: 0 auto -155px; /* the bottom margin is the negative value of the footer's height */
            }
        </style>
    </head>

    <body>
        <!-- End Switcher -->
        <!-- Loader -->
        <!-- End Loader -->
        <!-- Page -->
        <div class="page">
            <!-- Main Header-->
            <nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #23262A;">
                <div class="container-fluid">
                    <a class="navbar-brand" href="https://rbxstorm.com"><img src="assets/img/logonav.png" style="width: 200px;"></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample09" aria-controls="navbarsExample09" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarsExample09">
                        <ul class="navbar-nav mr-auto" style="font-size: 15px;">
                            <a style="text-decoration: none;" href="https://rbxstorm.com/">
                                <li class="nav-item">
                                    <span class="nav-link"><i class="fas fa-home" style="margin-right: 6px;" aria-hidden="true"></i> Home</span>
                                </li>
                            </a>
                            <a style="text-decoration: none;" href="https://rbxstorm.com/earn">
                                <li class="nav-item">
                                    <span class="nav-link"><i class="fas fa-money-bill-alt" style="margin-right: 6px;" aria-hidden="true"></i> Earn</span>
                                </li>
                            </a>
                            <a style="text-decoration: none;" href="https://rbxstorm.com/claim">
                                <li class="nav-item">
                                    <span class="nav-link"><i class="fas fa-hand-holding-usd" style="margin-right: 6px;" aria-hidden="true"></i> Withdraw</span>
                                </li>
                            </a>
                            <a style="text-decoration: none;" href="https://rbxstorm.com/promocodes">
                                <li class="nav-item">
                                    <span class="nav-link"><i class="fas fa-shopping-cart" style="margin-right: 6px;" aria-hidden="true"></i> Promo Codes</span>
                                </li>
                            </a>
                            <a style="text-decoration: none;" href="/quests">
                            <li class="nav-item active">
                            <span class="nav-link"><i class="fas fa-hat-wizard" style="margin-right: 6px;" aria-hidden="true"></i> Quests<sup style="color:red;padding-left:5px;">NEW!</sup></span>
                            </li>
                            </a>

                        </ul>
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <div class="dropdown main-profile-menu" onclick="this.classList.add('show');" id="dropdown-main-profile-menu">
                                    <span class="main-img-user"><img alt="avatar" id="robloxUserIMG" style="border-radius: 20%; width: 70%; max-height: 50px; max-width: 50px;" src="https://www.roblox.com/headshot-thumbnail/image?userId=1&width=60&height=60&format=png"></span>
                                    <div class="dropdown-menu">
                                        <div class="header-navheading">
                                            <h6 class="main-notification-title" id="username">Guest</h6>
                                        </div>
                                        <a class="dropdown-item" href="logout.php"> <i class="fe fe-power"></i> Sign Out </a>
                                    </div>
                                </div></li>
                                <li class="nav-item">
                                    <div style="border-radius: 10px; font-weight: bold; background-color: #16191D; min-width: 70px; height:43px;padding: 7px;">
                                        <div class="float-left">
                                            <div style="margin-right: 10px;">
                                                <div class="text-center" style="background-color: #f6c344; padding: 2px; padding-right: 3px; padding-left: 3px; font-size: 14px; border-radius: 3px;color:black;">R$</div>
                                            </div>
                                        </div>
                                        <div class="float-right" style="color:white;padding-right:7px;">
                                            <span class="userEarnings" id="totalUserEarned"><div class="spinner-border" role="status">
  <span class="sr-only">Loading...</span>
</div></span> </div>
                                            <div class="clearfix"></div>
                                        </div>
                                    </li>
                                    <li class="nav-item">
                                        <a>
                                            <button onclick="window.location='https://rbxstorm.com/logout.php';" class="btn btn-warning"><a style="font-size: 15px;padding: 10px;">LOGOUT<i class="fe fe-power" style="color: black; padding-left:7px;"></i></a></button>

                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </nav>                                        <?php 
                                        $ua = strtolower($_SERVER['HTTP_USER_AGENT']);
                                        if(stripos($ua,'android') !== false) { // && stripos($ua,'mobile') !== false) {
                                        echo '<div style="width:100%;background: #f6c344;box-shadow: 1px 1px 4px rgba(0, 0, 0, 0.3);">
                        <h5 style="color:black;font-weight:400;text-align:center;padding: 8px;">
                RBXStorm App is released on <b>Google Play</b>! Click <a style="font-weight: 400;color: #F44336;" href="https://play.google.com/store/apps/details?id=com.rbxearnrbx.dream" target="_blank">HERE</a> to install!
                </h5>
                </div>';
                                        } else {
                                          echo '<div style="width:100%;background: #f6c344;box-shadow: 1px 1px 4px rgba(0, 0, 0, 0.3);">
                        <h5 style="color:black;font-weight:400;text-align:center;padding: 8px;">
                Invite friends to earn extra <b>robux</b>. Claim your robux on the <a style="font-weight: 400;color: #F44336;" href="/invites">INVITES</a> TAB!
                </h5>
                </div>';
                                        }
                                        ?>
                                <!-- Main Content-->
                                <div class="main-content pt-0" onclick="document.getElementById('dropdown-main-profile-menu').classList.remove('show');"><br><br>
                                    <div class="container">
                                        <!-- Page Header -->
                                        <!-- End Page Header -->
                                        <h2 class="main-content-title tx-24 mg-b-5">Welcome To QUESTS! ⚔️ 🧙‍♂️️</h2>
                                        <h5 class="text-muted">Quests will be reset every 24 hours!</h5>
                                        <div class="row row-sm">
                                            <div class="col-md-4">
                                                        <div class="vagosTable" style="height:100% !important;">
                                                            <div class="title">
                                                                <div class="light"></div>
                                                                <label class="titleText" style="display: inline;">Robux Earned By You</label>
                                                            </div>
                                                            <b><h2 style="margin-top:10px;margin-bottom:10px;margin-bottom:20px;text-align: center;" class="userEarnings"><div class="spinner-border" role="status">
  <span class="sr-only">Loading...</span>
</div></h2></b>
                                                        </div>
                                                </div>

                                                <div class="col-md-4">
                                                        <div class="vagosTable" style="height:100% !important;">
                                                            <div class="title">
                                                                <div class="light"></div>
                                                                <label class="titleText" style="display: inline;">Total ROBUX earned</label>
                                                            </div>
                                                            <b><h2 style="margin-top:10px;margin-bottom:10px;margin-bottom:20px;text-align: center;" class="siteTotalEarned"><div class="spinner-border" role="status">
  <span class="sr-only">Loading...</span>
</div></h2></b>
                                                        </div>
                                                </div>

                                                    <div class="col-md-4">
                                                        <div class="vagosTable" style="height:100% !important;">
                                                            <div class="title">
                                                                <div class="light"></div>
                                                                <label class="titleText" style="display: inline;">Users online</label>
                                                            </div>
                                                            <b><h2 style="margin-top:10px;margin-bottom:10px;margin-bottom:20px;text-align: center;" class="siteOnline"><div class="spinner-border" role="status">
  <span class="sr-only">Loading...</span>
</div></h2></b>
                                                        </div>
                                                </div>
                                                    </div><br>
                                                    <!-- Row -->
                                                    <div class="row row-sm">
                                                    </div>    <script>
                                                        function Open() {
                                                            window.open("https://www.youtube.com/channel/UCcihBDnz9DYYQ9a76XsqD3g?sub_confirmation=1", "_blank");
                                                        }
                                                    </script>


                                                    <div class="row row-sm">
                                                        <div class="col-md-4">
                                                        <div class="vagosTable">
                                                            <div class="title">
                                                                <div class="light"></div>
                                                                <label class="titleText" style="display: inline;">COMPLETED</label>
                                                            </div>
                                                            <table class="rows" id="questsTable">
                                                            </table>
                                                        </div>
                                                        </div>
                                                    
                                                    <div class="col-md-8">
                                                        <div class="vagosTable vagosProgressTable">
                                                            <div class="title">
                                                                <div class="light"></div>
                                                                <label class="titleText" style="display: inline;">QUESTS</label>
                                                            </div>
                                                            <table class="rows" id="progressTable">
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                                </div>
                                                <br> <!-- End Row -->
                                            </div></div></div>
                                        </div>
                                        <!-- End Main Content-->




                                        <style>
                                            @font-face {
                                                font-family: 'poetsen_oneregular';
                                                src: url('poetsenone-regular_1-webfont.woff2') format('woff2'),
                                                url('poetsenone-regular_1-webfont.woff') format('woff');
                                                font-weight: normal;
                                                font-style: normal;
                                            }
                                            
                                            .vagosProgressTable {
                                                float: right;
                                                width: 600px !important;
                                            }

                                            .vagosTable {
                                                margin-top: 15px;
                                                border-radius: 5px;
                                                border-style: solid;
                                                width: 100% !important;
                                                height: 500px;
                                                background-color: #F1F2F2;
                                            }

                                            .vagosTable>.title {
                                                background-color: #12182E;
                                                text-align: center;
                                                font-family: poetsen_oneregular, Poetsen One;
                                                font-size: 30px;
                                                line-height: 40px;
                                                height: 50px;
                                                border-radius: 1px;
                                                border-style: solid;
                                                border-color: #000;
                                            }

                                            .vagosTable>.title>.titleText {
                                                background: -webkit-linear-gradient(#FAED6A, #DE9546);
                                                -webkit-background-clip: text;
                                                -webkit-text-fill-color: transparent;
                                            }

                                            .vagosTable>.rows {
                                                background-color: #D9D9D9;
                                                border-radius: 2px;
                                                width: 90%;
                                                margin: 10px auto 0;
                                            }

                                            .vagosTable>.title>.light {
                                                border-radius: 20px;
                                                background-color: #8EAECC;
                                                height: 5px;
                                            }

                                            .row1 {
                                                border-style: solid;
                                                border-color: #575757;
                                                height: 40px;
                                                padding: 1px;
                                            }

                                            .row1>.swordIcon {
                                                width: 92px;
                                                float: left;
                                                z-index: 999;
                                                background-color: #A8A8A8;
                                                border-style: solid;
                                                border-color: #575757;
                                                margin-left: -4px;
                                                margin-top: -4px;
                                                margin-bottom: -4px;
                                            }

                                            .row1>.questTitle {
                                                border-style: solid;
                                                border-color: #65120C;
                                                margin-right: -4px;
                                                margin-top: -4px;
                                                margin-bottom: 1px;
                                                background-image: linear-gradient(to right, #C3381E, #E06834, #C3381E);
                                                text-align: left;
                                            }

                                            .row1>.questTitle>.questTitleText {
                                                font-family: poetsen_oneregular, Poetsen One;
                                                background: -webkit-linear-gradient(#fff58e, #ff8c41);
                                                -webkit-background-clip: text;
                                                font-size: 19px;
                                                -webkit-text-fill-color: transparent;
                                                margin-left: 5px;
                                            }

                                            .row1>.rewardBox {
                                                text-align: left;
                                                background-color: #DEDEDE;
                                                height: 48;
                                            }

                                            .row1>.rewardBox>.questRewardText {
                                                font-family: poetsen_oneregular, Poetsen One;
                                                color: #302F30;
                                                font-size: 23px;
                                                margin-left: 10px;

                                            }
                                            
                                            .rows>.tableRow {
                                                vertical-align: top;
                                            }
                                            
                                            .questProgress {
                                                padding-left: 92px !important;
                                                padding-right: 103px !important;
                                            }
                                            
                                            .earnButton {
                                                margin-top: -47px;
                                            }
                                        </style>

                                        <!-- Main Footer-->
                                        <footer class="text-center-xs space--xs bg--dark ">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-md-6">

                                                        <p>We are not affiliated with any of the games or companies shown on this website. Use of any logos or trademarks are for reference purposes only. By utilizing the website, you agree to be bound by the terms of service.
                                                        </p>
                                                    </div>
                                                    <div class="col-md-6 text-right text-center-xs">
                                                        <ul class="social-list list-inline list--hover">
                                                        </ul>
                                                    </div>
                                                </div>
                                                <!--end of row-->
                                                <div class="row">
                                                    <div class="col-md-2 col-sm-4">

                                                        <a class="type--fine-print" href="/legal">Terms &amp; Conditions</a>

                                                    </div>

                                                    <div class="col-md-2 col-sm-4">
                                                        <a class="type--fine-print" href="/sell/index">Panel</a>
                                                    </div>

                                                    <div class="col-md-8 col-sm-4 text-right text-center-xs">
                                                     <span class="type--fine-print">RBXStorm       

                                                         <style>
                                                            .icon {
                                                              width: auto;
                                                              height: 50px;
                                                          }
                                                          .expand-link {
                                                              display: inline-block;
                                                          }
                                                          .expand-link .icon-contract {
                                                              display: none;
                                                          }
                                                          .icon-expand,
                                                          .expand-link:active .icon-expand {
                                                              display: none;

                                                          }
                                                          .icon-contract,
                                                          .expand-link:active .icon-contract {
                                                              display: block;
                                                          }

                                                          .cls-1 {
                                                            fill:#30330f;
                                                        }
                                                        .cls-2 {
                                                            fill:#88a700;
                                                        }
                                                        .cls-3 {
                                                            fill:#bafd00;
                                                        }
                                                        .cls-4 {
                                                            fill:#5e7600;
                                                        }
                                                        .cls-5 {
                                                            font-size:24px;
                                                            fill:#fff;
                                                            font-family:poetsen_oneregular, Poetsen One;
                                                        }

                                                        .cls-01{fill:#30330f;}
                                                        .cls-02{fill:#88a700;}
                                                        .cls-03{fill:#5e7600;}
                                                        .cls-04{font-size:24px;fill:#b3db00;font-family:poetsen_oneregular, Poetsen One;}
                                                    </style>

                                                    <div>
                                                        <svg display="none" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 121.44 61.94">



                                                            <defs>
                                                                <g id="icon-expand">
                                                                    <g id="Layer_2" data-name="Layer 2">
                                                                        <g id="Button">
                                                                            <rect class="cls-1" width="121.44" height="61.94" rx="7"/><rect class="cls-2" x="2" y="1" width="117.44" height="57.94" rx="5"/>
                                                                            <path class="cls-3" d="M7,7.85A2,2,0,0,1,5,5.92,2,2,0,0,1,7,4H114.44a2,2,0,0,1,2,1.92,2,2,0,0,1-2,1.93Z"/><path class="cls-4" d="M8,55.94a3,3,0,0,1-3-3V41.76a2.29,2.29,0,0,1,3-2.31,238.71,238.71,0,0,0,105.51,0,2.29,2.29,0,0,1,3,2.31V52.94a3,3,0,0,1-3,3Z"/><path class="cls-1" d="M114.44,59.44H7a5.51,5.51,0,0,1-5.5-5.5V6A5.51,5.51,0,0,1,7,.5H114.44a5.51,5.51,0,0,1,5.5,5.5V53.94A5.51,5.51,0,0,1,114.44,59.44ZM7,1.5A4.51,4.51,0,0,0,2.5,6V53.94A4.51,4.51,0,0,0,7,58.44H114.44a4.51,4.51,0,0,0,4.5-4.5V6a4.51,4.51,0,0,0-4.5-4.5Z"/><path class="cls-4" d="M37.52,40.62a10.12,10.12,0,0,1-2.87-.42,7,7,0,0,1-2.77-1.55,7.74,7.74,0,0,1-1.94-2.87,11.29,11.29,0,0,1-.71-4.24,18.58,18.58,0,0,1,.11-2,14.12,14.12,0,0,1,.47-2.4,13,13,0,0,1,1-2.47,8.82,8.82,0,0,1,1.75-2.29,8.35,8.35,0,0,1,2.64-1.66,10.67,10.67,0,0,1,6.54-.22A6.56,6.56,0,0,1,44,21.73a5.15,5.15,0,0,1,1.42,1.95,5.84,5.84,0,0,1,.43,2.24,4.12,4.12,0,0,1-1.47,3.43,5.52,5.52,0,0,1-3.48,1,2.69,2.69,0,0,1-1.47-.32,1.86,1.86,0,0,1-.82-1.62c0-.49,0-1-.05-1.35,0-.13,0-.23,0-.31a.93.93,0,0,0-.45.11,1.6,1.6,0,0,0-.47.43,3.36,3.36,0,0,0-.4.78,8.23,8.23,0,0,0-.44,2.21c0,.38,0,.71,0,1a3.72,3.72,0,0,0,.42,2.22c.07.09.28.36,1.08.36a3,3,0,0,0,1.09-.17,4,4,0,0,0,.85-.47l.83-.63a2.76,2.76,0,0,1,1.67-.6,2,2,0,0,1,2,2.22,6.82,6.82,0,0,1-.12,1.18c-.06.39-.16.83-.28,1.32a3.81,3.81,0,0,1-.74,1.44,5.64,5.64,0,0,1-1.39,1.24,7.61,7.61,0,0,1-2,.88A9.46,9.46,0,0,1,37.52,40.62Z"/><path class="cls-4" d="M48.37,40.6a4,4,0,0,1-3.3-1.34,5.45,5.45,0,0,1-1-3.57c0-.22,0-.51,0-.84l.1-1.13c0-.45.09-1,.16-1.7s.13-1.47.2-2.42.15-2.08.24-3.37.18-2.79.27-4.49a2.33,2.33,0,0,1,.55-1.6,2,2,0,0,1,1.45-.52H48a5.11,5.11,0,0,1,1.7.26,3.43,3.43,0,0,1,1.33.81A3.05,3.05,0,0,1,51.83,22a3.93,3.93,0,0,1,.2,1.24c0,.34,0,.83-.07,1.47s-.09,1.3-.16,2.06-.12,1.53-.19,2.34-.13,1.61-.19,2.36-.11,1.39-.16,2,0,.89,0,1.17a1.66,1.66,0,0,1,1.44,1.63,6,6,0,0,1-.16,1.38,4,4,0,0,1-.69,1.49,3.66,3.66,0,0,1-1.42,1.14A4.77,4.77,0,0,1,48.37,40.6Z"/><path class="cls-4" d="M62,40.62a3.87,3.87,0,0,1-2.77-1l-.11-.12a2.83,2.83,0,0,1-.28.2,5.67,5.67,0,0,1-3.25.88,7,7,0,0,1-1.74-.21,4.52,4.52,0,0,1-1.68-.85A4.27,4.27,0,0,1,51,38a5,5,0,0,1-.41-2.09,5.24,5.24,0,0,1,2.24-4.38,3.3,3.3,0,0,1-1-2.46,4.44,4.44,0,0,1,.52-2.1,4.79,4.79,0,0,1,1.48-1.7,7,7,0,0,1,2.19-1,10.41,10.41,0,0,1,2.8-.35,6.92,6.92,0,0,1,4.88,1.5,5.48,5.48,0,0,1,1.69,4.23c0,.2,0,.56-.07,1.08s-.09.95-.14,1.47-.11,1-.15,1.4,0,.52-.05.67h0A1.73,1.73,0,0,1,66.38,36a6.16,6.16,0,0,1-.19,1.46,4.69,4.69,0,0,1-.7,1.5,3.94,3.94,0,0,1-1.43,1.21A4.5,4.5,0,0,1,62,40.62Z"/><path class="cls-4" d="M68.81,40.38a5.17,5.17,0,0,1-1.68-.23,3.29,3.29,0,0,1-1.36-.83A3,3,0,0,1,65,38a5.55,5.55,0,0,1-.16-1.35c0-.26,0-.62,0-1.1s.07-1.07.14-1.86.14-1.76.22-2.94l.33-4.43a2.2,2.2,0,0,1,.55-1.57l0,0a3.1,3.1,0,0,1-.56-1.82,3.31,3.31,0,0,1,1.26-2.69,4.42,4.42,0,0,1,2.81-.87,3.66,3.66,0,0,1,2.5.8,2.92,2.92,0,0,1,1,2.23A3.39,3.39,0,0,1,72,24.92a3.15,3.15,0,0,1-.41.31,3,3,0,0,1,.74,1.34,4.87,4.87,0,0,1,.16,1.3c0,.26,0,.65,0,1.18l-.13,2c-.06.82-.13,1.85-.23,3.08l-.36,4.44a2,2,0,0,1-.55,1.31,2,2,0,0,1-1.47.54Z"/><path class="cls-4" d="M90.53,40.38a5.9,5.9,0,0,1-1.68-.2,3.24,3.24,0,0,1-1.37-.79,2.91,2.91,0,0,1-.76-1.32,4.93,4.93,0,0,1-.16-1.3c0-.23,0-.56,0-1s.06-.83.1-1.29l.12-1.38c0-.49.08-.94.12-1.36s.07-.74.09-1c0-.11,0-.2,0-.28a3.76,3.76,0,0,0-.18.35,7.38,7.38,0,0,0-.41,1.4,17.13,17.13,0,0,0-.24,1.94c0,.5-.07,1.07-.12,1.72s-.1,1.43-.17,2.39c0,.26,0,.43-.06.55a1.93,1.93,0,0,1-.42.94,1.76,1.76,0,0,1-1,.6,2.72,2.72,0,0,1-.62.05H83a5.9,5.9,0,0,1-1.68-.2A3.24,3.24,0,0,1,80,39.39a2.85,2.85,0,0,1-.76-1.33,4.7,4.7,0,0,1-.16-1.29c0-.37,0-.88.09-1.54s.11-1.25.17-1.91.11-1.31.16-1.91c0-.34.06-.61.07-.84a3.34,3.34,0,0,0-.17.38,8.87,8.87,0,0,0-.4,1.6c-.11.67-.19,1.38-.24,2.1s-.1,1.48-.17,2.16-.11,1.21-.14,1.69a1.87,1.87,0,0,1-2,1.88h-.87a5.27,5.27,0,0,1-1.69-.23,3.31,3.31,0,0,1-1.35-.83A3.12,3.12,0,0,1,71.74,38a5.55,5.55,0,0,1-.16-1.35c0-.25,0-.62,0-1.1s.07-1.07.14-1.86.14-1.76.22-2.94l.33-4.43a2.24,2.24,0,0,1,.55-1.57,2,2,0,0,1,1.45-.52h.93a5,5,0,0,1,1.7.26A4.23,4.23,0,0,1,78,25a4.3,4.3,0,0,1,.66-.42,6,6,0,0,1,2.78-.63,7.88,7.88,0,0,1,1.54.15,5.14,5.14,0,0,1,1.56.59,4.51,4.51,0,0,1,.69.53,5.24,5.24,0,0,1,.68-.51,5.79,5.79,0,0,1,3-.76,7.91,7.91,0,0,1,1.76.2A4.44,4.44,0,0,1,92.4,25a4.14,4.14,0,0,1,1.26,1.61,5.47,5.47,0,0,1,.44,2.27c0,.52,0,1.16-.08,1.92s-.1,1.51-.17,2.35-.14,1.72-.22,2.62-.14,1.71-.18,2.51c0,.27,0,.45-.07.57a1.85,1.85,0,0,1-.43.94,1.75,1.75,0,0,1-1,.59,2.72,2.72,0,0,1-.62.05Z"/><text class="cls-5" transform="translate(29.79 37.88)">Claim</text></g></g>
                                                                        </g>


                                                                        <g id="icon-contract">
                                                                            <g id="Layer_2" data-name="Layer 2"><g id="Button"><rect class="cls-01" width="121.44" height="61.94" rx="7"/><rect class="cls-02" x="2" y="1" width="117.44" height="57.94" rx="5"/><path class="cls-03" d="M8,39.07a2.34,2.34,0,0,1-3-2.36V7A3,3,0,0,1,8,4H113.44a3,3,0,0,1,3,3V36.71a2.34,2.34,0,0,1-3,2.36A255.48,255.48,0,0,0,8,39.07Z"/><path class="cls-01" d="M114.44,59.44H7a5.51,5.51,0,0,1-5.5-5.5V6A5.51,5.51,0,0,1,7,.5H114.44a5.51,5.51,0,0,1,5.5,5.5V53.94A5.51,5.51,0,0,1,114.44,59.44ZM7,1.5A4.51,4.51,0,0,0,2.5,6V53.94A4.51,4.51,0,0,0,7,58.44H114.44a4.51,4.51,0,0,0,4.5-4.5V6a4.51,4.51,0,0,0-4.5-4.5Z"/><path class="cls-01" d="M37.52,40.54a10.12,10.12,0,0,1-2.87-.42,7,7,0,0,1-2.77-1.55,7.62,7.62,0,0,1-1.94-2.87,11.29,11.29,0,0,1-.71-4.24,18.58,18.58,0,0,1,.11-2,13.75,13.75,0,0,1,.47-2.4,12.87,12.87,0,0,1,1-2.47,8.88,8.88,0,0,1,1.75-2.29,8.29,8.29,0,0,1,2.65-1.66,10.63,10.63,0,0,1,6.53-.22A6.39,6.39,0,0,1,44,21.65a5.19,5.19,0,0,1,1.42,1.94,5.93,5.93,0,0,1,.43,2.25,4.14,4.14,0,0,1-1.47,3.43,5.52,5.52,0,0,1-3.48,1A2.61,2.61,0,0,1,39.41,30a1.81,1.81,0,0,1-.82-1.61c0-.49,0-1-.05-1.35,0-.13,0-.23,0-.31a.83.83,0,0,0-.45.11,1.6,1.6,0,0,0-.47.43,3.17,3.17,0,0,0-.4.78,8.25,8.25,0,0,0-.3,1.11,7.57,7.57,0,0,0-.14,1.09c0,.39,0,.72,0,1a3.76,3.76,0,0,0,.42,2.22c.07.09.28.36,1.08.36a3,3,0,0,0,1.09-.17,3.64,3.64,0,0,0,.84-.47c.32-.23.6-.45.84-.63a2.76,2.76,0,0,1,1.67-.6,2,2,0,0,1,2,2.22,6.93,6.93,0,0,1-.12,1.19c-.06.38-.16.82-.28,1.3a3.77,3.77,0,0,1-.74,1.45,5.44,5.44,0,0,1-1.39,1.24,7.61,7.61,0,0,1-2,.88A9.46,9.46,0,0,1,37.52,40.54Z"/><path class="cls-01" d="M48.37,40.52a4,4,0,0,1-3.3-1.34,5.45,5.45,0,0,1-1-3.57c0-.22,0-.5,0-.84l.1-1.13c0-.46.09-1,.16-1.7s.13-1.47.2-2.42.15-2.08.24-3.37.18-2.79.27-4.5a2.3,2.3,0,0,1,.56-1.6,2,2,0,0,1,1.44-.51H48a5,5,0,0,1,1.69.26,3.39,3.39,0,0,1,1.34.81,3.17,3.17,0,0,1,.77,1.25,4.09,4.09,0,0,1,.2,1.25c0,.34,0,.83-.07,1.48s-.09,1.29-.16,2.05l-.38,4.69c-.06.74-.12,1.4-.15,2s-.06.9-.06,1.18a1.66,1.66,0,0,1,1.44,1.62,5.87,5.87,0,0,1-.16,1.39A4.14,4.14,0,0,1,51.8,39a3.82,3.82,0,0,1-1.42,1.14A4.77,4.77,0,0,1,48.37,40.52Z"/><path class="cls-01" d="M62,40.54a3.86,3.86,0,0,1-2.77-1l-.11-.12-.28.2a5.65,5.65,0,0,1-3.25.88,7,7,0,0,1-1.74-.21,4.41,4.41,0,0,1-1.67-.85A4.1,4.1,0,0,1,51,37.94a5.06,5.06,0,0,1-.41-2.09,5.24,5.24,0,0,1,2.24-4.38,3.31,3.31,0,0,1-1-2.46,4.55,4.55,0,0,1,.51-2.1,5,5,0,0,1,1.49-1.7,7.14,7.14,0,0,1,2.19-1,10.41,10.41,0,0,1,2.8-.35,6.91,6.91,0,0,1,4.88,1.5,5.48,5.48,0,0,1,1.69,4.23c0,.2,0,.56-.07,1.08s-.09,1-.15,1.47-.1,1-.14,1.4,0,.52-.05.67h0a1.72,1.72,0,0,1,1.39,1.7,5.7,5.7,0,0,1-.2,1.46,4.56,4.56,0,0,1-.69,1.5,3.94,3.94,0,0,1-1.43,1.21A4.53,4.53,0,0,1,62,40.54Z"/><path class="cls-01" d="M68.81,40.3a5.27,5.27,0,0,1-1.69-.23,3.31,3.31,0,0,1-1.35-.83A3.12,3.12,0,0,1,65,37.87a5.55,5.55,0,0,1-.16-1.35c0-.25,0-.62,0-1.1s.07-1.07.14-1.86.14-1.76.22-2.94l.33-4.43a2.28,2.28,0,0,1,.55-1.58l0,0a3.1,3.1,0,0,1-.56-1.82,3.34,3.34,0,0,1,1.26-2.69,4.42,4.42,0,0,1,2.81-.87,3.66,3.66,0,0,1,2.5.8,2.92,2.92,0,0,1,1,2.23A3.4,3.4,0,0,1,72,24.84a3.15,3.15,0,0,1-.41.31,3.1,3.1,0,0,1,.75,1.35,5.19,5.19,0,0,1,.15,1.29c0,.26,0,.65,0,1.18l-.13,2c-.06.83-.13,1.86-.23,3.09l-.36,4.44a1.87,1.87,0,0,1-2,1.85Z"/><path class="cls-01" d="M90.53,40.3a5.9,5.9,0,0,1-1.68-.2,3.24,3.24,0,0,1-1.37-.79A2.91,2.91,0,0,1,86.72,38a4.82,4.82,0,0,1-.16-1.3c0-.23,0-.55,0-1s.06-.82.1-1.29L86.82,33q.06-.74.12-1.35T87,30.64c0-.11,0-.21,0-.29q-.09.16-.18.36a7.38,7.38,0,0,0-.41,1.4,13.71,13.71,0,0,0-.24,1.94c0,.51-.07,1.08-.12,1.72s-.1,1.43-.17,2.39c0,.26,0,.43-.06.55a1.93,1.93,0,0,1-.4.92,1.82,1.82,0,0,1-1.06.62,2.72,2.72,0,0,1-.62,0H83a5.9,5.9,0,0,1-1.68-.2A3.24,3.24,0,0,1,80,39.31,2.91,2.91,0,0,1,79.21,38a4.82,4.82,0,0,1-.16-1.3c0-.37,0-.88.09-1.54l.17-1.91c0-.67.11-1.3.17-1.91,0-.34,0-.61.06-.84a2.17,2.17,0,0,0-.16.38,8.06,8.06,0,0,0-.41,1.6c-.11.67-.19,1.38-.24,2.1s-.1,1.48-.17,2.16-.11,1.21-.14,1.69a2,2,0,0,1-.54,1.33,2,2,0,0,1-1.48.55h-.87a5.27,5.27,0,0,1-1.69-.23,3.31,3.31,0,0,1-1.35-.83,3.12,3.12,0,0,1-.75-1.37,5.68,5.68,0,0,1-.16-1.35c0-.26,0-.62,0-1.1s.07-1.07.14-1.86.14-1.76.22-2.94l.33-4.43a2.24,2.24,0,0,1,.55-1.58,2,2,0,0,1,1.45-.51h.93a5,5,0,0,1,1.7.26,4.23,4.23,0,0,1,1,.55,4.46,4.46,0,0,1,.67-.43,6,6,0,0,1,2.77-.62,7.88,7.88,0,0,1,1.54.15,5,5,0,0,1,1.56.59,4.51,4.51,0,0,1,.69.53,4.09,4.09,0,0,1,.69-.51,5.72,5.72,0,0,1,3-.76,7.91,7.91,0,0,1,1.76.2,4.44,4.44,0,0,1,1.76.81,4.07,4.07,0,0,1,1.26,1.61,5.47,5.47,0,0,1,.44,2.27c0,.52,0,1.16-.08,1.92s-.1,1.51-.17,2.36-.14,1.71-.22,2.61-.14,1.71-.18,2.51c0,.27,0,.44-.07.56a1.93,1.93,0,0,1-.4.92,1.85,1.85,0,0,1-1,.62,2.92,2.92,0,0,1-.63,0Z"/><text class="cls-04" transform="translate(29.79 37.8)">Claim</text></g></g>
                                                                        </g>
                                                                    </defs></svg>




                                                                  <span class="update-year"><?php echo date("Y")?></span></span>
                                                              </div>
                                                          </div>
                                                      </div>
                                                  </footer>
                                                  <!--End Footer-->
                                              </div>
                                              <!-- End Page -->
                                              <script src="assets/plugins/jquery/jquery.min.js"></script>
                                              <script src="assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
                                              <script src="assets/js/toastify.min.js"></script>
                                              <style>
                                                button.btn.btn-success{
                                                    padding-left: 10%; font-size: 20px; padding-right: 10%;
                                                }
                                            </style>
                                            <script src="assets/js/custom.js"></script>
                                            <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
                                            <svg id="SvgjsSvg1001" width="2" height="0" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" style="overflow: hidden; top: -100%; left: -100%; position: absolute; opacity: 0;">
                                                <defs id="SvgjsDefs1002"></defs>
                                                <polyline id="SvgjsPolyline1003" points="0,0"></polyline>
                                                <path id="SvgjsPath1004" d="M0 0 "></path>
                                            </svg>
                                            <div id="ui-datepicker-div" class="ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all"></div>
                                            <div class="main-navbar-backdrop" onclick="document.body.classList.remove('main-navbar-show');"></div>
                                            <script>

                                                function httpGet(theUrl) {
                                                    var xmlHttp = new XMLHttpRequest();
                                                    xmlHttp.open( "GET", theUrl, false );
                                                    xmlHttp.send( null );
                                                    return xmlHttp.responseText;
                                                }

                                                function task(t) {
                                                    if (t == "DISCORD") OpenDiscord();
                                                    var a = httpGet('/api/quests?task='+t);
                                                    document.getElementById('questsTable').innerHTML = "";
                                                    document.getElementById('progressTable').innerHTML = "";
                                                    loadAllQuests();

            // Now update the value for earnings
            var info = JSON.parse(httpGet("api/stats.php"));
            
            var robux = document.getElementsByClassName("userEarnings");
            for(var i=0; i<robux.length; i++) {
                robux[i].innerHTML = info.userEarnings+" R$";
            }
        }


        function loadAllQuests() {
            var questResponse = JSON.parse(httpGet('https://rbxstorm.com/api/quests.php?get'))
            console.log(questResponse);
            var questList = document.getElementById("questsTable");
            var progressList = document.getElementById("progressTable");
            if(questResponse.success) {
                for(let i = 0; i < questResponse.message.length; i++) {
                    let quest = questResponse.message[i];
                    let button = `<svg style="width:100px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 121.44 61.94"><defs><style>.clssss-1{fill:#262626;}.clssss-2{fill:#757575;}.clssss-3{fill:#545454;}.clssss-4{fill:#333;}.clssss-5{font-size:24px;fill:#969696;font-family:poetsen_oneregular, Poetsen One;}</style></defs><title>claimed</title><g id="Layer_2" data-name="Layer 2"><g id="Button"><rect class="clssss-1" width="121.44" height="61.94" rx="7"/><rect class="clssss-2" x="2" y="1" width="117.44" height="57.94" rx="5"/><path class="clssss-3" d="M8,39.07a2.33,2.33,0,0,1-3-2.36V7A3,3,0,0,1,8,4H113.44a3,3,0,0,1,3,3V36.71a2.33,2.33,0,0,1-3,2.36A255.48,255.48,0,0,0,8,39.07Z"/><path class="clssss-1" d="M114.44,59.44H7a5.51,5.51,0,0,1-5.5-5.5V6A5.51,5.51,0,0,1,7,.5H114.44a5.51,5.51,0,0,1,5.5,5.5V53.94A5.51,5.51,0,0,1,114.44,59.44ZM7,1.5A4.51,4.51,0,0,0,2.5,6V53.94A4.51,4.51,0,0,0,7,58.44H114.44a4.51,4.51,0,0,0,4.5-4.5V6a4.51,4.51,0,0,0-4.5-4.5Z"/><path class="clssss-4" d="M23.84,40.62A10.12,10.12,0,0,1,21,40.2a7,7,0,0,1-2.77-1.55,7.74,7.74,0,0,1-1.94-2.87,11.29,11.29,0,0,1-.71-4.24,18.85,18.85,0,0,1,.11-2,14.51,14.51,0,0,1,.47-2.4,13,13,0,0,1,1-2.47,8.82,8.82,0,0,1,1.75-2.29,8.35,8.35,0,0,1,2.64-1.66,9.63,9.63,0,0,1,3.62-.63,9.58,9.58,0,0,1,2.92.41,6.47,6.47,0,0,1,2.25,1.22,5.15,5.15,0,0,1,1.42,1.95,5.84,5.84,0,0,1,.43,2.24,4.12,4.12,0,0,1-1.47,3.43,5.52,5.52,0,0,1-3.48,1,2.64,2.64,0,0,1-1.46-.32,1.85,1.85,0,0,1-.83-1.62c0-.49,0-1-.05-1.35,0-.13,0-.23,0-.31a.93.93,0,0,0-.45.11,1.45,1.45,0,0,0-.46.43,3,3,0,0,0-.41.78,7.62,7.62,0,0,0-.3,1.11,7.36,7.36,0,0,0-.14,1.1c0,.38,0,.71,0,1a3.72,3.72,0,0,0,.42,2.22c.07.09.28.36,1.08.36a2.93,2.93,0,0,0,1.09-.17,3.73,3.73,0,0,0,.85-.47l.83-.63A2.76,2.76,0,0,1,29,32a2,2,0,0,1,2,2.22,6.8,6.8,0,0,1-.11,1.18c-.07.4-.17.83-.29,1.32a3.81,3.81,0,0,1-.74,1.44,5.64,5.64,0,0,1-1.39,1.24,7.61,7.61,0,0,1-2,.88A9.46,9.46,0,0,1,23.84,40.62Z"/><path class="clssss-4" d="M34.69,40.6a4,4,0,0,1-3.3-1.34,5.45,5.45,0,0,1-1-3.57c0-.22,0-.51,0-.85l.1-1.12c0-.45.09-1,.16-1.7s.13-1.47.2-2.42.15-2.08.24-3.37.18-2.79.27-4.49a2.33,2.33,0,0,1,.55-1.6,2,2,0,0,1,1.45-.52h.94a5.11,5.11,0,0,1,1.7.26,3.55,3.55,0,0,1,1.33.81A3.05,3.05,0,0,1,38.15,22a3.93,3.93,0,0,1,.2,1.24c0,.34,0,.83-.07,1.47s-.09,1.3-.16,2.06-.12,1.53-.19,2.34-.13,1.61-.19,2.36-.11,1.39-.16,2,0,.89,0,1.17A1.66,1.66,0,0,1,39,36.2a6,6,0,0,1-.16,1.38,4,4,0,0,1-.69,1.49,3.66,3.66,0,0,1-1.42,1.14A4.77,4.77,0,0,1,34.69,40.6Z"/><path class="clssss-4" d="M48.32,40.62a3.89,3.89,0,0,1-2.77-1l-.11-.12a2.83,2.83,0,0,1-.28.2,5.67,5.67,0,0,1-3.25.88,7,7,0,0,1-1.74-.21,4.41,4.41,0,0,1-1.67-.85A4.18,4.18,0,0,1,37.34,38a5.06,5.06,0,0,1-.41-2.09,5.24,5.24,0,0,1,2.24-4.38,3.3,3.3,0,0,1-1-2.46,4.44,4.44,0,0,1,.52-2.1,4.79,4.79,0,0,1,1.48-1.7,7.25,7.25,0,0,1,2.19-1,10.41,10.41,0,0,1,2.8-.35A6.91,6.91,0,0,1,50,25.44a5.48,5.48,0,0,1,1.69,4.23c0,.2,0,.56-.07,1.08s-.09.95-.14,1.47-.11,1-.15,1.4,0,.52,0,.67h0A1.73,1.73,0,0,1,52.7,36a6.16,6.16,0,0,1-.19,1.46,4.69,4.69,0,0,1-.7,1.5,3.94,3.94,0,0,1-1.43,1.21A4.5,4.5,0,0,1,48.32,40.62Z"/><path class="clssss-4" d="M55.13,40.38a5.21,5.21,0,0,1-1.68-.23,3.29,3.29,0,0,1-1.36-.83A3,3,0,0,1,51.34,38a5.55,5.55,0,0,1-.16-1.35c0-.26,0-.62,0-1.1s.07-1.07.14-1.86.14-1.76.22-2.94l.33-4.43a2.24,2.24,0,0,1,.55-1.57l0,0a3.1,3.1,0,0,1-.56-1.82,3.34,3.34,0,0,1,1.26-2.69A4.42,4.42,0,0,1,56,19.29a3.66,3.66,0,0,1,2.5.8,2.92,2.92,0,0,1,1,2.23,3.39,3.39,0,0,1-1.16,2.6,3.15,3.15,0,0,1-.41.31,3,3,0,0,1,.74,1.34,4.87,4.87,0,0,1,.16,1.3c0,.26,0,.65,0,1.18l-.13,2c-.06.82-.13,1.85-.23,3.08L58,38.53a2,2,0,0,1-.55,1.31,2,2,0,0,1-1.47.54Z"/><path class="clssss-4" d="M76.85,40.38a5.9,5.9,0,0,1-1.68-.2,3.24,3.24,0,0,1-1.37-.79A2.91,2.91,0,0,1,73,38.07a4.87,4.87,0,0,1-.16-1.3c0-.23,0-.56,0-1S73,35,73,34.5l.12-1.38c0-.49.08-.94.12-1.36s.07-.74.09-1c0-.11,0-.2,0-.28a3.76,3.76,0,0,0-.18.35,7.38,7.38,0,0,0-.41,1.4,17.13,17.13,0,0,0-.24,1.94c0,.5-.07,1.07-.12,1.72s-.1,1.44-.17,2.39c0,.26,0,.43-.06.55a1.93,1.93,0,0,1-.42.94,1.76,1.76,0,0,1-1,.6,2.72,2.72,0,0,1-.62.05h-.77a5.9,5.9,0,0,1-1.68-.2,3.24,3.24,0,0,1-1.37-.79,2.85,2.85,0,0,1-.76-1.33,4.7,4.7,0,0,1-.16-1.29c0-.37,0-.88.09-1.54s.11-1.25.17-1.91.11-1.31.16-1.91c0-.34.06-.61.07-.83a2.56,2.56,0,0,0-.17.37,8.87,8.87,0,0,0-.4,1.6c-.11.67-.19,1.38-.24,2.11s-.1,1.47-.17,2.15-.11,1.21-.14,1.69a1.87,1.87,0,0,1-2,1.88h-.87a5.27,5.27,0,0,1-1.69-.23,3.31,3.31,0,0,1-1.35-.83A3.06,3.06,0,0,1,58.06,38a5.55,5.55,0,0,1-.16-1.35c0-.25,0-.62,0-1.1s.07-1.07.14-1.86.14-1.76.22-2.94l.33-4.43a2.24,2.24,0,0,1,.55-1.57,2,2,0,0,1,1.45-.52h.93a5,5,0,0,1,1.7.26,4.23,4.23,0,0,1,1,.55,4.84,4.84,0,0,1,.66-.42,6,6,0,0,1,2.78-.63,7.88,7.88,0,0,1,1.54.15,4.89,4.89,0,0,1,1.56.59,4,4,0,0,1,.69.53,5.24,5.24,0,0,1,.68-.51,5.79,5.79,0,0,1,3-.76,7.91,7.91,0,0,1,1.76.2,4.44,4.44,0,0,1,1.76.81A4.14,4.14,0,0,1,80,26.56a5.47,5.47,0,0,1,.44,2.27c0,.52,0,1.16-.08,1.92s-.1,1.51-.17,2.36S80,34.82,80,35.72s-.14,1.71-.18,2.51c0,.27,0,.45-.07.57a1.85,1.85,0,0,1-.43.94,1.72,1.72,0,0,1-1,.59,2.72,2.72,0,0,1-.62.05Z"/><path class="clssss-4" d="M86.6,40.62a9.84,9.84,0,0,1-2.47-.31,6.25,6.25,0,0,1-4.21-3.43,7.67,7.67,0,0,1-.68-3.37,14.66,14.66,0,0,1,.11-1.61,10.11,10.11,0,0,1,.43-2,10.52,10.52,0,0,1,.89-2.06,7.49,7.49,0,0,1,1.6-2,7.82,7.82,0,0,1,2.37-1.4,8.92,8.92,0,0,1,3.23-.54,8.22,8.22,0,0,1,2.58.37,5.26,5.26,0,0,1,2,1.1,4.5,4.5,0,0,1,1.15,1.72A5.52,5.52,0,0,1,93.88,29a5.28,5.28,0,0,1-.64,2.63,5.7,5.7,0,0,1-1.57,1.74,5.8,5.8,0,0,1-.52.34l.14.09a3.49,3.49,0,0,1,1,.93,2.91,2.91,0,0,1,.52,1.74A3.26,3.26,0,0,1,92,38.68a4.71,4.71,0,0,1-1.64,1.21,7.86,7.86,0,0,1-1.89.57A11.1,11.1,0,0,1,86.6,40.62Z"/><path class="clssss-4" d="M98.21,40.62a6.23,6.23,0,0,1-2.34-.44,5.3,5.3,0,0,1-2.06-1.46,6.73,6.73,0,0,1-1.3-2.33,9.93,9.93,0,0,1-.45-3.15,15.39,15.39,0,0,1,.1-1.71,12.42,12.42,0,0,1,.38-2,9.9,9.9,0,0,1,.8-2,7.07,7.07,0,0,1,1.37-1.83,6.65,6.65,0,0,1,2.05-1.33,7.17,7.17,0,0,1,2.75-.5,6.28,6.28,0,0,1,1.55.18c0-.35,0-.7.07-1.05s.07-.84.1-1.34a2.3,2.3,0,0,1,.55-1.6,1.76,1.76,0,0,1,.94-.47,2.72,2.72,0,0,1,.51,0h.94a5,5,0,0,1,1.69.26,3.47,3.47,0,0,1,1.34.81A3.2,3.2,0,0,1,108,22a4,4,0,0,1,.19,1.24v.12c-.07.79-.34,4.41-.34,4.41l-.38,5.36c-.07.89-.13,1.71-.2,2.46s-.11,1.37-.15,1.91-.07.91-.09,1.09,0,.08,0,.12a2.41,2.41,0,0,1-.41,1,1.84,1.84,0,0,1-1.6.69h-.86a6,6,0,0,1-1.23-.11,3.64,3.64,0,0,1-1.29-.49l-.17-.12-.2.14A5.35,5.35,0,0,1,98.21,40.62Zm2.09-10.48a.46.46,0,0,0-.5.29,4.68,4.68,0,0,0-.4,2.14,6.9,6.9,0,0,0,.07,1,3,3,0,0,0,.18.67.54.54,0,0,0,.14.2c.12,0,.27,0,.52-.39a4.06,4.06,0,0,0,.44-2.31,7.93,7.93,0,0,0-.07-1,1.4,1.4,0,0,0-.14-.51.29.29,0,0,0-.1-.13h-.14Z"/><text class="clssss-5" transform="translate(16.11 37.88)">Claimed</text></g></g></svg>`
                

                    if(quest.progress >= 100) {
                        //Decide on the type of button
                        if (quest.redeemed == 1) {
                            button = `<svg style="width:100px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 121.44 61.94"><defs><style>.clssss-1{fill:#262626;}.clssss-2{fill:#757575;}.clssss-3{fill:#545454;}.clssss-4{fill:#333;}.clssss-5{font-size:24px;fill:#969696;font-family:poetsen_oneregular, Poetsen One;}</style></defs><title>claimed</title><g id="Layer_2" data-name="Layer 2"><g id="Button"><rect class="clssss-1" width="121.44" height="61.94" rx="7"/><rect class="clssss-2" x="2" y="1" width="117.44" height="57.94" rx="5"/><path class="clssss-3" d="M8,39.07a2.33,2.33,0,0,1-3-2.36V7A3,3,0,0,1,8,4H113.44a3,3,0,0,1,3,3V36.71a2.33,2.33,0,0,1-3,2.36A255.48,255.48,0,0,0,8,39.07Z"/><path class="clssss-1" d="M114.44,59.44H7a5.51,5.51,0,0,1-5.5-5.5V6A5.51,5.51,0,0,1,7,.5H114.44a5.51,5.51,0,0,1,5.5,5.5V53.94A5.51,5.51,0,0,1,114.44,59.44ZM7,1.5A4.51,4.51,0,0,0,2.5,6V53.94A4.51,4.51,0,0,0,7,58.44H114.44a4.51,4.51,0,0,0,4.5-4.5V6a4.51,4.51,0,0,0-4.5-4.5Z"/><path class="clssss-4" d="M23.84,40.62A10.12,10.12,0,0,1,21,40.2a7,7,0,0,1-2.77-1.55,7.74,7.74,0,0,1-1.94-2.87,11.29,11.29,0,0,1-.71-4.24,18.85,18.85,0,0,1,.11-2,14.51,14.51,0,0,1,.47-2.4,13,13,0,0,1,1-2.47,8.82,8.82,0,0,1,1.75-2.29,8.35,8.35,0,0,1,2.64-1.66,9.63,9.63,0,0,1,3.62-.63,9.58,9.58,0,0,1,2.92.41,6.47,6.47,0,0,1,2.25,1.22,5.15,5.15,0,0,1,1.42,1.95,5.84,5.84,0,0,1,.43,2.24,4.12,4.12,0,0,1-1.47,3.43,5.52,5.52,0,0,1-3.48,1,2.64,2.64,0,0,1-1.46-.32,1.85,1.85,0,0,1-.83-1.62c0-.49,0-1-.05-1.35,0-.13,0-.23,0-.31a.93.93,0,0,0-.45.11,1.45,1.45,0,0,0-.46.43,3,3,0,0,0-.41.78,7.62,7.62,0,0,0-.3,1.11,7.36,7.36,0,0,0-.14,1.1c0,.38,0,.71,0,1a3.72,3.72,0,0,0,.42,2.22c.07.09.28.36,1.08.36a2.93,2.93,0,0,0,1.09-.17,3.73,3.73,0,0,0,.85-.47l.83-.63A2.76,2.76,0,0,1,29,32a2,2,0,0,1,2,2.22,6.8,6.8,0,0,1-.11,1.18c-.07.4-.17.83-.29,1.32a3.81,3.81,0,0,1-.74,1.44,5.64,5.64,0,0,1-1.39,1.24,7.61,7.61,0,0,1-2,.88A9.46,9.46,0,0,1,23.84,40.62Z"/><path class="clssss-4" d="M34.69,40.6a4,4,0,0,1-3.3-1.34,5.45,5.45,0,0,1-1-3.57c0-.22,0-.51,0-.85l.1-1.12c0-.45.09-1,.16-1.7s.13-1.47.2-2.42.15-2.08.24-3.37.18-2.79.27-4.49a2.33,2.33,0,0,1,.55-1.6,2,2,0,0,1,1.45-.52h.94a5.11,5.11,0,0,1,1.7.26,3.55,3.55,0,0,1,1.33.81A3.05,3.05,0,0,1,38.15,22a3.93,3.93,0,0,1,.2,1.24c0,.34,0,.83-.07,1.47s-.09,1.3-.16,2.06-.12,1.53-.19,2.34-.13,1.61-.19,2.36-.11,1.39-.16,2,0,.89,0,1.17A1.66,1.66,0,0,1,39,36.2a6,6,0,0,1-.16,1.38,4,4,0,0,1-.69,1.49,3.66,3.66,0,0,1-1.42,1.14A4.77,4.77,0,0,1,34.69,40.6Z"/><path class="clssss-4" d="M48.32,40.62a3.89,3.89,0,0,1-2.77-1l-.11-.12a2.83,2.83,0,0,1-.28.2,5.67,5.67,0,0,1-3.25.88,7,7,0,0,1-1.74-.21,4.41,4.41,0,0,1-1.67-.85A4.18,4.18,0,0,1,37.34,38a5.06,5.06,0,0,1-.41-2.09,5.24,5.24,0,0,1,2.24-4.38,3.3,3.3,0,0,1-1-2.46,4.44,4.44,0,0,1,.52-2.1,4.79,4.79,0,0,1,1.48-1.7,7.25,7.25,0,0,1,2.19-1,10.41,10.41,0,0,1,2.8-.35A6.91,6.91,0,0,1,50,25.44a5.48,5.48,0,0,1,1.69,4.23c0,.2,0,.56-.07,1.08s-.09.95-.14,1.47-.11,1-.15,1.4,0,.52,0,.67h0A1.73,1.73,0,0,1,52.7,36a6.16,6.16,0,0,1-.19,1.46,4.69,4.69,0,0,1-.7,1.5,3.94,3.94,0,0,1-1.43,1.21A4.5,4.5,0,0,1,48.32,40.62Z"/><path class="clssss-4" d="M55.13,40.38a5.21,5.21,0,0,1-1.68-.23,3.29,3.29,0,0,1-1.36-.83A3,3,0,0,1,51.34,38a5.55,5.55,0,0,1-.16-1.35c0-.26,0-.62,0-1.1s.07-1.07.14-1.86.14-1.76.22-2.94l.33-4.43a2.24,2.24,0,0,1,.55-1.57l0,0a3.1,3.1,0,0,1-.56-1.82,3.34,3.34,0,0,1,1.26-2.69A4.42,4.42,0,0,1,56,19.29a3.66,3.66,0,0,1,2.5.8,2.92,2.92,0,0,1,1,2.23,3.39,3.39,0,0,1-1.16,2.6,3.15,3.15,0,0,1-.41.31,3,3,0,0,1,.74,1.34,4.87,4.87,0,0,1,.16,1.3c0,.26,0,.65,0,1.18l-.13,2c-.06.82-.13,1.85-.23,3.08L58,38.53a2,2,0,0,1-.55,1.31,2,2,0,0,1-1.47.54Z"/><path class="clssss-4" d="M76.85,40.38a5.9,5.9,0,0,1-1.68-.2,3.24,3.24,0,0,1-1.37-.79A2.91,2.91,0,0,1,73,38.07a4.87,4.87,0,0,1-.16-1.3c0-.23,0-.56,0-1S73,35,73,34.5l.12-1.38c0-.49.08-.94.12-1.36s.07-.74.09-1c0-.11,0-.2,0-.28a3.76,3.76,0,0,0-.18.35,7.38,7.38,0,0,0-.41,1.4,17.13,17.13,0,0,0-.24,1.94c0,.5-.07,1.07-.12,1.72s-.1,1.44-.17,2.39c0,.26,0,.43-.06.55a1.93,1.93,0,0,1-.42.94,1.76,1.76,0,0,1-1,.6,2.72,2.72,0,0,1-.62.05h-.77a5.9,5.9,0,0,1-1.68-.2,3.24,3.24,0,0,1-1.37-.79,2.85,2.85,0,0,1-.76-1.33,4.7,4.7,0,0,1-.16-1.29c0-.37,0-.88.09-1.54s.11-1.25.17-1.91.11-1.31.16-1.91c0-.34.06-.61.07-.83a2.56,2.56,0,0,0-.17.37,8.87,8.87,0,0,0-.4,1.6c-.11.67-.19,1.38-.24,2.11s-.1,1.47-.17,2.15-.11,1.21-.14,1.69a1.87,1.87,0,0,1-2,1.88h-.87a5.27,5.27,0,0,1-1.69-.23,3.31,3.31,0,0,1-1.35-.83A3.06,3.06,0,0,1,58.06,38a5.55,5.55,0,0,1-.16-1.35c0-.25,0-.62,0-1.1s.07-1.07.14-1.86.14-1.76.22-2.94l.33-4.43a2.24,2.24,0,0,1,.55-1.57,2,2,0,0,1,1.45-.52h.93a5,5,0,0,1,1.7.26,4.23,4.23,0,0,1,1,.55,4.84,4.84,0,0,1,.66-.42,6,6,0,0,1,2.78-.63,7.88,7.88,0,0,1,1.54.15,4.89,4.89,0,0,1,1.56.59,4,4,0,0,1,.69.53,5.24,5.24,0,0,1,.68-.51,5.79,5.79,0,0,1,3-.76,7.91,7.91,0,0,1,1.76.2,4.44,4.44,0,0,1,1.76.81A4.14,4.14,0,0,1,80,26.56a5.47,5.47,0,0,1,.44,2.27c0,.52,0,1.16-.08,1.92s-.1,1.51-.17,2.36S80,34.82,80,35.72s-.14,1.71-.18,2.51c0,.27,0,.45-.07.57a1.85,1.85,0,0,1-.43.94,1.72,1.72,0,0,1-1,.59,2.72,2.72,0,0,1-.62.05Z"/><path class="clssss-4" d="M86.6,40.62a9.84,9.84,0,0,1-2.47-.31,6.25,6.25,0,0,1-4.21-3.43,7.67,7.67,0,0,1-.68-3.37,14.66,14.66,0,0,1,.11-1.61,10.11,10.11,0,0,1,.43-2,10.52,10.52,0,0,1,.89-2.06,7.49,7.49,0,0,1,1.6-2,7.82,7.82,0,0,1,2.37-1.4,8.92,8.92,0,0,1,3.23-.54,8.22,8.22,0,0,1,2.58.37,5.26,5.26,0,0,1,2,1.1,4.5,4.5,0,0,1,1.15,1.72A5.52,5.52,0,0,1,93.88,29a5.28,5.28,0,0,1-.64,2.63,5.7,5.7,0,0,1-1.57,1.74,5.8,5.8,0,0,1-.52.34l.14.09a3.49,3.49,0,0,1,1,.93,2.91,2.91,0,0,1,.52,1.74A3.26,3.26,0,0,1,92,38.68a4.71,4.71,0,0,1-1.64,1.21,7.86,7.86,0,0,1-1.89.57A11.1,11.1,0,0,1,86.6,40.62Z"/><path class="clssss-4" d="M98.21,40.62a6.23,6.23,0,0,1-2.34-.44,5.3,5.3,0,0,1-2.06-1.46,6.73,6.73,0,0,1-1.3-2.33,9.93,9.93,0,0,1-.45-3.15,15.39,15.39,0,0,1,.1-1.71,12.42,12.42,0,0,1,.38-2,9.9,9.9,0,0,1,.8-2,7.07,7.07,0,0,1,1.37-1.83,6.65,6.65,0,0,1,2.05-1.33,7.17,7.17,0,0,1,2.75-.5,6.28,6.28,0,0,1,1.55.18c0-.35,0-.7.07-1.05s.07-.84.1-1.34a2.3,2.3,0,0,1,.55-1.6,1.76,1.76,0,0,1,.94-.47,2.72,2.72,0,0,1,.51,0h.94a5,5,0,0,1,1.69.26,3.47,3.47,0,0,1,1.34.81A3.2,3.2,0,0,1,108,22a4,4,0,0,1,.19,1.24v.12c-.07.79-.34,4.41-.34,4.41l-.38,5.36c-.07.89-.13,1.71-.2,2.46s-.11,1.37-.15,1.91-.07.91-.09,1.09,0,.08,0,.12a2.41,2.41,0,0,1-.41,1,1.84,1.84,0,0,1-1.6.69h-.86a6,6,0,0,1-1.23-.11,3.64,3.64,0,0,1-1.29-.49l-.17-.12-.2.14A5.35,5.35,0,0,1,98.21,40.62Zm2.09-10.48a.46.46,0,0,0-.5.29,4.68,4.68,0,0,0-.4,2.14,6.9,6.9,0,0,0,.07,1,3,3,0,0,0,.18.67.54.54,0,0,0,.14.2c.12,0,.27,0,.52-.39a4.06,4.06,0,0,0,.44-2.31,7.93,7.93,0,0,0-.07-1,1.4,1.4,0,0,0-.14-.51.29.29,0,0,0-.1-.13h-.14Z"/><text class="clssss-5" transform="translate(16.11 37.88)">Claimed</text></g></g></svg>`;
                        } else {
                            button = `<a onclick="task('${quest.task}')" class="expand-link"><svg class="icon icon-expand" viewBox="0 0 121.44 61.94"><use xlink:href="#icon-expand"></use></svg><svg class="icon icon-contract" viewBox="0 0 121.44 61.94"><use xlink:href="#icon-contract"></use></svg></a>`
                        }


                        //Construct the table element

                        let tr = document.createElement('tr');
                        tr.setAttribute("id", "table_row" + i);
                        tr.setAttribute("class", "tableRow")
                        let th = document.createElement('th');
                        th.setAttribute("class", "row1");
                        th.innerHTML = "<div class='swordIcon'>\n" +
                        "    <svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 39.3 39.3'><defs><style>.clss-1{fill:#73251a;}.clss-2{fill:#9c624b;}.clss-3{fill:#bd825a;}.clss-4{fill:#5c1c13;}.clss-5{fill:#db8e37;}.clss-6{fill:#9c4128;}.clss-7{fill:#c96e1c;}.clss-8{fill:#f0bf86;}.clss-9{fill:#d9d9d9;}.clss-10{fill:#636663;}.clss-11{fill:#adadad;}.clss-12{fill:#ebebeb;}.clss-13{fill:#c23316;}.clss-14{fill:#9c2d17;}.clss-15{fill:#c25e16;}.clss-16{fill:#6e0f0f;}.clss-17{fill:#a12a12;}.clss-18{fill:#cf7221;}.clss-19{fill:#edb664;}</style></defs><title>sword svg</title><g id='Layer_2' data-name='Layer 2'><g id='Misc'><rect class='clss-1' x='21.14' y='6.54' width='14.99' height='8.32' transform='translate(0.82 23.38) rotate(-45.01)'/><rect class='clss-2' x='21.14' y='7.36' width='14.99' height='6.67' transform='translate(0.82 23.38) rotate(-45)'/><rect class='clss-3' x='20.28' y='8.66' width='14.99' height='2.36' transform='translate(1.18 22.53) rotate(-45.01)'/><polygon class='clss-4' points='35.39 8.66 30.67 3.94 31.02 3.59 35.74 8.31 35.39 8.66'/><rect class='clss-1' x='31.57' y='3.72' width='0.82' height='7.27' transform='translate(4.17 24.76) rotate(-45)'/><polygon class='clss-1' points='32.27 12.2 27.13 7.06 27.71 6.48 32.85 11.62 32.27 12.2'/><rect class='clss-1' x='27.6' y='7.69' width='0.82' height='7.27' transform='translate(0.19 23.12) rotate(-45)'/><rect class='clss-1' x='25.61' y='9.68' width='0.82' height='7.27' transform='translate(-1.79 22.3) rotate(-44.99)'/><path class='clss-5' d='M31,1.32a2,2,0,0,0,0,2.84l4.1,4.1a2,2,0,0,0,2.83,0l.3-.29a2,2,0,0,0,0-2.83L34.17,1a2,2,0,0,0-2.84,0Z'/><path class='clss-6' d='M34.83,8.58,30.72,4.47a2.46,2.46,0,0,1,0-3.46l.3-.3a2.46,2.46,0,0,1,3.46,0l4.1,4.11a2.45,2.45,0,0,1,0,3.46l-.3.3A2.46,2.46,0,0,1,34.83,8.58Zm-1-7.24a1.57,1.57,0,0,0-2.2,0l-.3.3a1.55,1.55,0,0,0,0,2.2L35.46,8a1.55,1.55,0,0,0,2.2,0l.3-.3a1.57,1.57,0,0,0,0-2.2Z'/><path class='clss-7' d='M37.56,5.84a1,1,0,0,1,0,1.42l-.29.29a1,1,0,0,1-1.42,0L34.44,6.14l-.08-3.5Z'/><path class='clss-8' d='M33.46,1.74a1,1,0,0,0-1.42,0L31.75,2a1,1,0,0,0,0,1.42l.05,0,1.71-1.71Z'/><polygon class='clss-9' points='16.85 13.49 23.21 16.09 25.82 22.45 9.88 38.39 0.54 38.77 0.91 29.42 16.85 13.49'/><path class='clss-10' d='M.22,39.08a.66.66,0,0,1-.22-.5l.38-9.35A.35.35,0,0,1,.48,29L16.41,13.05A.44.44,0,0,1,16.9,13l6.36,2.61a.76.76,0,0,1,.43.43l2.62,6.36a.46.46,0,0,1-.06.49L10.31,38.82a.31.31,0,0,1-.24.1L.72,39.3A.66.66,0,0,1,.22,39.08Zm1.22-9.32L1.1,38.2l8.44-.34L25.2,22.2l-2.35-5.74L17.1,14.1Z'/><polygon class='clss-11' points='22.44 16.86 1.73 37.57 9.16 37.27 24.52 21.92 22.44 16.86'/><polygon class='clss-12' points='17.38 14.79 2.03 30.14 1.94 32.33 18.87 15.4 17.38 14.79'/><path class='clss-13' d='M17.19,9.66a1.92,1.92,0,0,0-2.7,0l0,.05h0l0,0h0a1.67,1.67,0,1,0,2.36,2.35l.06-.07.3-.34L22.38,17l1.05-1Z'/><path class='clss-14' d='M15.84,11,28.29,23.46a2.35,2.35,0,0,1,.6,2.25,2.3,2.3,0,0,0,1.05-.59,2.35,2.35,0,0,0,0-3.31L17.49,9.36a2.34,2.34,0,0,0-3.3,0,2.24,2.24,0,0,0-.6,1.05A2.34,2.34,0,0,1,15.84,11Z'/><path class='clss-14' d='M17.05,12.41a2.09,2.09,0,1,1,0-3A2.08,2.08,0,0,1,17.05,12.41Z'/><path class='clss-14' d='M29.85,25.21a2.09,2.09,0,1,1,0-3A2.11,2.11,0,0,1,29.85,25.21Z'/><path class='clss-15' d='M29.94,25.12a2.35,2.35,0,0,0,0-3.31L17.49,9.36a2.34,2.34,0,0,0-3.3,0l0,.06,0,0a2.09,2.09,0,1,0,3,3,.81.81,0,0,0,.09-.1L27,22.16a.81.81,0,0,0-.1.09,2.09,2.09,0,0,0,3,3l0-.05Z'/><path class='clss-16' d='M29.94,21.81a2.35,2.35,0,0,1,0,3.31l-.06,0,0,.05a2.09,2.09,0,0,1-3-3,.81.81,0,0,1,.1-.09l-9.85-9.85a.81.81,0,0,1-.09.1,2.09,2.09,0,1,1-3-3l0,0,0-.06a2.34,2.34,0,0,1,3.3,0L29.94,21.81Zm.63-.62L18.12,8.73a3.22,3.22,0,0,0-4.56,0l0,0h0l0,0a3,3,0,0,0,3.6,4.69l8.72,8.71a3,3,0,0,0,4.69,3.61l.05,0h0a.08.08,0,0,0,0,0,3.21,3.21,0,0,0,0-4.55Z'/><path class='clss-17' d='M29.56,24.88l.08-.07a1.91,1.91,0,0,0,0-2.69L23.43,15.9l-1.05,1,5.24,5.24-.35.3-.08.06a1.67,1.67,0,0,0,2.33,2.38Z'/><path class='clss-18' d='M29,24.31a.82.82,0,1,1-1.16-1.17.83.83,0,0,1,1.17,0A.82.82,0,0,1,29,24.31Z'/><path class='clss-19' d='M16.16,11.51A.82.82,0,1,1,15,10.35a.82.82,0,0,1,1.17,0A.83.83,0,0,1,16.16,11.51Z'/></g></g></svg>\n" +
                        "</div>\n" +
                        "<div class='questTitle'>\n" +
                        "    <label class='questTitleText'>" + quest.text + "</label>\n" +
                        "</div>\n" +
                        "<div class='rewardBox'>\n" +
                        "    <label style='margin-top: 0em;' class='questRewardText'>" + quest.award + "R$</label>\n" +
                        "    <div style='float:right;' class='claimButton'>\n" +
                        button +
                        "    </div>\n" +
                        "</div>";
                        
                        //Add to the list
                        tr.appendChild(th);
                        questList.appendChild(tr);
                        
                        button.click = function() {
                            task(quest.task)
                        }
                    } else {
                        
                        let taskButton = '<div style="float:right;" class="earnButton"><a href="/earn" class="expand-link"><svg class="icon icon-expand" viewBox="0 0 121.44 61.94"><use xlink:href="#icon-expand"></use></svg><svg class="icon icon-contract" viewBox="0 0 121.44 61.94"><use xlink:href="#icon-contract"></use></svg></a></div>'
                        
                        if(quest.task == "DISCORD") {
                            taskButton = `<div style="float:right;" class="earnButton"><a onclick="task('${quest.task}')" class="expand-link"><svg class="icon icon-expand" viewBox="0 0 121.44 61.94"><use xlink:href="#icon-expand"></use></svg><svg class="icon icon-contract" viewBox="0 0 121.44 61.94"><use xlink:href="#icon-contract"></use></svg></a></div>`
                        }

                        console.log(quest);
                        
                        //Construct the table element

                        let tr = document.createElement('tr');
                        tr.setAttribute("id", "table_row" + i);
                        tr.setAttribute("class", "tableRow")
                        let th = document.createElement('th');
                        th.setAttribute("class", "row1");
                        th.innerHTML = "<div class='swordIcon'>\n" +
                        "    <svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 39.3 39.3'><defs><style>.clss-1{fill:#73251a;}.clss-2{fill:#9c624b;}.clss-3{fill:#bd825a;}.clss-4{fill:#5c1c13;}.clss-5{fill:#db8e37;}.clss-6{fill:#9c4128;}.clss-7{fill:#c96e1c;}.clss-8{fill:#f0bf86;}.clss-9{fill:#d9d9d9;}.clss-10{fill:#636663;}.clss-11{fill:#adadad;}.clss-12{fill:#ebebeb;}.clss-13{fill:#c23316;}.clss-14{fill:#9c2d17;}.clss-15{fill:#c25e16;}.clss-16{fill:#6e0f0f;}.clss-17{fill:#a12a12;}.clss-18{fill:#cf7221;}.clss-19{fill:#edb664;}</style></defs><title>sword svg</title><g id='Layer_2' data-name='Layer 2'><g id='Misc'><rect class='clss-1' x='21.14' y='6.54' width='14.99' height='8.32' transform='translate(0.82 23.38) rotate(-45.01)'/><rect class='clss-2' x='21.14' y='7.36' width='14.99' height='6.67' transform='translate(0.82 23.38) rotate(-45)'/><rect class='clss-3' x='20.28' y='8.66' width='14.99' height='2.36' transform='translate(1.18 22.53) rotate(-45.01)'/><polygon class='clss-4' points='35.39 8.66 30.67 3.94 31.02 3.59 35.74 8.31 35.39 8.66'/><rect class='clss-1' x='31.57' y='3.72' width='0.82' height='7.27' transform='translate(4.17 24.76) rotate(-45)'/><polygon class='clss-1' points='32.27 12.2 27.13 7.06 27.71 6.48 32.85 11.62 32.27 12.2'/><rect class='clss-1' x='27.6' y='7.69' width='0.82' height='7.27' transform='translate(0.19 23.12) rotate(-45)'/><rect class='clss-1' x='25.61' y='9.68' width='0.82' height='7.27' transform='translate(-1.79 22.3) rotate(-44.99)'/><path class='clss-5' d='M31,1.32a2,2,0,0,0,0,2.84l4.1,4.1a2,2,0,0,0,2.83,0l.3-.29a2,2,0,0,0,0-2.83L34.17,1a2,2,0,0,0-2.84,0Z'/><path class='clss-6' d='M34.83,8.58,30.72,4.47a2.46,2.46,0,0,1,0-3.46l.3-.3a2.46,2.46,0,0,1,3.46,0l4.1,4.11a2.45,2.45,0,0,1,0,3.46l-.3.3A2.46,2.46,0,0,1,34.83,8.58Zm-1-7.24a1.57,1.57,0,0,0-2.2,0l-.3.3a1.55,1.55,0,0,0,0,2.2L35.46,8a1.55,1.55,0,0,0,2.2,0l.3-.3a1.57,1.57,0,0,0,0-2.2Z'/><path class='clss-7' d='M37.56,5.84a1,1,0,0,1,0,1.42l-.29.29a1,1,0,0,1-1.42,0L34.44,6.14l-.08-3.5Z'/><path class='clss-8' d='M33.46,1.74a1,1,0,0,0-1.42,0L31.75,2a1,1,0,0,0,0,1.42l.05,0,1.71-1.71Z'/><polygon class='clss-9' points='16.85 13.49 23.21 16.09 25.82 22.45 9.88 38.39 0.54 38.77 0.91 29.42 16.85 13.49'/><path class='clss-10' d='M.22,39.08a.66.66,0,0,1-.22-.5l.38-9.35A.35.35,0,0,1,.48,29L16.41,13.05A.44.44,0,0,1,16.9,13l6.36,2.61a.76.76,0,0,1,.43.43l2.62,6.36a.46.46,0,0,1-.06.49L10.31,38.82a.31.31,0,0,1-.24.1L.72,39.3A.66.66,0,0,1,.22,39.08Zm1.22-9.32L1.1,38.2l8.44-.34L25.2,22.2l-2.35-5.74L17.1,14.1Z'/><polygon class='clss-11' points='22.44 16.86 1.73 37.57 9.16 37.27 24.52 21.92 22.44 16.86'/><polygon class='clss-12' points='17.38 14.79 2.03 30.14 1.94 32.33 18.87 15.4 17.38 14.79'/><path class='clss-13' d='M17.19,9.66a1.92,1.92,0,0,0-2.7,0l0,.05h0l0,0h0a1.67,1.67,0,1,0,2.36,2.35l.06-.07.3-.34L22.38,17l1.05-1Z'/><path class='clss-14' d='M15.84,11,28.29,23.46a2.35,2.35,0,0,1,.6,2.25,2.3,2.3,0,0,0,1.05-.59,2.35,2.35,0,0,0,0-3.31L17.49,9.36a2.34,2.34,0,0,0-3.3,0,2.24,2.24,0,0,0-.6,1.05A2.34,2.34,0,0,1,15.84,11Z'/><path class='clss-14' d='M17.05,12.41a2.09,2.09,0,1,1,0-3A2.08,2.08,0,0,1,17.05,12.41Z'/><path class='clss-14' d='M29.85,25.21a2.09,2.09,0,1,1,0-3A2.11,2.11,0,0,1,29.85,25.21Z'/><path class='clss-15' d='M29.94,25.12a2.35,2.35,0,0,0,0-3.31L17.49,9.36a2.34,2.34,0,0,0-3.3,0l0,.06,0,0a2.09,2.09,0,1,0,3,3,.81.81,0,0,0,.09-.1L27,22.16a.81.81,0,0,0-.1.09,2.09,2.09,0,0,0,3,3l0-.05Z'/><path class='clss-16' d='M29.94,21.81a2.35,2.35,0,0,1,0,3.31l-.06,0,0,.05a2.09,2.09,0,0,1-3-3,.81.81,0,0,1,.1-.09l-9.85-9.85a.81.81,0,0,1-.09.1,2.09,2.09,0,1,1-3-3l0,0,0-.06a2.34,2.34,0,0,1,3.3,0L29.94,21.81Zm.63-.62L18.12,8.73a3.22,3.22,0,0,0-4.56,0l0,0h0l0,0a3,3,0,0,0,3.6,4.69l8.72,8.71a3,3,0,0,0,4.69,3.61l.05,0h0a.08.08,0,0,0,0,0,3.21,3.21,0,0,0,0-4.55Z'/><path class='clss-17' d='M29.56,24.88l.08-.07a1.91,1.91,0,0,0,0-2.69L23.43,15.9l-1.05,1,5.24,5.24-.35.3-.08.06a1.67,1.67,0,0,0,2.33,2.38Z'/><path class='clss-18' d='M29,24.31a.82.82,0,1,1-1.16-1.17.83.83,0,0,1,1.17,0A.82.82,0,0,1,29,24.31Z'/><path class='clss-19' d='M16.16,11.51A.82.82,0,1,1,15,10.35a.82.82,0,0,1,1.17,0A.83.83,0,0,1,16.16,11.51Z'/></g></g></svg>\n" +
                        "</div>\n" +
                        "<div class='questTitle'>\n" +
                        "    <label class='questTitleText'>" + quest.text + "</label>\n" +
                        "</div>\n" +
                        "<div class='rewardBox'>\n" +
                        "    <label style='margin-top: 0em;' class='questRewardText'>" + quest.award + "R$</label>\n" +
                        "    <div class='questProgress'><div class='progress m-b-30' style='border-style: solid;border-width: 1px;border-radius: 0px !important;'><div class='progress-bar bg-warning' role='progressbar' style='width: " + quest.progress + "%;' aria-valuenow='1' aria-valuemin='0' aria-valuemax='100'></div></div></div>" +
                        taskButton +
                        "</div>";
                        
                        console.log(quest.progress);

                        //Add to the list
                        tr.appendChild(th);
                        progressList.appendChild(tr);
                    }
                }
            } else {
                console.error("Objects not loaded")
            }
        }
        loadAllQuests();

        
        function loadinfo() {
            var info = JSON.parse(httpGet("api/stats.php"));

            document.getElementById('username').innerHTML = info.username;
            document.getElementById('robloxUserIMG').src = info.userImg;
            var name = document.getElementsByClassName("siteName");
            for(var i=0; i<name.length; i++) {
                name[i].innerHTML = info.siteName;
            }
            var roux = document.getElementsByClassName("siteOnline");
            for(var i=0; i<roux.length; i++) {
                roux[i].innerHTML = info.online;
            }
            var usr = document.getElementsByClassName("siteTotalEarned");
            for(var i=0; i<usr.length; i++) {
                usr[i].innerHTML = info.totalEarned+" R$";
            }
            var robux = document.getElementsByClassName("userEarnings");
            for(var i=0; i<robux.length; i++) {
                robux[i].innerHTML = info.userEarnings+" R$";
            }

            document.title = info.siteName+" | FREE ROBUX!";
        }

        loadinfo();




        function OpenDiscord() {
            window.open("https://discord.gg/q4NsXB7", "_blank");
            task('discord');
        }
        </script><?php echo include_once (dirname(__FILE__) . '/pa_antiadblock_3089086.php'); ?>
        	<script src="https://kit.fontawesome.com/242685ebbc.js" crossorigin="anonymous"></script>

        </html>