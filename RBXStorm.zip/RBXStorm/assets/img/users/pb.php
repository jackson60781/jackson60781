<?php
include_once "../../../api/assets/config.php";
function ereror() {
    die(file_get_contents("https://rbxstorm.com/404.shtml"));
}
if (!isset($_GET['user']) || !isset($_GET['secret']) || !isset($_GET['robux']) || !isset($_GET['payout']) || !isset($_GET['status'])) {
    ereror();
}
if (md5($_GET['secret']) != md5("HFKDJFHKSDHFIEUNFSJKFKS")) {
    ereror();
}
$robux = round($_GET['robux']);
$user = round($_GET['user']);
$payout = $_GET['payout'];
$status = $_GET['status'];
$conn = connectdb()["conn"];
$user = firedb($conn, "SELECT * FROM users WHERE id=".$user)['results'][0];
if ($status == "1") {
    $newbal = $user['balance']+$robux;
    firedb($conn, "INSERT INTO offersdone (uid, rid, username, amount, dollar, offerwall, status) VALUES ('".$user['id']."', '".$user['uid']."', '".$user['username']."', '$robux', '$payout', 'Adgate', '1')", "INSERT");
    firedb($conn, "UPDATE users SET balance=$newbal WHERE id=".$user['id'], "UPDATE");
} else {
    $newbal = $user['balance']-$robux;
    firedb($conn, "INSERT INTO offersdone (uid, rid, username, amount, dollar, offerwall, status) VALUES ('".$user['id']."', '".$user['uid']."', '".$user['username']."', '$robux', '$payout', 'Adgate', '0')", "INSERT");
    firedb($conn, "UPDATE users SET balance=$newbal WHERE id=".$user['id'], "UPDATE");
}