<html lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    <style data-styles="">
        ion-icon {
            visibility: hidden
        }
        
        .hydrated {
            visibility: inherit
        }
    </style>
    <!-- Global site tag (gtag.js) - Google Analytics -->
<meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Favicon -->
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <!-- Title -->
    
    <title>RBXStorm | Earn FREE ROBUX!</title>
    <!---Fontawesome css-->
    <link href="Proxima-Nova-Bold.otf" rel="stylesheet">
    <link href="assets/plugins/fontawesome-free/css/all.min.css" rel="stylesheet">
    <!---Ionicons css-->
    <link href="/assets/css/iconsmind.css" rel="stylesheet" type="text/css" media="all">
    <!---Feather css-->
    <link href="assets/plugins/feather/feather.css" rel="stylesheet">
    <!---Falg-icons css-->
    <link href="assets/plugins/flag-icon-css/css/flag-icon.min.css" rel="stylesheet">
    <link href="assets/css/flickity.css" rel="stylesheet">
    <link href="/assets/css/theme.css" rel="stylesheet" type="text/css" media="all">    <!---Style css-->
    <link href="assets/css/custom-style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,400i,700%7CRubik:300,400,500" rel="stylesheet">
    <link href="assets/css/font-rubiklato.css" rel="stylesheet" type="text/css" media="all">
    <!---Select2 css-->
    <link href="assets/plugins/select2/css/select2.min.css" rel="stylesheet">
    <!--Mutipleselect css-->
    <link rel="stylesheet" href="assets/plugins/multipleselect/multiple-select.css">
    <!---Jquery.mCustomScrollbar css-->
    <link href="assets/plugins/jquery.mCustomScrollbar/jquery.mCustomScrollbar.css" rel="stylesheet">
    <!---Sidebar css-->
    <link href="assets/plugins/sidebar/sidebar.css" rel="stylesheet">
    <!-- Switcher css -->
    <link href="assets/switcher/css/switcher.css" rel="stylesheet">
    <link href="assets/switcher/demo.css" rel="stylesheet">
    <meta http-equiv="imagetoolbar" content="no">
    <style type="text/css">
        /* Chart.js */
        
        @-webkit-keyframes chartjs-render-animation {
            from {
                opacity: 0.99
            }
            to {
                opacity: 1
            }
        }
        
        @keyframes chartjs-render-animation {
            from {
                opacity: 0.99
            }
            to {
                opacity: 1
            }
        }
        
        .chartjs-render-monitor {
            -webkit-animation: chartjs-render-animation 0.001s;
            animation: chartjs-render-animation 0.001s;
        }
    </style>
	<style>
	.adBanner {
		background-color: transparent;
		height: 1px;
		width: 1px;
	}
	* {
        margin: 0;
}
html, body {
        height: 100%;
}
.wrapper {
        min-height: 100%;
        margin: 0 auto -155px; /* the bottom margin is the negative value of the footer's height */
}
	</style>
</head>

<body>
    <!-- End Switcher -->
    <!-- Loader -->
    <div id="global-loader" style="display: none;"> <img src="assets/img/loader.svg" class="loader-img" alt="Loader"> </div>
    <!-- End Loader -->
    <!-- Page -->
    <div class="page">
        <!-- Main Header-->
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #23262A;">
<div class="container-fluid">
<a class="navbar-brand" href="https://rbxstorm.com"><img src="assets/img/logonav.png" style="width: 200px;"></a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample09" aria-controls="navbarsExample09" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarsExample09">
<ul class="navbar-nav mr-auto" style="font-size: 15px;">
<a style="text-decoration: none;" href="https://rbxstorm.com/">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-home" style="margin-right: 6px;" aria-hidden="true"></i> Home</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/earn">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-money-bill-alt" style="margin-right: 6px;" aria-hidden="true"></i> Earn</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/claim">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-hand-holding-usd" style="margin-right: 6px;" aria-hidden="true"></i> Withdraw</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/promocodes">
<li class="nav-item active">
<span class="nav-link"><i class="fas fa-shopping-cart" style="margin-right: 6px;" aria-hidden="true"></i> Promocodes</span>
</li>
</a>
<a style="text-decoration: none;" href="/quests">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-hat-wizard" style="margin-right: 6px;" aria-hidden="true"></i> Quests<sup style="color:red;padding-left:5px;">NEW!</sup></span>
</li>
</a>

</ul>
<ul class="navbar-nav">
    <li class="nav-item">
<div class="dropdown main-profile-menu" onclick="this.classList.add('show');" id="dropdown-main-profile-menu">
                        <span class="main-img-user"><img alt="avatar" id="robloxUserIMG" style="border-radius: 20%; width: 70%; max-height: 50px; max-width: 50px;" src="https://www.roblox.com/headshot-thumbnail/image?userId=1&width=60&height=60&format=png"></span>
                        <div class="dropdown-menu">
                            <div class="header-navheading">
                                <h6 class="main-notification-title" id="username">Guest</h6>
                            </div>
                            <a class="dropdown-item" href="logout.php"> <i class="fe fe-power"></i> Sign Out </a>
                        </div>
                    </div></li>
    <li class="nav-item">
<div style="border-radius: 10px; font-weight: bold; background-color: #16191D; min-width: 70px; height:43px;padding: 7px;">
<div class="float-left">
<div style="margin-right: 10px;">
<div class="text-center" style="background-color: #f6c344; padding: 2px; padding-right: 3px; padding-left: 3px; font-size: 14px; border-radius: 3px;color:black;">R$</div>
</div>
</div>
<div class="float-right" style="color:white;padding-right:7px;">
<span class="userEarnings"></span> </div>
<div class="clearfix"></div>
</div>
</li>
<li class="nav-item">
    <a>
<button onclick="window.location='https://rbxstorm.com/logout.php';" class="btn btn-warning"><a style="font-size: 15px;padding: 10px;">LOGOUT<i class="fe fe-power" style="color: black; padding-left:7px;"></i></a></button>

</li>
</ul>
</div>
</div>
</nav>
                                        <?php 
                                        $ua = strtolower($_SERVER['HTTP_USER_AGENT']);
                                        if(stripos($ua,'android') !== false) { // && stripos($ua,'mobile') !== false) {
                                        echo '<div style="width:100%;background: #f6c344;box-shadow: 1px 1px 4px rgba(0, 0, 0, 0.3);">
                        <h5 style="color:black;font-weight:400;text-align:center;padding: 8px;">
                RBXStorm App is released on <b>Google Play</b>! Click <a style="font-weight: 400;color: #F44336;" href="https://play.google.com/store/apps/details?id=com.rbxearnrbx.dream" target="_blank">HERE</a> to install!
                </h5>
                </div>';
                                        } else {
                                          echo '<div style="width:100%;background: #f6c344;box-shadow: 1px 1px 4px rgba(0, 0, 0, 0.3);">
                        <h5 style="color:black;font-weight:400;text-align:center;padding: 8px;">
                Invite friends to earn extra <b>robux</b>. Claim your robux on the <a style="font-weight: 400;color: #F44336;" href="/invites">INVITES</a> TAB!
                </h5>
                </div>';
                                        }
                                        ?>
        <!-- Main Content-->
        <div class="main-content pt-0" onclick="document.getElementById('dropdown-main-profile-menu').classList.remove('show');"><br><br>
            <div class="container">
                <!-- Page Header -->
                <!-- End Page Header -->
										<div class="row row-sm">
<div class="col-md-4">
                            <div class="feature feature--featured feature-3 boxed boxed--border bg--white">
                                <h5>Robux earned by you<br></h5><div class="ml-auto">
                                <h3 class="userEarnings"></h3>
                            </div></div>
                        </div>
                        
                        <div class="col-md-4">
                            <div class="feature feature--featured feature-3 boxed boxed--border bg--white">
                                <h5>Total ROBUX earned<br></h5><div class="ml-auto">
                                <h3 class="siteTotalEarned"></h3>
                            </div></div>
                        </div>
                        
                                               <div class="col-md-4">
                            <div class="feature feature--featured feature-3 boxed boxed--border bg--white">
                                <h5>Users online<br></h5><div class="ml-auto">
                                <h3 class="siteOnline"></h3>
                            </div></div>
                        </div>
                        <style>
                            .feature.feature--featured:after {
    background: #f6c344!important;
}
                        </style>
				</div><br>
                <!-- Row -->
				<div class="row row-sm">
				</div>    <script> 
        function Open() { 
            window.open("https://www.youtube.com/channel/UCcihBDnz9DYYQ9a76XsqD3g?sub_confirmation=1", "_blank"); 
        } 
    </script> 
                <div class="row row-sm">
                    <div class="col-sm-12 col-xl-12 col-lg-12">
                        <div class="card custom-card">
                            <div class="card-body">
                                <div>
                                    <h5 class="card-title mb-1">Claim <b style="color: #02b757;">Promocodes</b></h5>
                                    <p class="text-muted mb-0 card-sub-title">Get <b>robux</b> by claiming promocodes instantly!</p>
                                </div>
                            </div>
							<div class="card-body" style="padding-left: 0px; padding-right: 0px;">
								<div class="row" style="margin-left: 20px; margin-right: 20px;">
									<input type="text" id="promoCodeInput" class="form-control" placeholder="Promocode"></div><br>
																	<div class="row" style="margin-left: 20px; margin-right: 20px;">
									<button type="submit" class="btn ripple btn-warning btn-lg btn-block" onclick="claimCode();">Claim Promocode</button>
									</div>
								</div>
								<br />
								<div class="row" style="margin-left: 50px; margin-right: 50px;">
									<div class="table-responsive">
										<table class="table mg-b-0">
											<thead>
												<tr>
													<th scope="col">Promocode</th>
													<th scope="col">Amount</th>
													<th scope="col">Time</th>
												</tr>
											</thead>
											<tbody id="promocodeClaims">
											</tbody>
										</table><br>
									</div>
								</div>
							</div>
                        </div>
                    </div>
               <br> <!-- End Row -->
            </div></div></div>
                
        <!-- End Main Content-->
        <!-- Main Footer-->
       <footer class="text-center-xs space--xs bg--dark ">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">

                            <p>We are not affiliated with any of the games or companies shown on this website. Use of any logos or trademarks are for reference purposes only. By utilizing the website, you agree to be bound by the terms of service.
</p>
                        </div>
                        <div class="col-md-6 text-right text-center-xs">
                            <ul class="social-list list-inline list--hover">
                            </ul>
                        </div>
                    </div>
                    <!--end of row-->
                    <div class="row">
                        <div class="col-md-2 col-sm-4">

                            <a class="type--fine-print" href="/legal">Terms &amp; Conditions</a>

                        </div>

                      <div class="col-md-2 col-sm-4">
                            <a class="type--fine-print" href="/sell/index">Panel</a>
                        </div>

                   <div class="col-md-8 col-sm-4 text-right text-center-xs">
 <span class="type--fine-print">RBXStorm
                                    <span class="update-year">2020</span></span>
                                       </div>
                    </div>
                </div>
            </footer>
        <!--End Footer-->
    </div>
    <!-- End Page -->
    <!-- Back-to-top --><a href="#top" id="back-to-top"><i class="fe fe-arrow-up"></i></a>
    <!-- Jquery js-->
    <script src="assets/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap js-->
    <script src="assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Ionicons js-->
    <script src="assets/plugins/ionicons/ionicons.js"></script>
    <!-- Rating js-->
    <script src="assets/plugins/rating/jquery.rating-stars.js"></script>
    <!-- Chart.Bundle js-->
    <script src="assets/plugins/chart.js/Chart.bundle.min.js"></script>
    <!-- Apexcharts js-->
    <script src="assets/plugins/apexcharts/apexcharts.js"></script>
    <script src="assets/plugins/apexcharts/irregular-data-series.js"></script>
    <!-- Peity js-->
    <script src="assets/plugins/peity/jquery.peity.min.js"></script>
    <!-- Flot Chart js-->
    <script src="assets/plugins/jquery.flot/jquery.flot.js"></script>
    <script src="assets/plugins/jquery.flot/jquery.flot.pie.js"></script>
    <script src="assets/plugins/jquery.flot/jquery.flot.resize.js"></script>
    <!-- Jquery-Ui js-->
    <script src="assets/plugins/jquery-ui/ui/widgets/datepicker.js"></script>
    <!-- Select2 js-->
    <script src="assets/plugins/select2/js/select2.min.js"></script>
    <!--MutipleSelect js-->
    <script src="assets/plugins/multipleselect/multiple-select.js"></script>
    <script src="assets/plugins/multipleselect/multi-select.js"></script>
    <!-- Sidebar js-->
    <script src="assets/plugins/sidebar/sidebar.js"></script>
    <!-- Jquery.mCustomScrollbar js-->
    <script src="assets/plugins/jquery.mCustomScrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <!-- Perfect-scrollbar js-->
    <script src="assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <!-- Switcher js -->
    <script src="assets/switcher/js/switcher.js"></script>
    <!-- Sticky js-->
    <script src="assets/js/sticky.js"></script>
    <!-- Dashboard js-->
    <script src="assets/js/index.js"></script>
    <!-- Custom js-->
    <script src="assets/js/custom.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
    <svg id="SvgjsSvg1001" width="2" height="0" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" style="overflow: hidden; top: -100%; left: -100%; position: absolute; opacity: 0;">
        <defs id="SvgjsDefs1002"></defs>
        <polyline id="SvgjsPolyline1003" points="0,0"></polyline>
        <path id="SvgjsPath1004" d="M0 0 "></path>
    </svg>
    <div id="ui-datepicker-div" class="ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all"></div>
    <div class="main-navbar-backdrop" onclick="document.body.classList.remove('main-navbar-show');"></div>
	<script>
		function httpGet(theUrl) {
			var xmlHttp = new XMLHttpRequest();
			xmlHttp.open( "GET", theUrl, false );
			xmlHttp.send( null );
			return xmlHttp.responseText;
		}
	
		function loadinfo() {
			var info = JSON.parse(httpGet("api/stats.php"));
				
			document.getElementById('username').innerHTML = info.username;
			document.getElementById('robloxUserIMG').src = info.userImg;
			var name = document.getElementsByClassName("siteName");
			for(var i=0; i<name.length; i++) {
				name[i].innerHTML = info.siteName;
			}
			var roux = document.getElementsByClassName("siteOnline");
			for(var i=0; i<roux.length; i++) {	
				roux[i].innerHTML = info.online;
			}
			var usr = document.getElementsByClassName("siteTotalEarned");
			for(var i=0; i<usr.length; i++) {	
				usr[i].innerHTML = info.totalEarned+" R$";
			}
			var robux = document.getElementsByClassName("userEarnings");
			for(var i=0; i<robux.length; i++) {	
				robux[i].innerHTML = info.userEarnings+" R$";
			}
			document.getElementById('promocodeClaims').innerHTML = httpGet("api/a.php?tablePromo");
			document.title = info.siteName+" | FREE ROBUX!";
		}
		
		function claimCode() {
			var code = document.getElementById('promoCodeInput').value;
			var dablit = JSON.parse(httpGet("api/a.php?claimPromo="+code));
			if (dablit['success']) {
				Swal.fire({
					icon: 'success',
					title: 'Yeah!',
					text: dablit['message'],
				});
			} else {
				Swal.fire({
					icon: 'error',
					title: 'Oops..',
					text: dablit['message'],
				});
			}
			document.getElementById('promoCodeInput').value = '';
		}
		
		loadinfo();
		var intervalID = window.setInterval(loadinfo, 35000);
			var info = httpGet("api/a.php?isLoggedIn");
			if (info != "1") {
				window.location.href = "index";
			} else {
				njdsnsdf
			}
	</script>
	<?php echo include_once (dirname(__FILE__) . '/pa_antiadblock_3089086.php'); ?>
	<script src="https://kit.fontawesome.com/242685ebbc.js" crossorigin="anonymous"></script>
<script type="text/javascript">window.$crisp=[];window.CRISP_WEBSITE_ID="a07a442c-a0e4-4d76-8f46-b031e5b3793c";(function(){d=document;s=d.createElement("script");s.src="https://client.crisp.chat/l.js";s.async=1;d.getElementsByTagName("head")[0].appendChild(s);})();</script>
</html>