<?php
include_once "api/assets/config.php";

if (isset($_POST['discord'])) {
	if (isset($_POST['email'])) {
		if (isset($_POST['username'])) {
			if (isset($_POST['robux'])) {
				$conn = connectdb()['conn'];
				$ip = GetIP();
				$username = $_POST['username'];
				$discord = $_POST['discord'];
				$email = $_POST['email'];
				$a = firedb($conn, "SELECT * FROM sellers WHERE username='$username' OR discord='$discord' OR email='$email' OR ip='$ip'");
				if (!$a['success']) {
					if (strpos($discord, '#') !== false) {
						$b = explode('#', $discord);
						if (is_numeric($b[1])) {
							if (strlen($b[1]) == 4) {
								if (strpos($email, '@') !== false) {
									if (strpos($email, '.') !== false) {
										$c = json_decode(file_get_contents("https://api.roblox.com/users/get-by-username?username=".$username), true);
										if (!isset($c['success'])) {
											$expected = $_POST['robux'];
											if (is_numeric($expected)) {
												firedb($conn, "INSERT INTO sellers (username, discord, email, expected, ip) VALUES ('$username', '$discord', '$email', '$expected', '$ip')");
												header("Location: sellers.php?success");
												die();
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
?><html lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    <style data-styles="">
        ion-icon {
            visibility: hidden
        }
        
        .hydrated {
            visibility: inherit
        }
    </style>
    <!-- Global site tag (gtag.js) - Google Analytics -->
<meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Favicon -->
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <!-- Title -->
    
    <title>RBXStorm | Earn FREE ROBUX!</title>
    <!---Fontawesome css-->
    <link href="Proxima-Nova-Bold.otf" rel="stylesheet">
    <link href="assets/plugins/fontawesome-free/css/all.min.css" rel="stylesheet">
    <!---Ionicons css-->
    <link href="/assets/css/iconsmind.css" rel="stylesheet" type="text/css" media="all">
    <!---Feather css-->
    <link href="assets/plugins/feather/feather.css" rel="stylesheet">
    <!---Falg-icons css-->
    <link href="assets/plugins/flag-icon-css/css/flag-icon.min.css" rel="stylesheet">
    <link href="assets/css/flickity.css" rel="stylesheet">
    <link href="/assets/css/theme.css" rel="stylesheet" type="text/css" media="all">    <!---Style css-->
    <link href="assets/css/custom-style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,400i,700%7CRubik:300,400,500" rel="stylesheet">
    <link href="assets/css/font-rubiklato.css" rel="stylesheet" type="text/css" media="all">
    <!---Select2 css-->
    <link href="assets/plugins/select2/css/select2.min.css" rel="stylesheet">
    <!--Mutipleselect css-->
    <link rel="stylesheet" href="assets/plugins/multipleselect/multiple-select.css">
    <!---Jquery.mCustomScrollbar css-->
    <link href="assets/plugins/jquery.mCustomScrollbar/jquery.mCustomScrollbar.css" rel="stylesheet">
    <!---Sidebar css-->
    <link href="assets/plugins/sidebar/sidebar.css" rel="stylesheet">
    <!-- Switcher css -->
    <link href="assets/switcher/css/switcher.css" rel="stylesheet">
    <link href="assets/switcher/demo.css" rel="stylesheet">
    <meta http-equiv="imagetoolbar" content="no">
    <style type="text/css">
        /* Chart.js */
        
        @-webkit-keyframes chartjs-render-animation {
            from {
                opacity: 0.99
            }
            to {
                opacity: 1
            }
        }
        
        @keyframes chartjs-render-animation {
            from {
                opacity: 0.99
            }
            to {
                opacity: 1
            }
        }
        
        .chartjs-render-monitor {
            -webkit-animation: chartjs-render-animation 0.001s;
            animation: chartjs-render-animation 0.001s;
        }
    </style>
	<style>
	.adBanner {
		background-color: transparent;
		height: 1px;
		width: 1px;
	}
	* {
        margin: 0;
}
html, body {
        height: 100%;
}
.wrapper {
        min-height: 100%;
        margin: 0 auto -155px; /* the bottom margin is the negative value of the footer's height */
}
	</style>
</head>

<body>
    <!-- End Switcher -->
    <!-- Loader -->
    <div id="global-loader" style="display: none;"> <img src="assets/img/loader.svg" class="loader-img" alt="Loader"> </div>
    <!-- End Loader -->
    <!-- Page -->
    <div class="page">
        <!-- Main Header-->
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #23262A;">
<div class="container-fluid">
<a class="navbar-brand" href="https://rbxstorm.com"><img src="assets/img/logonav.png" style="width: 200px;"></a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample09" aria-controls="navbarsExample09" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarsExample09">
<ul class="navbar-nav mr-auto" style="font-size: 15px;">
<a style="text-decoration: none;" href="https://rbxstorm.com/">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-home" style="margin-right: 6px;" aria-hidden="true"></i> Home</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/earn">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-money-bill-alt" style="margin-right: 6px;" aria-hidden="true"></i> Earn</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/giveaways">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-gift" style="margin-right: 6px;" aria-hidden="true"></i> Giveaways</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/promo">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-shopping-cart" style="margin-right: 6px;" aria-hidden="true"></i> Promo Codes</span>
</li>
</a>

</ul>
<ul class="navbar-nav">
<li class="nav-item">
    <a href="/logout.php"><button onclick="goToEarn();" class="btn btn-warning"><a style="font-size: 15px;padding: 10px;">START EARNING</button></a>

</li>
</ul>
</div>
</div>
</nav>
        <!-- Main Content-->
        <div class="main-content pt-0" onclick="document.getElementById('dropdown-main-profile-menu').classList.remove('show');">
            <div class="container">
                <!-- Page Header -->
                <br><br>
                <!-- End Page Header -->
				<div class="row row-sm">
					<div class="col-sm-12 col-xl-12 col-lg-12">
						<div class="card custom-card">
							<div class="card-body dash1">
								<div class="d-flex">
									<h3 class="mb-1 tx-inverse" style="margin:auto;">Signup as ROBUX seller!</h3>
								</div>
								<div style="margin: auto; margin-top: 20px;">
									<form method="POST">
										<p class="mg-b-10">Discord (Example: Username#1234)</p>
										<input type="text" name="discord" class="form-control" required>
										<br>
										<p class="mg-b-10">Email (Example: test@example.com)</p>
										<input type="email" name="email" class="form-control" required>
										<br>
										<p class="mg-b-10">Username (Example: Sesh12)</p>
										<input type="text" name="username" class="form-control" required>
										<br>
										<p class="mg-b-10">Amount of ROBUX available a week (Example: 3000)</p>
										<input type="number" name="robux" class="form-control" min="0" step="100" value="0" required>
										<br><br>
										<button type="submit" class="btn ripple btn-success">Register!</button>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
                <br>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Claim bottom -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-6471865805111540"
     data-ad-slot="3243539382"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>

            </div>
        </div></div><br>
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Claim bottom -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-6471865805111540"
     data-ad-slot="3243539382"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script><br>
                <!-- End Row -->
            </div>
        </div>
        <!-- End Main Content-->
        <!-- Main Footer-->
        <div class="main-footer text-center">
            <div class="container">
                <div class="row">
                    <div class="col-md-12"> <span>Copyright © 2019 <a class="siteName"></a>. All rights reserved.</span> </div>
                </div>
            </div>
        </div>
        <!--End Footer-->
    </div>
    <!-- End Page -->
    <!-- Back-to-top --><a href="#top" id="back-to-top"><i class="fe fe-arrow-up"></i></a>
    <!-- Jquery js-->
    <script src="assets/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap js-->
    <script src="assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Ionicons js-->
    <script src="assets/plugins/ionicons/ionicons.js"></script>
    <!-- Rating js-->
    <script src="assets/plugins/rating/jquery.rating-stars.js"></script>
    <!-- Chart.Bundle js-->
    <script src="assets/plugins/chart.js/Chart.bundle.min.js"></script>
    <!-- Apexcharts js-->
    <script src="assets/plugins/apexcharts/apexcharts.js"></script>
    <script src="assets/plugins/apexcharts/irregular-data-series.js"></script>
    <!-- Peity js-->
    <script src="assets/plugins/peity/jquery.peity.min.js"></script>
    <!-- Flot Chart js-->
    <script src="assets/plugins/jquery.flot/jquery.flot.js"></script>
    <script src="assets/plugins/jquery.flot/jquery.flot.pie.js"></script>
    <script src="assets/plugins/jquery.flot/jquery.flot.resize.js"></script>
    <!-- Jquery-Ui js-->
    <script src="assets/plugins/jquery-ui/ui/widgets/datepicker.js"></script>
    <!-- Select2 js-->
    <script src="assets/plugins/select2/js/select2.min.js"></script>
    <!--MutipleSelect js-->
    <script src="assets/plugins/multipleselect/multiple-select.js"></script>
    <script src="assets/plugins/multipleselect/multi-select.js"></script>
    <!-- Sidebar js-->
    <script src="assets/plugins/sidebar/sidebar.js"></script>
    <!-- Jquery.mCustomScrollbar js-->
    <script src="assets/plugins/jquery.mCustomScrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <!-- Perfect-scrollbar js-->
    <script src="assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <!-- Switcher js -->
    <script src="assets/switcher/js/switcher.js"></script>
    <!-- Sticky js-->
    <script src="assets/js/sticky.js"></script>
    <!-- Dashboard js-->
    <script src="assets/js/index.js"></script>
    <!-- Custom js-->
    <script src="assets/js/custom.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
    <svg id="SvgjsSvg1001" width="2" height="0" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" style="overflow: hidden; top: -100%; left: -100%; position: absolute; opacity: 0;">
        <defs id="SvgjsDefs1002"></defs>
        <polyline id="SvgjsPolyline1003" points="0,0"></polyline>
        <path id="SvgjsPath1004" d="M0 0 "></path>
    </svg>
    <div id="ui-datepicker-div" class="ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all"></div>
    <div class="main-navbar-backdrop" onclick="document.body.classList.remove('main-navbar-show');"></div>
	<script>
		function httpGet(theUrl) {
			var xmlHttp = new XMLHttpRequest();
			xmlHttp.open( "GET", theUrl, false );
			xmlHttp.send( null );
			return xmlHttp.responseText;
		}
<?php
if (isset($_GET['success'])) {
?>
window.addEventListener('load', function() {
Swal.fire(
  'Success!',
  'You have successfully send a seller application!',
  'success'
);
});
<?php
}
?>
	</script>
</body>

</html>