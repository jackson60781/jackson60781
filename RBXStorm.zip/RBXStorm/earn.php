<?php echo include_once (dirname(__FILE__) . '/pa_antiadblock_3089086.php'); ?><html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    <style data-styles="">
        ion-icon {
            visibility: hidden
        }
        
        .hydrated {
            visibility: inherit
        }
    </style>
    <!-- Global site tag (gtag.js) - Google Analytics -->
<meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Favicon -->
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <!-- Title -->
    
  <title>RBXStorm - Earn Free Robux Now</title>
  <meta name="description" content="Earn free robux by watching videos playing games and completing simple tasks. Start earning today.">
  <meta name="keywords" content="robux,free,promocodes,codes">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intro.js/2.9.3/introjs.min.css" integrity="sha256-/oZ7h/Jkj6AfibN/zTWrCoba0L+QhP9Tf/ZSgyZJCnY=" crossorigin="anonymous" />
      <link rel="stylesheet" href="https://raw.githubusercontent.com/usablica/intro.js/master/themes/introjs-dark.css">
    <link href="assets/plugins/fontawesome-free/css/all.min.css" rel="stylesheet">
    <link href="/assets/css/theme.css" rel="stylesheet" type="text/css" media="all">    <!---Style css-->
    <link href="assets/css/custom-style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,400i,700%7CRubik:300,400,500" rel="stylesheet">
    <link href="assets/css/font-rubiklato.css" rel="stylesheet" type="text/css" media="all">
    <meta http-equiv="imagetoolbar" content="no">
    <!-- Global site tag (gtag.js) - Google Analytics -->

    <style type="text/css">
        /* Chart.js */
        
        @-webkit-keyframes chartjs-render-animation {
            from {
                opacity: 0.99
            }
            to {
                opacity: 1
            }
        }
        
        @keyframes chartjs-render-animation {
            from {
                opacity: 0.99
            }
            to {
                opacity: 1
            }
        }
        
        .chartjs-render-monitor {
            -webkit-animation: chartjs-render-animation 0.001s;
            animation: chartjs-render-animation 0.001s;
        }
    </style>
	<style>
	.adBanner {
		background-color: transparent;
		height: 1px;
		width: 1px;
	}
	* {
        margin: 0;
}
html, body {
        height: 100%;
}
.wrapper {
        min-height: 100%;
        margin: 0 auto -155px; /* the bottom margin is the negative value of the footer's height */
}
	</style>
</head>

<body onload="loadAdgate();">
    <!-- End Switcher -->
    <!-- End Loader -->
    <!-- Page -->
    <div class="page">
        <!-- Main Header-->
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #23262A;">
<div class="container-fluid">
<a class="navbar-brand" href="https://rbxstorm.com"><img src="assets/img/logonav.png" style="width: 200px;"></a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample09" aria-controls="navbarsExample09" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarsExample09">
<ul class="navbar-nav mr-auto" style="font-size: 15px;">
<a style="text-decoration: none;" href="https://rbxstorm.com/">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-home" style="margin-right: 6px;" aria-hidden="true"></i> Home</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/earn">
<li class="nav-item active">
<span class="nav-link"><i class="fas fa-money-bill-alt" style="margin-right: 6px;" aria-hidden="true"></i> Earn</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/claim">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-hand-holding-usd" style="margin-right: 6px;" aria-hidden="true"></i> Withdraw</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/promocodes">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-shopping-cart" style="margin-right: 6px;" aria-hidden="true"></i> Promo Codes</span>
</li>
</a>
<a style="text-decoration: none;" href="/quests">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-hat-wizard" style="margin-right: 6px;" aria-hidden="true"></i> Quests<sup style="color:red;padding-left:5px;">NEW!</sup></span>
</li>
</a>
</ul>




<ul class="navbar-nav">

    <li class="nav-item">
<div class="dropdown main-profile-menu" onclick="this.classList.add('show');" id="dropdown-main-profile-menu">
                        <span class="main-img-user"><img alt="avatar" id="robloxUserIMG" style="border-radius: 20%; width: 70%; max-height: 50px; max-width: 50px;" src="https://www.roblox.com/headshot-thumbnail/image?userId=1&width=60&height=60&format=png"></span>
                        <div class="dropdown-menu">
                            <div class="header-navheading">
                                <h6 class="main-notification-title" id="username">Guest</h6>
                            </div>
                            <a class="dropdown-item" href="logout.php"> <i class="fe fe-power"></i> Sign Out </a>
                        </div>
                    </div></li>

    <li class="nav-item">
<div style="border-radius: 10px; font-weight: bold; background-color: #16191D; min-width: 70px; height:43px;padding: 7px;">
<div class="float-left">
<div style="margin-right: 10px;">
<div class="text-center" style="background-color: #f6c344; padding: 2px; padding-right: 3px; padding-left: 3px; font-size: 14px; border-radius: 3px;color:black;">R$</div>
</div>
</div>
<div class="float-right" style="color:white;padding-right:7px;">
<span class="userEarnings">0</span> </div>
<div class="clearfix"></div>
</div>
</li>
<li class="nav-item">
    <a>
<button onclick="window.location='https://rbxstorm.com/logout.php';" class="btn btn-warning"><a style="font-size: 15px;padding: 10px;">LOGOUT<i class="fe fe-power" style="color: black; padding-left:7px;"></i></a></button>

</li>
</ul>
</div>
</div>
</nav>           
                                        <?php 
                                        $ua = strtolower($_SERVER['HTTP_USER_AGENT']);
                                        if(stripos($ua,'android') !== false) { // && stripos($ua,'mobile') !== false) {
                                        echo '<div style="width:100%;background: #f6c344;box-shadow: 1px 1px 4px rgba(0, 0, 0, 0.3);">
                        <h5 style="color:black;font-weight:400;text-align:center;padding: 8px;">
                RBXStorm App is released on <b>Google Play</b>! Click <a style="font-weight: 400;color: #F44336;" href="https://play.google.com/store/apps/details?id=com.rbxearnrbx.dream" target="_blank">HERE</a> to install!
                </h5>
                </div>';
                                        } else {
                                          echo '<div style="width:100%;background: #f6c344;box-shadow: 1px 1px 4px rgba(0, 0, 0, 0.3);">
                        <h5 style="color:black;font-weight:400;text-align:center;padding: 8px;">
                Invite friends to earn extra <b>robux</b>. Claim your robux on the <a style="font-weight: 400;color: #F44336;" href="/invites">INVITES</a> TAB!
                </h5>
                </div>';
                                        }
                                        ?>
        <!-- Main Content-->
        <div class="main-content pt-0" onclick="document.getElementById('dropdown-main-profile-menu').classList.remove('show');">

                                        
            <div class="container">
                <!-- Page Header -->
                <div class="page-header"><br>
                    <div>
                        <br><h2 class="main-content-title tx-24 mg-b-5">Welcome To RBXStorm!</h2>
                        <h5 class="text-muted">Complete offers and receive robux!</h5><br>
                    </div>
					<noscript>
						<div class="alert alert-solid-danger mg-b-0" role="alert">
							<meta http-equiv="refresh" content="0; URL='index'" />
						</div>
					</noscript>
                </div>
                <!-- End Page Header -->
							<div class="row row-sm">
<div class="col-md-4">
                            <div class="feature feature--featured feature-3 boxed boxed--border bg--white"  data-intro='Your robux balance will appear here!' class='introduction-farm' data-step="2">
                                <h5>Robux earned by you<br></h5><div class="ml-auto">
                                <h3 class="userEarnings"></h3>
                            </div></div>
                        </div>
                        
                        <div class="col-md-4">
                            <div class="feature feature--featured feature-3 boxed boxed--border bg--white">
                                <h5>Total ROBUX earned<br></h5><div class="ml-auto">
                                <h3 class="siteTotalEarned"></h3>
                            </div></div>
                        </div>
                        
                                               <div class="col-md-4">
                            <div class="feature feature--featured feature-3 boxed boxed--border bg--white">
                                <h5>Users online<br></h5><div class="ml-auto">
                                <h3 class="siteOnline"></h3>
                            </div></div>
                        </div>
                        <style>
                            .feature.feature--featured:after {
    background: #f6c344!important;
}
                        </style>
				</div><br>
                <!-- Row -->
				<div class="row row-sm">
				</div>

    <br>
    <div class="row">
        <div class="col-sm-6">
				<button type="button" class="btn ripple btn-warning btn-lg btn-block" onclick="OpenYT()">SUBSCRIBE FOR 20% BOOST!</button>
              </div> <div class="col-sm-6"> 
               				<button type="button" class="btn ripple btn-warning btn-lg btn-block" onclick="OpenDiscord()">Join the Discord </button>
</div></div>
                <br><div class="row row-sm">
                    <div class="col-sm-12 col-xl-12 col-lg-12">
                        <div class="card custom-card">
                            <div class="card-body" data-intro='Earn robux here! Complete offers for robux!' class='introduction-farm' data-step="1">
                                <div>
                                    <h6 class="card-title mb-1">Earn <b style="color: #02b757;">ROBUX</b></h6>
                                    <p class="text-muted mb-0 card-sub-title">Earn your beloved <b>robux</b></p>
                                </div>
                            </div>
							<div class="card-body" style="padding-left: 0px; padding-right: 0px;">
								<div class="row" style="margin-left: 20px; margin-right: 20px;">
										<button class="btn btn-success" onclick="loadAdgate();" style="width: 130px;"><i class="fa fa-coins"></i> Most earning</button>
                                        <button class="btn btn-danger" onclick="loadOffertoro();" style="width: 130px;"><i class="fa fa-fire"></i> Easiest Offers</button>
								        <button class="btn btn-warning float-right" href="javascript:void(0);" onclick="javascript:introJs().start();" style="padding: 10px;">Tutorial</button>
                                </div>
								<br>
								<iframe style="width: 100%; height: 700px; border: 0;" id="iFrameOfferWallyeye" src="https://wall.adgaterewards.com/nqiZqA/1"></iframe>
							</div>
                        </div>
                    </div>
                    
                    
               <br> <!-- End Row -->

</div></div>
</section></div>
               <section class="text-center">
                <div class="container" style="margin-top:0px;margin-bottom:0px;">
     <div class="row justify-content-center">
                        <div class="col-md-10 col-lg-6">
                            <div class="boxed boxed--lg bg--dark subscribe-form-1" style="background:#f7f7f7;border:1px solid #d6d6d6;">
                                                            <h3 style="color:#212121;">Have any issues?</h3>
                                                            <p style="color:#666666;">Join our discord server, where our staff and community can help you with any troubles you have!</p>
               				<button type="button" class="btn ripple btn-warning btn-lg btn-block" onclick="OpenDiscord()">Join the Discord</button>
</div>

</div>
            </div>
</div></div>
                
        <!-- End Main Content-->
        <!-- Main Footer-->
       <footer class="text-center-xs space--xs bg--dark ">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">

                            <p>We are not affiliated with any of the games or companies shown on this website. Use of any logos or trademarks are for reference purposes only. By utilizing the website, you agree to be bound by the terms of service.
</p>
                        </div>
                        <div class="col-md-6 text-right text-center-xs">
                            <ul class="social-list list-inline list--hover">
                            </ul>
                        </div>
                    </div>
                    <!--end of row-->
                    <div class="row">
                        <div class="col-md-2 col-sm-4">

                            <a class="type--fine-print" href="/legal">Terms &amp; Conditions</a>

                        </div>

                      <div class="col-md-2 col-sm-4">
                            <a class="type--fine-print" href="/sell/index">Panel</a>
                        </div>

                   <div class="col-md-8 col-sm-4 text-right text-center-xs">
 <span class="type--fine-print">RBXStorm
                                    <span class="update-year">2020</span></span>
                                       </div>
                    </div>
                </div>
            </footer>
        <!--End Footer-->
    </div>
    <!-- End Page -->
    <!-- Back-to-top --><a href="#top" id="back-to-top"><i class="fe fe-arrow-up"></i></a>
    <!-- Jquery js-->
    <script src="assets/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap js-->
    <script src="assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
    <div class="main-navbar-backdrop" onclick="document.body.classList.remove('main-navbar-show');"></div>
	<script>
		function httpGet(theUrl) {
			var xmlHttp = new XMLHttpRequest();
			xmlHttp.open( "GET", theUrl, false );
			xmlHttp.send( null );
			return xmlHttp.responseText;
		}
	
		function loadinfo() {
			var info = JSON.parse(httpGet("api/stats.php"));
				
			document.getElementById('username').innerHTML = info.username;
			document.getElementById('robloxUserIMG').src = info.userImg;
			var name = document.getElementsByClassName("siteName");
			for(var i=0; i<name.length; i++) {
				name[i].innerHTML = info.siteName;
			}
			var roux = document.getElementsByClassName("siteOnline");
			for(var i=0; i<roux.length; i++) {	
				roux[i].innerHTML = info.online;
			}
			var usr = document.getElementsByClassName("siteTotalEarned");
			for(var i=0; i<usr.length; i++) {	
				usr[i].innerHTML = info.totalEarned+" R$";
			}
			var robux = document.getElementsByClassName("userEarnings");
			for(var i=0; i<robux.length; i++) {	
				robux[i].innerHTML = info.userEarnings+" R$";
			}
			
			document.title = info.siteName+" | FREE ROBUX!";
		}
		
		loadinfo();
		
		function loadAdgate() {
			var info = JSON.parse(httpGet("api/stats.php"));
			document.getElementById('iFrameOfferWallyeye').src = info.adgate;
		}
		        function loadOffertoro() {
            var info = JSON.parse(httpGet("api/stats.php"));
            document.getElementById('iFrameOfferWallyeye').src = info.offertoro;
        }
		var intervalID = window.setInterval(loadinfo, 35000);
			var info = httpGet("api/a.php?isLoggedIn");
			if (info != "1") {
				window.location.href = "index";
			}
	</script>
	<script async src="https://www.googletagmanager.com/gtag/js?id=UA-155017871-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-155017871-1');
</script>
				
				<script> 
        function OpenYT() { 
            window.open("https://www.youtube.com/channel/UCcihBDnz9DYYQ9a76XsqD3g?sub_confirmation=1", "_blank"); 
        } 
        function OpenDiscord() { 
            window.open("https://discord.gg/q4NsXB7", "_blank"); 
        } 
    </script> 
    <script src="https://kit.fontawesome.com/242685ebbc.js" crossorigin="anonymous"></script>
<script type="text/javascript">window.$crisp=[];window.CRISP_WEBSITE_ID="a07a442c-a0e4-4d76-8f46-b031e5b3793c";(function(){d=document;s=d.createElement("script");s.src="https://client.crisp.chat/l.js";s.async=1;d.getElementsByTagName("head")[0].appendChild(s);})();</script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/intro.js/2.9.3/intro.min.js" integrity="sha256-fOPHmaamqkHPv4QYGxkiSKm7O/3GAJ4554pQXYleoLo=" crossorigin="anonymous"></script>
</body>

</html>