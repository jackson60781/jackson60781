<?php
include_once "../api/assets/config.php";
function ereror() {
    die(file_get_contents("https://rblx.click/404.shtml"));
}
if (!isset($_GET['user']) || !isset($_GET['secret']) || !isset($_GET['robux']) || !isset($_GET['payout'])) {
    ereror();
}
if (md5($_GET['secret']) != md5("73427f87a4fb5326926a1453274717c8")) {
    ereror();
}
$robux = round($_GET['robux']);
$user = round($_GET['user']);
$payout = $_GET['payout'];
$conn = connectdb()["conn"];
$user = firedb($conn, "SELECT * FROM users WHERE id=".$user)['results'][0];
$newbal = $user['balance']+$robux;
firedb($conn, "INSERT INTO offersdone (uid, rid, username, amount, dollar, offerwall, status) VALUES ('".$user['id']."', '".$user['uid']."', '".$user['username']."', '$robux', '$payout', 'Offertoro', '1')", "INSERT");
firedb($conn, "UPDATE users SET balance='$newbal' WHERE id=".$user['id'], "UPDATE");
?>
1