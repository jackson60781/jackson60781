<?php
include_once "../api/assets/config.php";
if (!isset($_SESSION['a']['p'])) {
	die();
}
if (md5($_SESSION['a']['p']) != md5($adminpass)) {
	die();
}
$conn = connectdb()['conn'];
$s = getSettings($conn);
if (isset($_GET['action'])) {
	$a = $_GET['action'];
	if ($a == "give") {
		$b = $_GET['username'];
		$c = $_GET['amount'];
		$user = firedb($conn, "SELECT * FROM users WHERE username='".$b."'")['results'][0];
		$newbal = $user['balance']+$c;
		firedb($conn, "UPDATE users SET balance='$newbal' WHERE id=".$user['id'], "UPDATE");
		header("Location: admin.php?a");
		die();
	}
	if ($a == "maintenancetoggle") {
		firedb($conn, "UPDATE settings SET m='1' WHERE id=1", "UPDATE");
		header("Location: admin.php?b");
		die();
	}
	if ($a == "maintenancetogglee") {
		firedb($conn, "UPDATE settings SET m='0' WHERE id=1", "UPDATE");
		header("Location: admin.php?b");
		die();
	}
	if ($a == "changeCookie") {
		$b = $_GET['cookie'];
		$c = $_GET['groupid'];
		$d = $_GET['stock'];
		firedb($conn, "UPDATE settings SET cookie='$b' WHERE id=1", "UPDATE");
		firedb($conn, "UPDATE settings SET stock='$d' WHERE id=1", "UPDATE");
		firedb($conn, "UPDATE settings SET groupid='$c' WHERE id=1", "UPDATE");
		header("Location: admin.php?c");
		die();
	}
}
?><html lang="en">

<head>
    <style data-styles="">
        ion-icon {
            visibility: hidden
        }
        
        .hydrated {
            visibility: inherit
        }
    </style>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport">
    <meta name="description" content="Dashlead -  Admin Panel HTML Dashboard Template">
    <meta name="author" content="Spruko Technologies Private Limited">
    <meta name="keywords" content="sales dashboard, admin dashboard, bootstrap 4 admin template, html admin template, admin panel design, admin panel design, bootstrap 4 dashboard, admin panel template, html dashboard template, bootstrap admin panel, sales dashboard design, best sales dashboards, sales performance dashboard, html5 template, dashboard template">
    <!-- Favicon -->
    <link rel="icon" href="../assets/img/brand/favicon.ico" type="image/x-icon">
    <!-- Title -->
    <title></title>
    <!---Fontawesome css-->
    <link href="../assets/plugins/fontawesome-free/css/all.min.css" rel="stylesheet">
    <!---Ionicons css-->
    <link href="../assets/plugins/ionicons/css/ionicons.min.css" rel="stylesheet">
    <!---Typicons css-->
    <link href="../assets/plugins/typicons.font/typicons.css" rel="stylesheet">
    <!---Feather css-->
    <link href="../assets/plugins/feather/feather.css" rel="stylesheet">
    <!---Falg-icons css-->
    <link href="../assets/plugins/flag-icon-css/css/flag-icon.min.css" rel="stylesheet">
    <!---Style css-->
    <link href="../assets/css/style.css" rel="stylesheet">
    <link href="../assets/css/custom-style.css" rel="stylesheet">
    <link href="../assets/css/skins.css" rel="stylesheet">
    <link href="../assets/css/dark-style.css" rel="stylesheet">
    <link href="../assets/css/custom-dark-style.css" rel="stylesheet">
    <link href="../assets/css/dashboard.css" rel="stylesheet">
    <!---Select2 css-->
    <link href="../assets/plugins/select2/css/select2.min.css" rel="stylesheet">
    <!--Mutipleselect css-->
    <link rel="stylesheet" href="../assets/plugins/multipleselect/multiple-select.css">
    <!---Jquery.mCustomScrollbar css-->
    <link href="../assets/plugins/jquery.mCustomScrollbar/jquery.mCustomScrollbar.css" rel="stylesheet">
    <!---Sidebar css-->
    <link href="../assets/plugins/sidebar/sidebar.css" rel="stylesheet">
    <!-- Switcher css -->
    <link href="../assets/switcher/css/switcher.css" rel="stylesheet">
    <link href="../assets/switcher/demo.css" rel="stylesheet">
    <meta http-equiv="imagetoolbar" content="no">
    <style type="text/css">
        /* Chart.js */
        
        @-webkit-keyframes chartjs-render-animation {
            from {
                opacity: 0.99
            }
            to {
                opacity: 1
            }
        }
        
        @keyframes chartjs-render-animation {
            from {
                opacity: 0.99
            }
            to {
                opacity: 1
            }
        }
        
        .chartjs-render-monitor {
            -webkit-animation: chartjs-render-animation 0.001s;
            animation: chartjs-render-animation 0.001s;
        }
    </style>
    <link href="../assets/css/dab.css" rel="stylesheet">
	<link href="../assets/css/custom.css" rel="stylesheet">
</head>

<body>
    <!-- End Switcher -->
    <!-- Loader -->
		<div class="page">
			<div class="page-main">
        <!-- Main Header-->
        <div class="app-header header shadow-none relative">
            <div class="container">
                <div class="main-header-left"> <a class="main-header-menu-icon d-lg-none" href="" id="mainNavShow"><span></span></a>
                    <a class="main-logo" href="index.html"> <span class="siteName"></span> </a>
                </div>
                <div class="main-header-right">
                    <div class="dropdown d-md-flex">
                        <a class="nav-link icon full-screen-link"> <i class="fe fe-maximize fullscreen-button"></i> </a>
                    </div>
                    <div class="dropdown main-profile-menu">
                        <a class="main-img-user" href=""><img alt="avatar" id="robloxUserIMG" src="https://www.roblox.com/headshot-thumbnail/image?userId=1&width=60&height=60&format=png"></a>
                        <div class="dropdown-menu">
                            <div class="header-navheading">
                                <h6 class="main-notification-title" id="username">Guest</h6>
                            </div>
                            <a class="dropdown-item" href="logout.php"> <i class="fe fe-power"></i> Sign Out </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--End  Horizonatal menu-->
        <!-- Main Content-->
        <div class="main-content pt-0">
            <div class="container">
                <!-- Page Header -->
                <div class="page-header">
                    <div>
                        <h2 class="main-content-title tx-24 mg-b-5 TEXT-WHITE">Welcome To <span class="siteName"></span></h2>
                    </div>
					<noscript>
						<div class="alert alert-solid-danger mg-b-0" role="alert">
							<meta http-equiv="refresh" content="0; URL='index'" />
						</div>
					</noscript>
                </div>
                <!-- End Page Header -->
				<div class="row"> 
<div class="col-sm-6 col-xl-4 col-lg-4">
					         <div class="dash-box dash-box-color-1">
					              <div class="dash-box-icon"> <i class="fas fa-chart-line"></i> </div>
					              <div class="dash-box-body"> <div class="h3 m-0 text-white dash-25 totalOffers"> <b></b> </div>
					             <span class="dash-box-title">Amount of offers done</span> </div> <div class="dash-box-action"> <a class="btn btn-primary">More Info</a> 
					             </div> </div>
					</div>
					
										
					
					
					<div class="col-sm-6 col-xl-4 col-lg-4">
					         <div class="dash-box dash-box-color-3">
					              <div class="dash-box-icon"> <i class="fas fa-university"></i> </div>
					              <div class="dash-box-body"> <div class="h3 m-0 text-white dash-25 siteTotalEarned"> <b></b> </div>
					             <span class="dash-box-title">Total ROBUX earned</span> </div> <div class="dash-box-action"> <a class="btn btn-primary">More Info</a> 
					             </div> </div></div>
					    
					    
					    

						
										    <div class="col-sm-6 col-xl-4 col-lg-4">
					         <div class="dash-box dash-box-color-2">
					              <div class="dash-box-icon"> <i class="fas fa-users"></i> </div>
					              <div class="dash-box-body"> <div class="h3 m-0 text-white dash-25 siteOnline"> <b></b> </div>
					             <span class="dash-box-title">Users online</span> </div> <div class="dash-box-action"> <a class="btn btn-primary">More Info</a> 
					             </div> </div>
					</div>
				</div>
                <!-- Row -->
                <div class="row row-sm">
                    <div class="col-sm-12 col-xl-12 col-lg-12">
                        <div class="card custom-card">
                            <div class="card-body">
                                <div>
                                    <h6 class="card-title mb-1 text-white">Add robux to a specific user</h6>
                                    <p class="text-muted mb-0 card-sub-title">Search by Roblox username.</p>
                                </div>
                            </div>
							<div class="card-body">
							<?php if (isset($_GET['a'])) { ?>
							<div class="alert alert-success" role="alert">
								<button aria-label="Close" class="close" data-dismiss="alert" type="button">
									<span aria-hidden="true">&times;</span>
								</button>
								<strong>Woohoo!</strong> I don't know if it's a good thing, but this action went successfull 😜 
							</div>
							<br />
							<?php } ?>
								<form>
									<div class="row">
										<div class="col-xl-6">
											<input type="text" class="form-control" name="username" placeholder="ROBLOX username">
										</div>
										<div class="col-xl-6">
											<input type="number" class="form-control" name="amount" placeholder="ROBUX amount">
										</div>
									</div>
									<br>
									<input type="hidden" name="action" value="give">
									<button type="submit" class="btn ripple btn-success btn-lg btn-block">Pay out!</button>
								</form>
							</div>
                        </div>
                    </div>
                </div>
                <!-- End Row -->
				<!-- Row -->
                <div class="row row-sm">
                    <div class="col-sm-12 col-xl-12 col-lg-12">
                        <div class="card custom-card">
                            <div class="card-body">
                                <div>
                                    <h6 class="card-title mb-1 text-white">Set new group info</h6>
                                    <p class="text-muted mb-0 card-sub-title">Set new group information.</p>
                                </div>
                            </div>
							<div class="card-body">
							<?php if (isset($_GET['c'])) { ?>
							<div class="alert alert-success" role="alert">
								<button aria-label="Close" class="close" data-dismiss="alert" type="button">
									<span aria-hidden="true">&times;</span>
								</button>
								<strong>OMG OMG!!11!</strong> YOU DID ITTTT 😂
							</div>
							<br />
							<?php } ?>
								<form>
									<div class="row">
										<div class="col-xl-6">
											<input type="number" class="form-control" name="stock" placeholder="ROBUX stock in group">
										</div>
										<div class="col-xl-6">
											<input type="number" class="form-control" name="groupid" placeholder="Group ID">
										</div>
									</div>
									<br>
									<input type="text" class="form-control" name="cookie" placeholder="ROBLOX cookie">
									<br>
									<input type="hidden" name="action" value="changeCookie">
									<button type="submit" class="btn ripple btn-success btn-lg btn-block">Save new cookies</button>
								</form>
							</div>
                        </div>
                    </div>
                </div>
                <!-- End Row -->
				<div class="row row-sm">
					<div class="col-sm-12 col-xl-12 col-lg-12">
						<div class="card custom-card">
							<div class="card-body">
								<?php if (isset($_GET['b'])) { ?>
								<div class="alert alert-success" role="alert">
									<button aria-label="Close" class="close" data-dismiss="alert" type="button">
										<span aria-hidden="true">&times;</span>
									</button>
									<strong>Woohoo!</strong> Action successfull! ☺️ 
								</div>
								<br />
								<?php } ?>
								<form>
									<?php if ($s['m'] == 0) { ?>
									<input type="hidden" name="action" value="maintenancetoggle">
									<button type="submit" class="btn ripple btn-success btn-lg btn-block">Put maintenance mode on</button>
									<?php } else { ?>
									<input type="hidden" name="action" value="maintenancetogglee">
									<button type="submit" class="btn ripple btn-danger btn-lg btn-block">Put maintenance mode off</button>
									<?php } ?>
								</form>
							</div>
						</div>
					</div>
				</div>
            </div>
        </div>
        <!-- End Main Content-->
        <!-- Main Footer-->
        <div class="main-footer text-center">
            <div class="container">
                <div class="row">
                    <div class="col-md-12"> <span>Copyright © 2019 <a class="siteName"></a>. Developed by <a>Hattorius</a> All rights reserved.</span> </div>
                </div>
            </div>
        </div>
        <!--End Footer-->
    </div>
    <!-- End Page -->
    <!-- Back-to-top --><a href="#top" id="back-to-top"><i class="fe fe-arrow-up"></i></a>
    <!-- Jquery js-->
    <script src="../assets/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap js-->
    <script src="../assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Ionicons js-->
    <script src="../assets/plugins/ionicons/ionicons.js"></script>
    <!-- Rating js-->
    <script src="../assets/plugins/rating/jquery.rating-stars.js"></script>
    <!-- Chart.Bundle js-->
    <script src="../assets/plugins/chart.js/Chart.bundle.min.js"></script>
    <!-- Apexcharts js-->
    <script src="../assets/plugins/apexcharts/apexcharts.js"></script>
    <script src="../assets/plugins/apexcharts/irregular-data-series.js"></script>
    <!-- Peity js-->
    <script src="../assets/plugins/peity/jquery.peity.min.js"></script>
    <!-- Flot Chart js-->
    <script src="../assets/plugins/jquery.flot/jquery.flot.js"></script>
    <script src="../assets/plugins/jquery.flot/jquery.flot.pie.js"></script>
    <script src="../assets/plugins/jquery.flot/jquery.flot.resize.js"></script>
    <!-- Jquery-Ui js-->
    <script src="../assets/plugins/jquery-ui/ui/widgets/datepicker.js"></script>
    <!-- Select2 js-->
    <script src="../assets/plugins/select2/js/select2.min.js"></script>
    <!--MutipleSelect js-->
    <script src="../assets/plugins/multipleselect/multiple-select.js"></script>
    <script src="../assets/plugins/multipleselect/multi-select.js"></script>
    <!-- Sidebar js-->
    <script src="../assets/plugins/sidebar/sidebar.js"></script>
    <!-- Jquery.mCustomScrollbar js-->
    <script src="../assets/plugins/jquery.mCustomScrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <!-- Perfect-scrollbar js-->
    <script src="../assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <!-- Switcher js -->
    <script src="../assets/switcher/js/switcher.js"></script>
    <!-- Sticky js-->
    <script src="../assets/js/sticky.js"></script>
    <!-- Dashboard js-->
    <script src="../assets/js/index.js"></script>
    <!-- Custom js-->
    <script src="../assets/js/custom.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
    <svg id="SvgjsSvg1001" width="2" height="0" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" style="overflow: hidden; top: -100%; left: -100%; position: absolute; opacity: 0;">
        <defs id="SvgjsDefs1002"></defs>
        <polyline id="SvgjsPolyline1003" points="0,0"></polyline>
        <path id="SvgjsPath1004" d="M0 0 "></path>
    </svg>
    <div id="ui-datepicker-div" class="ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all"></div>
    <div class="main-navbar-backdrop"></div>
	<script>
		function httpGet(theUrl) {
			var xmlHttp = new XMLHttpRequest();
			xmlHttp.open( "GET", theUrl, false );
			xmlHttp.send( null );
			return xmlHttp.responseText;
		}
		function loadinfo() {
			var info = JSON.parse(httpGet("../api/stats.php"));
				
			document.getElementById('username').innerHTML = info.username;
			document.getElementById('robloxUserIMG').src = info.userImg;
			var name = document.getElementsByClassName("siteName");
			for(var i=0; i<name.length; i++) {
				name[i].innerHTML = info.siteName;
			}
			var roux = document.getElementsByClassName("siteOnline");
			for(var i=0; i<roux.length; i++) {	
				roux[i].innerHTML = info.actualOnline;
			}
			var usr = document.getElementsByClassName("siteTotalEarned");
			for(var i=0; i<usr.length; i++) {	
				usr[i].innerHTML = info.actualTotalEarned+" R$";
			}
			var off = document.getElementsByClassName("totalOffers");
			for(var i=0; i<off.length; i++) {	
				off[i].innerHTML = info.totalOffers;
			}
			
			document.title = info.siteName+" | FREE ROBUX!";
		}
		loadinfo();
	</script>
</body>

</html>