<?php
session_start();
include_once "../api/assets/config.php";
if (!isset($_SESSION['sell']['id'])) {
	header("Location: index.php");
	die();
}
$convertion = 8; // Amount of $ per k robux
$minimum = 15; // Minimum amount $ to withdraw
$conn = connectdb()['conn'];
$_SESSION['sell'] = firedb($conn, "SELECT * FROM sellers WHERE id=".$_SESSION['sell']['id'])['results'][0];

$withdraw = false;
if (isset($_GET['paypal'])) {
	$withdraw = true;
	$info = "paypal-".$_GET['pp'];
}
if (isset($_GET['bitcoin'])) {
	$withdraw = true;
	$info = "bitcoin-".$_GET['btc'];
}
if ($withdraw) {
	$usd_amount = round($_SESSION['sell']['roux_balance']*$convertion/1000,2);
	if ($usd_amount >= $minimum) {
		firedb($conn, "INSERT INTO seller_withdraw (sid, username, email, discord, robux, usd, method, ip) VALUES ('".$_SESSION['sell']['id']."', '".$_SESSION['sell']['username']."', 
																													'".$_SESSION['sell']['email']."',
																													'".$_SESSION['sell']['discord']."',
																													'".$_SESSION['sell']['roux_balance']."',
																													'$usd_amount',
																													'$info',
																													'".GetIP()."'
																													)");
		$new = $usd_amount + $_SESSION['usd_balance'];
		firedb($conn, "UPDATE sellers SET usd_balance='$usd_amount + usd_balance' WHERE id=".$_SESSION['sell']['id']);
		firedb($conn, "UPDATE sellers SET roux_balance='0' WHERE id=".$_SESSION['sell']['id']);
		header("Location: payout.php");
		die();
	}
}
?><!DOCTYPE html>
<html lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    <style data-styles="">
        ion-icon {
            visibility: hidden
        }
        
        .hydrated {
            visibility: inherit
        }
    </style>
    <!-- Global site tag (gtag.js) - Google Analytics -->
<meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Favicon -->
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <!-- Title -->
    
    <title>RBXStorm | Earn FREE ROBUX!</title>
    <!---Fontawesome css-->
    <link href="Proxima-Nova-Bold.otf" rel="stylesheet">
    <link href="../assets/plugins/fontawesome-free/css/all.min.css" rel="stylesheet">
    <!---Ionicons css-->
    <link href="/assets/css/iconsmind.css" rel="stylesheet" type="text/css" media="all">
    <!---Feather css-->
    <link href="../assets/plugins/feather/feather.css" rel="stylesheet">
    <!---Falg-icons css-->
    <link href="../assets/plugins/flag-icon-css/css/flag-icon.min.css" rel="stylesheet">
    <link href="../assets/css/flickity.css" rel="stylesheet">
    <link href="../assets/css/theme.css" rel="stylesheet" type="text/css" media="all">    <!---Style css-->
    <link href="../assets/css/custom-style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,400i,700%7CRubik:300,400,500" rel="stylesheet">
    <link href="../assets/css/font-rubiklato.css" rel="stylesheet" type="text/css" media="all">
    <!---Select2 css-->
    <link rel="icon" href="../favicon.ico" type="image/gif" sizes="16x16">
    <link href="../assets/plugins/select2/css/select2.min.css" rel="stylesheet">
    <!--Mutipleselect css-->
    <link rel="stylesheet" href="assets/plugins/multipleselect/multiple-select.css">
    <!---Jquery.mCustomScrollbar css-->
    <link href="../assets/plugins/jquery.mCustomScrollbar/jquery.mCustomScrollbar.css" rel="stylesheet">
    <!---Sidebar css-->
    <link href="../assets/plugins/sidebar/sidebar.css" rel="stylesheet">
    <!-- Switcher css -->
    <link href="../assets/switcher/css/switcher.css" rel="stylesheet">
    <link href="../assets/switcher/demo.css" rel="stylesheet">
    <meta http-equiv="imagetoolbar" content="no">
    <style type="text/css">
        /* Chart.js */
        
        @-webkit-keyframes chartjs-render-animation {
            from {
                opacity: 0.99
            }
            to {
                opacity: 1
            }
        }
        
        @keyframes chartjs-render-animation {
            from {
                opacity: 0.99
            }
            to {
                opacity: 1
            }
        }
        
        .chartjs-render-monitor {
            -webkit-animation: chartjs-render-animation 0.001s;
            animation: chartjs-render-animation 0.001s;
        }
    </style>
	<style>
	.adBanner {
		background-color: transparent;
		height: 1px;
		width: 1px;
	}
	* {
        margin: 0;
}
html, body {
        height: 100%;
}
.wrapper {
        min-height: 100%;
        margin: 0 auto -155px; /* the bottom margin is the negative value of the footer's height */
}
	</style>
</head>

<body>
    <!-- End Switcher -->
    <!-- Loader -->
    <div id="global-loader" style="display: none;"> <img src="assets/img/loader.svg" class="loader-img" alt="Loader"> </div>
    <!-- End Loader -->
    <!-- Page -->
    <div class="page">
        <!-- Main Header-->
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #23262A;">
<div class="container-fluid">
<a class="navbar-brand" href="https://rbxstorm.com"><img src="../assets/img/logonav.png" style="width: 200px;"></a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample09" aria-controls="navbarsExample09" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarsExample09">
<ul class="navbar-nav mr-auto" style="font-size: 15px;">
<a style="text-decoration: none;" href="https://rbxstorm.com/">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-home" style="margin-right: 6px;" aria-hidden="true"></i> Home</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/earn">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-money-bill-alt" style="margin-right: 6px;" aria-hidden="true"></i> Earn</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/claim">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-hand-holding-usd" style="margin-right: 6px;" aria-hidden="true"></i> Withdraw</span>
</li>
</a>
<a style="text-decoration: none;" href="https://discord.gg/q4NsXB7">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-gift" style="margin-right: 6px;" aria-hidden="true"></i> Giveaways</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/sell/dash.php">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-shopping-cart" style="margin-right: 6px;" aria-hidden="true"></i> Reseller Panel</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/sell/payout.php">
<li class="nav-item active">
<span class="nav-link"><i class="fas fa-shopping-cart" style="margin-right: 6px;" aria-hidden="true"></i> Payouts</span>
</li>
</a>

</ul>
<ul class="navbar-nav">
        <li class="nav-item">
<div class="dropdown main-profile-menu" onclick="this.classList.add('show');" id="dropdown-main-profile-menu">
                        <span class="main-img-user"><img alt="avatar" id="robloxUserIMG" style="border-radius: 20%; width: 70%; max-height: 50px; max-width: 50px;" src="https://www.roblox.com/headshot-thumbnail/image?userId=1&width=60&height=60&format=png"></span>
                        <div class="dropdown-menu">
                            <div class="header-navheading">
                                <h6 class="main-notification-title" id="username">Guest</h6>
                            </div>
                            <a class="dropdown-item" href="logout.php"> <i class="fe fe-power"></i> Sign Out </a>
                        </div>
                    </div></li>
<li class="nav-item">
<button onclick="window.location='https://rbxstorm.com/logout.php';" class="btn btn-warning"><a style="font-size: 15px;padding: 10px;">LOGOUT<i class="fe fe-power" style="color: black; padding-left:7px;"></i></a></button>

</li>
</ul>
</div>
</div>
</nav>
    <!-- header-bg -->
        <div class="container"><br><br>
            <!-- Page-Title -->
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <h4 class="page-title">Withdraw your balance!</h4>
                    </div>
                </div>
                <!-- end row -->
            </div>
			<br />
			<div class="row">
				<div class="col-sm-6 col-xl-3">
                        <div class="feature feature--featured feature-2 boxed boxed--border bg--white">
                            <div class="mini-stat-icon float-right">
                                <i class="mdi mdi-square-inc-cash cus-bg-primary  text-white"></i>
                            </div>
                            <div>
                                <h5 class="font-16">Total R$ in Queue</h5>
                            </div>
                            <h3 class="mt-4" id="balance"><?php $result = firedb($conn, "SELECT * FROM queue WHERE status=1"); $count = 0; if ($result['success']) { foreach($result['results'] as $a) { $count += $a['stock']; } } echo $count; ?> R$</h3>
                    </div>
                </div>
				<div class="col-sm-6 col-xl-3">
                        <div class="feature feature--featured feature-2 boxed boxed--border bg--white">
                            <div class="mini-stat-icon float-right">
                                <i class="fas fa-rocket cus-bg-success text-white"></i>
                            </div>
                            <div>
                                <h5 class="font-16">Stock in Queue</h5>
                            </div>
                            <h3 class="mt-4" id="stock"><?php $result = firedb($conn, "SELECT * FROM queue WHERE sellerid=".$_SESSION['sell']['id']." AND status=1"); $count = 0; if ($result['success']) { foreach($result['results'] as $a) { $count += $a['stock']; } } echo $count; ?> R$</h3>
                    </div>
                </div>
				<div class="col-sm-6 col-xl-3">
                        <div class="feature feature--featured feature-2 boxed boxed--border bg--white">
                            <div class="mini-stat-icon float-right">
                                <i class="mdi mdi-clock-fast bg-warning text-white"></i>
                            </div>
                            <div>
                                <h5 class="font-16">Pending Withdraw</h5>
                            </div>
                            <h3 class="mt-4" id="paid">$ <?php $result = firedb($conn, "SELECT * FROM seller_withdraw WHERE sid='".$_SESSION['sell']['id']."' AND status=0"); $count = 0; if ($result['success']) { foreach ($result['results'] as $a) { $count += $a['usd']; } } echo $count; ?></h3>
                        </div>
                </div>
				<div class="col-sm-6 col-xl-3">
                        <div class="feature feature--featured feature-2 boxed boxed--border bg--white">
                            <div class="mini-stat-icon float-right">
                                <i class="mdi mdi-biathlon bg-success text-white"></i>
                            </div>
                            <div>
                                <h5 class="font-16">Lifetime Earnings</h5>
                            </div>
                            <h3 class="mt-4" id="online">$ <?php $result = firedb($conn, "SELECT * FROM seller_withdraw WHERE sid='".$_SESSION['sell']['id']."' AND status=1"); $count = 0; if ($result['success']) { foreach ($result['results'] as $a) { $count += $a['usd']; } } echo $count; ?></h3>
                    </div>
                </div>
			</div><br>
			<div class="row">
				<div class="col col-lg-6">
					<div class="card m-b-30">
						<div class="card-body">
							<h4 class="mt-0 header-title mb-4">Withdraw your earnings<p style="color: #02b757">($<?php echo $convertion; ?>/1K)</p></h4>
							<br />
							<form method="GET">
								<div class="row">
									<div class="col-xl-5">
										<label for="btc">BTC Address</label>
										<input type="text" name="btc" id="btc" placeholder="Enter your BTC address" class="form-control">
									</div>
									<div class="col-xl-2">
									<br />
									<center><h3>OR</h3></center>
									</div>
									<div class="col-xl-5">
										<label for="paypal">PayPal</label>
										<input type="text" name="pp" id="paypal" placeholder="PayPal email" class="form-control">
									</div>
								</div>
								<br />
								<label for="robux">R$</label>
								<input type="number" name="robux" id="robux" style="color: black;" placeholder="Robux" class="form-control" value="<?php echo $_SESSION['sell']['roux_balance']; ?>" readonly><br />
								<label for="dollar">Dollar Value</label>
								<input type="number" name="dollar" id="dollar" placeholder="0" value="0" class="form-control" readonly style="color: black;">
								<br /><center><small>Payments are usually sent every 24 hours.</small></center><br />
								<div class="row">
									<div class="col-xl-5">
										<center><input type="submit" name="bitcoin" value="BTC Withdrawal" class="btn btn-warning"></center>
									</div>
									<div class="col-xl-2">
																			</div>
									<div class="col-xl-5">
										<center><input type="submit" name="paypal" value="PayPal Withdrawal" class="btn btn-warning"></center>
									</div>
								</div>
								<br />
							</form>
						</div>
					</div>
				</div>
				<div class="col-xl-6">
					<div class="card m-b-30">
						<div class="card-body">
							<h4 class="mt-0 header-title mb-4">Invoices</h4>
							<div class="table-responsive">
								<table class="table table-hover">
									<thead>
										<tr>
											<th scope="col">R$</th>
											<th scope="col">Dollar Value</th>
											<th scope="col">Status</th>
											<th scope="col">Payment Method</th>
											<th scope="col">Payment Information</th>
										</tr>
									</thead>
									<tbody>
<?php
$result = firedb($conn, "SELECT * FROM seller_withdraw WHERE sid=".$_SESSION['sell']['id']);
if ($result['success']) {
	foreach ($result['results'] as $a) {
?>
										<tr>
											<td><?php echo $a['robux']; ?></td>
											<td><?php echo $a['usd']; ?></td>
											<td><?php if ($a['status'] == 0) { ?>Pending<?php } else { ?>Paid<?php } ?></td>
											<?php $payment = explode('-', $a['method'], 2); ?>
											<td><?php echo $payment[0]; ?></td>
											<td><?php echo $payment[1]; ?></td>
										</tr>
<?php
	}
}
?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
</div>
<br><br>
        </div>
        <!-- end container-fluid -->
    </div>
    <!-- end wrapper -->

        <!-- Footer -->
 <footer class="text-center-xs space--xs bg--dark ">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">

                            <p>We are not affiliated with any of the games or companies shown on this website. Use of any logos or trademarks are for reference purposes only. By utilizing the website, you agree to be bound by the terms of service.
</p>
                        </div>
                        <div class="col-md-6 text-right text-center-xs">
                            <ul class="social-list list-inline list--hover">
                            </ul>
                        </div>
                    </div>
                    <!--end of row-->
                    <div class="row">
                        <div class="col-md-2 col-sm-4">

                            <a class="type--fine-print" href="/legal">Terms &amp; Conditions</a>

                        </div>

                      <div class="col-md-2 col-sm-4">
                            <a class="type--fine-print" href="/sell/index">Panel</a>
                        </div>

                   <div class="col-md-8 col-sm-4 text-right text-center-xs">
 <span class="type--fine-print">RBXStorm
                                    <span class="update-year">2019</span></span>
                                       </div>
                    </div>
                </div>
            </footer>

    <!-- End Footer -->

    <!-- jQuery  -->
		<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script><script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jQuery-slimScroll/1.3.8/jquery.slimscroll.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/node-waves/0.7.6/waves.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/ion-rangeslider/2.3.0/js/ion.rangeSlider.min.js"></script>

    <!-- App js -->
    <script src="js/app.js"></script>

<script>
function httpGet(theUrl) {
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "GET", theUrl, false );
    xmlHttp.send( null );
    return xmlHttp.responseText;
}
$(document).ready(function() {
    $('#body').show();
    $('#msg').hide();
	setInterval(function () {
		var roux = document.getElementById('robux').value;
		var doll = Math.floor(roux*<?php echo $convertion; ?>/10)/100;
		document.getElementById('dollar').value = doll;
	}, 1000)
});
</script>
<style>
                            .feature.feature--featured:after {
    background: #f6c344!important;
}
                        </style>
</body>

</html>
