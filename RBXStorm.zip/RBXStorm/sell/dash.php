<?php
session_start();
include_once "../api/assets/config.php";
if (!isset($_SESSION['sell']['id'])) {
	header("Location: index.php");
	die();
}
$conn = connectdb()['conn'];
$_SESSION['sell'] = firedb($conn, "SELECT * FROM sellers WHERE id=".$_SESSION['sell']['id'])['results'][0];
if (isset($_POST['action'])) {
	$a = explode('-', $_POST['action']);
	if ($a[0] == "pause") {
		firedb($conn, "UPDATE queue SET status='200' WHERE id=".$a[1]." AND sellerid=".$_SESSION['sell']['id']);
		header("Location: dash.php");
		die();
	} elseif ($a[0] == "resume") {
		firedb($conn, "UPDATE queue SET status='1' WHERE id=".$a[1]." AND sellerid=".$_SESSION['sell']['id']);
		header("Location: dash.php");
		die();
	}
}
?><html lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    <style data-styles="">
        ion-icon {
            visibility: hidden
        }
        
        .hydrated {
            visibility: inherit
        }
    </style>
    <!-- Global site tag (gtag.js) - Google Analytics -->
<meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Favicon -->
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <!-- Title -->
    
    <title>RBXStorm | Earn FREE ROBUX!</title>
    <!---Fontawesome css-->
    <link href="Proxima-Nova-Bold.otf" rel="stylesheet">
    <link href="../assets/plugins/fontawesome-free/css/all.min.css" rel="stylesheet">
    <!---Ionicons css-->
    <link href="/assets/css/iconsmind.css" rel="stylesheet" type="text/css" media="all">
    <!---Feather css-->
    <link href="../assets/plugins/feather/feather.css" rel="stylesheet">
    <!---Falg-icons css-->
    <link href="../assets/plugins/flag-icon-css/css/flag-icon.min.css" rel="stylesheet">
    <link href="../assets/css/flickity.css" rel="stylesheet">
    <link href="../assets/css/theme.css" rel="stylesheet" type="text/css" media="all">    <!---Style css-->
    <link href="../assets/css/custom-style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,400i,700%7CRubik:300,400,500" rel="stylesheet">
    <link href="../assets/css/font-rubiklato.css" rel="stylesheet" type="text/css" media="all">
    <!---Select2 css-->
    <link href="../assets/plugins/select2/css/select2.min.css" rel="stylesheet">
    <!--Mutipleselect css-->
    <link rel="stylesheet" href="assets/plugins/multipleselect/multiple-select.css">
    <!---Jquery.mCustomScrollbar css-->
    <link href="../assets/plugins/jquery.mCustomScrollbar/jquery.mCustomScrollbar.css" rel="stylesheet">
    <!---Sidebar css-->
    <link href="../assets/plugins/sidebar/sidebar.css" rel="stylesheet">
    <!-- Switcher css -->
        <link rel="icon" href="../favicon.ico" type="image/gif" sizes="16x16">
    <link href="../assets/switcher/css/switcher.css" rel="stylesheet">
    <link href="../assets/switcher/demo.css" rel="stylesheet">
    <meta http-equiv="imagetoolbar" content="no">
    <style type="text/css">
        /* Chart.js */
        
        @-webkit-keyframes chartjs-render-animation {
            from {
                opacity: 0.99
            }
            to {
                opacity: 1
            }
        }
        
        @keyframes chartjs-render-animation {
            from {
                opacity: 0.99
            }
            to {
                opacity: 1
            }
        }
        
        .chartjs-render-monitor {
            -webkit-animation: chartjs-render-animation 0.001s;
            animation: chartjs-render-animation 0.001s;
        }
    </style>
	<style>
	.adBanner {
		background-color: transparent;
		height: 1px;
		width: 1px;
	}
	* {
        margin: 0;
}
html, body {
        height: 100%;
}
.wrapper {
        min-height: 100%;
        margin: 0 auto -155px; /* the bottom margin is the negative value of the footer's height */
}
	</style>
</head>

<body>
    <!-- End Switcher -->
    <!-- Loader -->
    <div id="global-loader" style="display: none;"> <img src="assets/img/loader.svg" class="loader-img" alt="Loader"> </div>
    <!-- End Loader -->
    <!-- Page -->
    <div class="page">
        <!-- Main Header-->
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #23262A;">
<div class="container-fluid">
<a class="navbar-brand" href="https://rbxstorm.com"><img src="../assets/img/logonav.png" style="width: 200px;"></a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample09" aria-controls="navbarsExample09" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarsExample09">
<ul class="navbar-nav mr-auto" style="font-size: 15px;">
<a style="text-decoration: none;" href="https://rbxstorm.com/">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-home" style="margin-right: 6px;" aria-hidden="true"></i> Home</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/earn">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-money-bill-alt" style="margin-right: 6px;" aria-hidden="true"></i> Earn</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/claim">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-hand-holding-usd" style="margin-right: 6px;" aria-hidden="true"></i> Withdraw</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/promocodes">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-gift" style="margin-right: 6px;" aria-hidden="true"></i> Promocodes</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/sell/dash.php">
<li class="nav-item active">
<span class="nav-link"><i class="fas fa-shopping-cart" style="margin-right: 6px;" aria-hidden="true"></i> Reseller Panel</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/sell/payout.php">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-shopping-cart" style="margin-right: 6px;" aria-hidden="true"></i> Payouts</span>
</li>
</a>

</ul>
<ul class="navbar-nav">
        <li class="nav-item">
<div class="dropdown main-profile-menu" onclick="this.classList.add('show');" id="dropdown-main-profile-menu">
                        <span class="main-img-user"><img alt="avatar" id="robloxUserIMG" style="border-radius: 20%; width: 70%; max-height: 50px; max-width: 50px;" src="https://www.roblox.com/headshot-thumbnail/image?userId=1&width=60&height=60&format=png"></span>
                        <div class="dropdown-menu">
                            <div class="header-navheading">
                                <h6 class="main-notification-title" id="username">Guest</h6>
                            </div>
                            <a class="dropdown-item" href="logout.php"> <i class="fe fe-power"></i> Sign Out </a>
                        </div>
                    </div></li>
<li class="nav-item">
<button onclick="window.location='https://rbxstorm.com/logout.php';" class="btn btn-warning"><a style="font-size: 15px;padding: 10px;">LOGOUT<i class="fe fe-power" style="color: black; padding-left:7px;"></i></a></button>

</li>
</ul>
</div>
</div>
</nav>
<div style="width:100%;background: #f6c344;box-shadow: 1px 1px 4px rgba(0, 0, 0, 0.3);">
                        <h5 style="color:black;font-weight:400;text-align:center;padding: 8px;">
                        To receive payouts, please visit the <a style="font-weight: 400;color: #F44336;" href="https://rbxstorm.com/sell/payout.php">payouts</a> tab!</h5></div>

    <!-- header-bg -->

        <div class="container">
            <!-- Page-Title -->
            <div class="page-title-box"><br><br>
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <h4 class="page-title">Add your group to the queue!</h4>
                    </div>
                </div>
                <!-- end row -->
            </div>
			<br />
			<div class="row">
				<div class="col-sm-6 col-xl-4">
                        <div class="feature feature--featured feature-2 boxed boxed--border bg--white">
                            <div class="mini-stat-icon float-right">
                                <i class="mdi mdi-square-inc-cash cus-bg-primary  text-white"></i>
                            </div>
                            <div>
                                <h5 class="font-16">Total R$ in Queue</h5>
                            </div>
                            <h3 class="mt-4" id="balance"><?php $result = firedb($conn, "SELECT * FROM queue WHERE status=1"); $count = 0; if ($result['success']) { foreach($result['results'] as $a) { $count += $a['stock']; } } echo $count; ?> R$</h3>
                    </div>
                </div>
				<div class="col-sm-6 col-xl-4">
                        <div class="feature feature--featured feature-2 boxed boxed--border bg--white">
                            <div class="mini-stat-icon float-right">
                                <i class="fas fa-rocket cus-bg-success text-white"></i>
                            </div>
                            <div>
                                <h5 class="font-16">Stock in Queue</h5>
                            </div>
                            <h3 class="mt-4" id="stock"><?php $result = firedb($conn, "SELECT * FROM queue WHERE sellerid=".$_SESSION['sell']['id']." AND status=1"); $count = 0; if ($result['success']) { foreach($result['results'] as $a) { $count += $a['stock']; } } echo $count; ?> R$</h3>
                        </div>
                </div>
				<div class="col-sm-6 col-xl-4">
                        <div class="feature feature--featured feature-2 boxed boxed--border bg--white">
                            <div class="mini-stat-icon float-right">
                                <i class="mdi mdi-biathlon bg-success text-white"></i>
                            </div>
                            <div>
                                <h5 class="font-16">Lifetime Earnings</h5>
                            </div>
                            <h3 class="mt-4" id="online">$ <?php $result = firedb($conn, "SELECT * FROM seller_withdraw WHERE sid='".$_SESSION['sell']['id']."' AND status=1"); $count = 0; if ($result['success']) { foreach ($result['results'] as $a) { $count += $a['usd']; } } echo $count; ?></h3>
                    </div>
                </div>
			</div><br>
			<div class="row">
				<div class="col-xl-4">
					<div class="card m-b-30" style="background-color: #fcfcfc;">
						<div class="card-body">
							<h4 class="mt-0 header-title mb-4">Link your group</h4>
							<br />
							<label for="group">Group ID</label>
							<input type="number" name="group" id="group" class="form-control"><br />
							<label for="stock">R$ Stock</label>
							<input type="number" name="stock" id="kkk" class="form-control" min="0" value="0" min="1000"><br />
							<label for="cookie">Group Owner Cookie</label>
							<input type="text" name="cookie" id="cookie" class="form-control"><br /><br />
							<center><button class="btn btn-warning btn-block" onclick="addgroup();">Add group</button></center>
							<center><p class="text-muted mb-0 card-sub-title" style="padding-top: 10px;">Your information is 100% <b>secure.</b></p></center>
						</div>
					</div>
				</div>
				<div class="col-xl-8">
					<div class="card m-b-30" style="background-color: #fcfcfc;">
						<div class="card-body">
							<h4 class="mt-0 header-title mb-4">Group in queue</h4>
							<div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th scope="col">Status</th>
											<th scope="col">R$ Stock</th>
                                            <th scope="col">Group ID</th>
											<th scope="col">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
$result = firedb($conn, "SELECT * FROM queue WHERE sellerid=".$_SESSION['sell']['id']." AND status=1");
if ($result['success']) {
	foreach ($result['results'] as $a) {
?>
										<tr>
											<td>In queue</td>
											<td><?php echo $a['stock']; ?></td>
											<td><?php echo $a['groupid']; ?></td>
											<td><form method="post"><button type="submit" class="btn btn-warning" name="action" value="pause-<?php echo $a['id']; ?>">Pause</button></form></td>
										</tr>
<?php
	}
}
?>
                                    </tbody>
                                </table>
                            </div>
						</div>
					</div><br>
					<div class="card m-b-30" style="background-color: #fcfcfc;">
						<div class="card-body">
							<h4 class="mt-0 header-title mb-4">Group history</h4>
							<div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th scope="col">Status</th>
											<th scope="col">R$ Stock</th>
                                            <th scope="col">Group ID</th>
											<th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
$result = firedb($conn, "SELECT * FROM queue WHERE sellerid=".$_SESSION['sell']['id']." AND status!=1");
if ($result['success']) {
	foreach ($result['results'] as $a) {
?>
										<tr>
											<td><?php if ($a['status'] == 200) { ?>Paused<?php } else { ?>Out of queue<?php } ?></td>
											<td><?php echo $a['stock']; ?></td>
											<td><?php echo $a['groupid']; ?></td>
											<td><?php if ($a['status'] == 200) { ?><form method="post"><button type="submit" class="btn btn-warning" name="action" value="resume-<?php echo $a['id']; ?>">Resume</button></form><?php } else { ?> No actions available <?php } ?></td>
										</tr>
<?php
	}
}
?>
                                    </tbody>
                                </table>
                            </div>
						</div>
					</div>
				</div>
			</div><hr>
			 <?php
            
        
            $con=mysqli_connect("localhost","rbxsyjov_admin","RBXStorm456","rbxsyjov_rbxstorm");
// Check connection
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
?>




    
    
            
        
        <br>
        
        <div class="col-sm-6">
        <div class="card m-b-30" style="background-color: #fcfcfc;">
        						<div class="card-body">
							<h4 class="mt-0 header-title mb-4">Recent Earnings</h4>
        <canvas id="myChart"></canvas>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.bundle.js"></script>
<script>
var ctx = document.getElementById('myChart').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ['<?php $today = date("l", strtotime( $date . ' -5 day' )); echo $today;?>', '<?php $today = date("l", strtotime( $date . ' -4 day' )); echo $today;?>', '<?php $today = date("l", strtotime( $date . ' -3 day' )); echo $today;?>', '<?php $today = date("l", strtotime( $date . ' -2 day' )); echo $today;?>', '<?php $today = date("l", strtotime( $date . ' -1 day' )); echo $today;?>', 'Today'],
        datasets: [{
            label: 'R$ Sold',
            data: [
                <?php $day_before5 = date( 'Y-m-d', strtotime( $date . ' -5 day' ) ); $result5 = firedb($conn, "SELECT * FROM withdraw WHERE sellerid=".$_SESSION['sell']['id']." AND time LIKE '%$day_before5%'"); $count5 = 0; if ($result5['success']) { foreach($result5['results'] as $a) { $count5 += $a['dollar']; } } ; echo $count5; ?>,
                <?php $day_before4 = date( 'Y-m-d', strtotime( $date . ' -4 day' ) ); $result4 = firedb($conn, "SELECT * FROM withdraw WHERE sellerid=".$_SESSION['sell']['id']." AND time LIKE '%$day_before4%'"); $count4 = 0; if ($result4['success']) { foreach($result4['results'] as $a) { $count4 += $a['dollar']; } } ; echo $count4; ?>,
                <?php $day_before3 = date( 'Y-m-d', strtotime( $date . ' -3 day' ) ); $result3 = firedb($conn, "SELECT * FROM withdraw WHERE sellerid=".$_SESSION['sell']['id']." AND time LIKE '%$day_before3%'"); $count3 = 0; if ($result3['success']) { foreach($result3['results'] as $a) { $count3 += $a['dollar']; } } ; echo $count3; ?>,
                <?php $day_before2 = date( 'Y-m-d', strtotime( $date . ' -2 day' ) ); $result2 = firedb($conn, "SELECT * FROM withdraw WHERE sellerid=".$_SESSION['sell']['id']." AND time LIKE '%$day_before2%'"); $count2 = 0; if ($result2['success']) { foreach($result2['results'] as $a) { $count2 += $a['dollar']; } } ; echo $count2; ?>,
                <?php $day_before1 = date( 'Y-m-d', strtotime( $date . ' -1 day' ) ); $result1 = firedb($conn, "SELECT * FROM withdraw WHERE sellerid=".$_SESSION['sell']['id']." AND time LIKE '%$day_before1%'"); $count1 = 0; if ($result1['success']) { foreach($result1['results'] as $a) { $count1 += $a['dollar']; } } ; echo $count1; ?>,
                <?php $today = date( 'Y-m-d'); $result = firedb($conn, "SELECT * FROM withdraw WHERE sellerid=".$_SESSION['sell']['id']." AND time LIKE '%$today%'"); $count = 0; if ($result['success']) { foreach($result['results'] as $a) { $count += $a['dollar']; } } ; echo $count; ?>],
            backgroundColor: [
                'rgba(255, 171, 0, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255, 171, 0, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 3
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        }
    }
});
</script></div></div></div>
    
        </div>
        <!-- end container-fluid -->
    </div><br><br>
    <!-- end wrapper -->

    <!-- Footer -->
 <footer class="text-center-xs space--xs bg--dark ">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">

                            <p>We are not affiliated with any of the games or companies shown on this website. Use of any logos or trademarks are for reference purposes only. By utilizing the website, you agree to be bound by the terms of service.
</p>
                        </div>
                        <div class="col-md-6 text-right text-center-xs">
                            <ul class="social-list list-inline list--hover">
                            </ul>
                        </div>
                    </div>
                    <!--end of row-->
                    <div class="row">
                        <div class="col-md-2 col-sm-4">

                            <a class="type--fine-print" href="/legal">Terms &amp; Conditions</a>

                        </div>

                      <div class="col-md-2 col-sm-4">
                            <a class="type--fine-print" href="/sell/index">Panel</a>
                        </div>

                   <div class="col-md-8 col-sm-4 text-right text-center-xs">
 <span class="type--fine-print">RBXStorm
                                    <span class="update-year">2019</span></span>
                                       </div>
                    </div>
                </div>
            </footer>

    <!-- End Footer -->

    <!-- jQuery  -->
		<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script><script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jQuery-slimScroll/1.3.8/jquery.slimscroll.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/node-waves/0.7.6/waves.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/ion-rangeslider/2.3.0/js/ion.rangeSlider.min.js"></script>

    <!-- App js -->
    <script src="js/app.js"></script>

<script>
function httpGet(theUrl) {
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "GET", theUrl, false );
    xmlHttp.send( null );
    return xmlHttp.responseText;
}

$(document).ready(function() {
    $('#body').show();
    $('#msg').hide();
});
function addgroup() {
	var group = document.getElementById("group").value;
	var stock = document.getElementById("kkk").value;
	var cookie = document.getElementById("cookie").value;
	var url = ""+location.protocol+"//"+window.location.hostname+"/sell/api/addgroup.php?group="+group+"&stock="+stock+"&cookie="+cookie;
	console.log(url);
	var obj = JSON.parse(httpGet(url));
	console.log(obj);
	if (obj.error) {
		document.getElementById("alert").innerHTML = '<div class="alert alert-danger alert-dismissible fade show" style="width:100%;" role="alert">'+obj.message+'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>';
	} else {
		document.getElementById("alert").innerHTML = '<div class="alert alert-success alert-dismissible fade show" style="width:100%;" role="alert">'+obj.message+'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>';
	}
}
</script>
<style>
                            .feature.feature--featured:after {
    background: #f6c344!important;
}
                        </style>
</body>

</html>
