<?php
session_start();
include_once "../../api/assets/config.php";
if (!isset($_SESSION['sell']['id'])) {
	die();
}
$conn = connectdb()['conn'];
$min = 0;
$error = "";
if (isset($_GET['group'])) {
	if (isset($_GET['stock'])) {
		if (isset($_GET['cookie'])) {
			$group = $_GET['group'];
			$stock = $_GET['stock'];
			$cookie = $_GET['cookie'];
			if ($stock >= $min) {
				$aaa = firedb($conn, "SELECT * FROM queue WHERE sellerid='".$_SESSION['sell']['id']."' AND groupid='$group'");
				if ($aaa['success']) {
					foreach ($aaa['results'] as $a) {
						if ($a['status'] == 1 || $a['status'] == 200) {
							$error .= " Group already in queue!";
						}
					}
				}
				if (!lastclaimchecks($group, $cookie, $stock)) {
					if ($error == "") {
						firedb($conn, "INSERT INTO queue (groupid, stock, cookie, sellerid) VALUES ('$group', '$stock', '$cookie', '".$_SESSION['sell']['id']."')");
						die(json_encode(array('error'=>false, 'message'=>"Group successfully added to the queue! Reload the page to see it added!")));
					}
				} else {
					$error .= " Cookie or stock amount invalid!";
				}
			} else {
				$error .= " Minimum group stock amount => $min R$!";
			}
		}
	}
}
die(json_encode(array('error'=>true, 'message'=>$error)));
?>