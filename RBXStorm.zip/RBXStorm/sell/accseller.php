<?php
include_once "../api/assets/config.php";
die("here");
if (isset($_GET['wdunfuh2ffuenq8hddndakdkad'])) {
	if (isset($_GET['id'])) {
		$id = $_GET['id'];
		$conn = connectdb()['conn'];
		$user = firedb($conn, "SELECT * FROM sellers WHERE id=".$id);
		if ($user['success']) {
			$result = firedb($conn, "UPDATE sellers SET status='1' WHERE id=".$id, "UPDATE");
			if ($result['success']) {
				// Lets create the secret key for the person
				$go = true;
				$count = 0;
				$email = $user['results'][0]['email'];
				$discord = $user['results'][0]['discord'];
				$username = $user['results'][0]['email'];
				$key = "";
				while ($go) {
					$key .= md5($count.$count.$count.$count.$username.$username.$discord.$username.$discord.$email.$email.$discord.$email);
					$count++;
					if ($count > 100) {
						$go = false;
					}
				}
				$key = md5($key);
				die($key);
			}
		}
	}
}
// If key is wrong, or ID is not given or there is an error etc. It will give a 404 error..
die("aa");
?>