<?php
if (isset($_POST['email-address'])) {
	if (isset($_POST['secret-token'])) {
		$email = strtolower($_POST['email-address']);
		$token = $_POST['secret-token'];
		include_once "../api/assets/config.php";
		$conn = connectdb()['conn'];
		$user = firedb($conn, "SELECT * FROM sellers WHERE email='$email'");
		if ($user['success']) {
			if ($user['results'][0]['status'] == 1) {
				$go = true;
				$count = 0;
				$email = $user['results'][0]['email'];
				$discord = $user['results'][0]['discord'];
				$username = $user['results'][0]['email'];
				$key = "";
				while ($go) {
					$key .= md5($count.$count.$count.$count.$username.$username.$discord.$username.$discord.$email.$email.$discord.$email);
					$count++;
					if ($count > 100) {
						$go = false;
					}
				}
				$key = md5($key);
				if ($key == $token) {
					session_start();
					$_SESSION['sell'] = $user['results'][0];
					header("Location: dash.php");
					die();
				}
			}
		}
	}
}
?><!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <style>
            body {
                margin-top: 65px;
            }
        </style>
    </head>
	<body>
		<div id="root">
			<rbxdream-login>
				<rbxdream-img src="/logo.png" width="95%" height="auto" style="margin: auto;"></rbxdream-img>
				<rbxdream-input type="email" name="Email address"></rbxdream-input>
				<rbxdream-input type="password" name="Secret token"></rbxdream-input>
				<rbxdream-button color="#02b757" type="submit" text="Login"></rbxdream-button>
			</rbxdream-login>
		</div>
		
		
		<script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>
		<script>
			 Vue.component('rbxdream-login', {
				 template: `
					<div class="container">
						<div class="card col-5" style="margin: auto; background: rgba(0,0,0,.03); padding-bottom: 20px;">
							<form method="POST">
								<slot></slot>
							</form>
						</div>
					</div>
				 `
			 });
			 Vue.component('rbxdream-img', {
				 template: `
					<img :src="src" :width="width" :height="height">
				 `,
				 props: {
					 src: { default: 'logo' },
					 width: { default: '100px' },
					 height: { dafult: 'auto' }
				 },
			 });
			 Vue.component('rbxdream-button', {
				 template: `
					<button class="btn btn-lg btn-block" :type="type" :style="{ 'background-color': color, 'color': textColor, 'margin-top': '24px' }">{{ text }}</button>
				 `,
				 props: {
					 color: { default: '#000' },
					 type: { default: 'submit' },
					 text: { dafult: 'Click me' },
					 textColor: { default: '#fff' }
				 },
			 });
			 Vue.component('rbxdream-input', {
				 template: `
					<div style="margin-top: 10px;">
						<label :for="giveName">{{ name }}</label>
						<div class="input-group">
							<input :id="giveName" :type="type" :name="giveName" class="form-control">
						</div>
					</div>
				 `,
				 props: {
					 type: { default: 'text' },
					 name: { default: '' }
				 },
				 computed: {
					 giveName() {
						 return this.name.toLowerCase().replace(/ /g, '-');
					 }
				 }
			 });
			 new Vue ({
				el: '#root'
            });
		</script>
	</body>
</html>