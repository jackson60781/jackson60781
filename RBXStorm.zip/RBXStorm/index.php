<html lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="favicon.ico" type="image/x-icon">
  <title>RBXStorm - Earn Free Robux</title>
  <meta name="description" content="Earn free robux by watching videos playing games and completing simple tasks. Start earning today.">
  <meta name="keywords" content="robux,free,promocodes,codes">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!---Fontawesome css-->
        <link href="/assets/css/theme.css" rel="stylesheet" type="text/css" media="all">    <!---Style css-->
    <link href="assets/css/custom-style.css" rel="stylesheet">
    <link href="assets/plugins/fontawesome-free/css/all.min.css" rel="stylesheet">
    <meta name="propeller" content="4f4de90b252504e68f6674eba7d889ab">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,400i,700%7CRubik:300,400,500" rel="stylesheet">
    <link href="assets/css/font-rubiklato.css" rel="stylesheet" type="text/css" media="all">
	<style>
html, body {
        height: 100%;
}

	</style>
</head>

<body>
    <!-- Page -->
    <div class="page">
        <!-- Main Header-->
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #23262A;">
<div class="container-fluid">
<a class="navbar-brand" href="https://rbxstorm.com"><img src="assets/img/logonav.png" style="width: 200px;"></a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample09" aria-controls="navbarsExample09" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarsExample09">
<ul class="navbar-nav mr-auto" style="font-size: 15px;">
<a style="text-decoration: none;" href="https://rbxstorm.com/">
<li class="nav-item active">
<span class="nav-link"><i class="fas fa-home" style="margin-right: 6px;" aria-hidden="true"></i> Home</span>
</li>
</a>
<a style="text-decoration: none;" onclick="goToEarn();" href="#">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-money-bill-alt" style="margin-right: 6px;" aria-hidden="true"></i> Earn</span>
</li>
</a>
<a style="text-decoration: none;" href="https://discord.gg/q4NsXB7">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-gift" style="margin-right: 6px;" aria-hidden="true"></i> Giveaways</span>
</li>
</a>
<a style="text-decoration: none;" onclick="goToEarn();" href="#">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-shopping-cart" style="margin-right: 6px;" aria-hidden="true"></i> Promo Codes</span>
</li>
</a>
<a style="text-decoration: none;" onclick="goToEarn();" href="#">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-hat-wizard" style="margin-right: 6px;" aria-hidden="true"></i> Quests<sup style="color:red;padding-left:5px;">NEW!</sup></span>
</li>
</a>
</ul>
<ul class="navbar-nav">
<li class="nav-item">
    <a href=""><button onclick="goToEarn();" style="border-color:black;" class="btn btn-warning"><a style="font-size: 15px;padding: 10px;">START EARNING</button></a>

</li>
</ul>
</div>
</div>
</nav>
<div style="width:100%;background: #f6c344;box-shadow: 1px 1px 4px rgba(0, 0, 0, 0.3);">
                        <h5 style="color:black;font-weight:400;font-size:18px;text-align:center;padding: 8px;">
                                                20% BOOST ON ALL EARNINGS! VISIT THE <a style="font-weight: 400;color: #F44336;" href="#" onclick="goToEarn();">EARN</a> TAB!</h5></div>
        <!-- Main Content-->
        <div class="main-content pt-0" onclick="document.getElementById('dropdown-main-profile-menu').classList.remove('show');">
            <div class="container">
                <!-- Page Header -->
                <div class="page-header"><br><br>
                    <div class="container">
                        <center>
                            
                        <section>
                <div class="container">
                    <div class="row align-items-center justify-content-around">


                        <div class="col-md-7 mt-0">
                            <h1>
                                Earn free <c style="color:#4CAF50;">ROBUX</c>.
                            </h1>
                            <p class="lead">
                                By downloading apps, completing surveys, or watching videos.
                            </p>
                            <button onclick="goToEarn();" type="submit" style="width: 80%;" class="btn btn-warning"><a style="font-size: 15px;">START EARNING</a></button>

                        </div>

                         <div class="col-md-5" style="text-align:center">
                            <img style="width:100%;" alt="Image" src="assets/img/stickmasterluke.png">
                        </div>

                    </div>
                    <!--end of row-->
                </div>
                <!--end of container-->
            </section></div></div></div>
<section class="text-center" style="background-color: #fafafa;">
                <div class="container">
                <h3 style="color:#666666;">How does it work?</h3><br>
                    <div class="row">


                        <div class="col-md-4">
                            <div class="feature feature-3 boxed boxed--lg boxed--border"> <i style="color:#f6c344;" class="far fa-user fa-7x"></i>
                                <h4>Link Account</h4>
                                <p> Enter your ACCOUNT username to begin. You do not need to provide your password anywhere.</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="feature feature-3 boxed boxed--lg boxed--border"> <i style="color:#f6c344;" class="fas fa-coins fa-7x"></i>
                                <h4>Earn Points</h4>
                                <p>Download mobile phone apps, complete surveys, or watch videos to earn points on the website.</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="feature feature-3 boxed boxed--lg boxed--border"> <i style="color:#f6c344;" class="fa fa-gem fa-7x"></i>
                                <h4>Cash Out</h4>
                                <p>Exchange your points on the website for ROBUX. Simply join a group and press a button.</p>
                            </div>
                        </div>
                    </div></section>


<!-- <h3></h3>

<div style="height:200px;width:100%;"><br>
</div>-->
   
   
   
   
   
   
   
   
   <section class="text-center" style="padding-top: 50px;">
                <div class="container" style="margin-top:0px;margin-bottom:0px;">
     <div class="row justify-content-center">
                        <div class="col-md-10 col-lg-8">
                            <div class="boxed boxed--lg bg--dark subscribe-form-1" style="background:#f7f7f7;border:1px solid #d6d6d6;">
                                                            <h3 style="color:#212121;">100% Legitimate.</h3>
                                                            <p style="color:#666666;">Don't fall for anymore fake scam websites. With our platform, you can earn ROBUX completely legitimately, and receive it instantly.
                                                            Thousands of users have already been paid out. Earn ROBUX with us today, and purchase yourself a new outfit, gamepass, or whatever you want!</p>

</div>
</div></div></div></div>
</div></div>
</section>



<footer class="text-center-xs space--xs bg--dark ">
                <div class="container">
                    <div class="row">








                        <div class="col-md-6">
                        <!--
                            <ul class="list-inline">
                                <li>
                                    <a href="#">
                                        <span class="h6 type--uppercase">Button</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <span class="h6 type--uppercase">Button</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <span class="h6 type--uppercase">Button</span>
                                    </a>
                                </li>
                            </ul>
                            -->

                            <p>We are not affiliated with any of the games or companies shown on this website. Use of any logos or trademarks are for reference purposes only. By utilizing the website, you agree to be bound by the terms of service.
</p>
                        </div>





                        <div class="col-md-6 text-right text-center-xs">
                            <ul class="social-list list-inline list--hover">

                            <!--    <li>
                                    <a href="#">
                                        <i class="socicon socicon-twitter icon icon--xs"></i>
                                    </a>
                                </li>
-->
                            </ul>
                        </div>
                    </div>
                    <!--end of row-->
                    <div class="row">
                        <div class="col-md-2 col-sm-4">

                            <a class="type--fine-print" href="/legal">Terms &amp; Conditions</a>

                        </div>

                      <div class="col-md-2 col-sm-4">
                            <a class="type--fine-print" href="/sell/index">Panel</a>
                        </div>

                   <div class="col-md-8 col-sm-4 text-right text-center-xs">
 <span class="type--fine-print">RBXStorm
                                    <span class="update-year">2020</span></span>
                                       </div>


                    </div>
                </div></body>
                <!--end of container-->
            </footer>
        <!--End Footer-->
    </div></div>
    <!-- End Page -->
    <!-- Back-to-top --><a href="#top" id="back-to-top"><i class="fe fe-arrow-up"></i></a>
    <!-- Jquery js-->
    <script src="assets/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap js-->
    <script src="assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Ionicons js-->
    <!-- Rating js-->
    <!-- Chart.Bundle js-->
    <!-- Perfect-scrollbar js-->
    <script src="assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <!-- Dashboard js-->
    <script src="assets/js/index.js"></script>
    <!-- Custom js-->
    <script src="assets/js/custom.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
    <div class="main-navbar-backdrop" onclick="document.body.classList.remove('main-navbar-show');"></div>
	<script>
		function httpGet(theUrl) {
			var xmlHttp = new XMLHttpRequest();
			xmlHttp.open( "GET", theUrl, false );
			xmlHttp.send( null );
			return xmlHttp.responseText;
		}
	
		function loadinfo() {
			var info = JSON.parse(httpGet("api/stats.php"));
				
			document.getElementById('username').innerHTML = info.username;
			document.getElementById('robloxUserIMG').src = info.userImg;
			var name = document.getElementsByClassName("siteName");
			for(var i=0; i<name.length; i++) {
				name[i].innerHTML = info.siteName;
			}
			var roux = document.getElementsByClassName("siteOnline");
			for(var i=0; i<roux.length; i++) {	
				roux[i].innerHTML = info.online;
			}
			var usr = document.getElementsByClassName("siteTotalEarned");
			for(var i=0; i<usr.length; i++) {	
				usr[i].innerHTML = info.totalEarned;
			}
			
			document.getElementById('recentClaims').innerHTML = httpGet("api/a.php?getNewOne") + document.getElementById('recentClaims').innerHTML
		}
		
		loadinfo();
		document.getElementById('recentClaims').innerHTML = httpGet("api/recentearningstable.php");
		var intervalID = window.setInterval(loadinfo, 5000);
		
		function goToEarn() {
			var info = httpGet("api/a.php?isLoggedIn");
			if (info == "1") {
				window.location.href = "earn";
			} else {
				Swal.fire({
				  title: 'Submit your username',
				  input: 'text',
				  imageUrl: 'logo.png',
				  imageWidth: 400,
				  imageHeight: "auto",
				  inputAttributes: {
					autocapitalize: 'off'
				  },
				  showCancelButton: false,
				  confirmButtonText: 'Login',
				  showLoaderOnConfirm: true,
				  preConfirm: (login) => {
					console.log("api/a.php?login=${login}");
					return fetch(`api/a.php?login=${login}`)
					  .then(response => {
						if (!response.ok) {
						  throw new Error(response.statusText)
						}
						return response.json()
					  })
					  .catch(error => {
						Swal.showValidationMessage(
						  `Request failed: ${error}`
						)
					  })
				  },
				  allowOutsideClick: () => !Swal.isLoading()
				}).then((result) => {
				  if (result.value) {
					window.location.href = "earn";
				  }
				})
			}
		}
		$(document).ready(function(){
			if($("#wrapfabtest").height() > 0) {
				console.log('No AdBlock :)');
				
			} else {
			Swal.fire({title: 'You are using an adblocker!', text: "Please disable your adblocker to continue", type: 'warning', showCancelButton: false, confirmButtonClass: 'btn btn-success', confirmButtonText: 'My adblock was disabled: Click to Continue'}).then(function () { location.reload() });
				
			}
			if($("#wrapfabtest").width() > 0) {
				console.log('No AdBlock :)');
				
			} else {
			Swal.fire({title: 'You are using an adblocker!', text: "Please disable your adblocker to continue", type: 'warning', showCancelButton: false, confirmButtonClass: 'btn btn-success', confirmButtonText: 'My adblock was disabled: Click to Continue'}).then(function () { location.reload() });
				
			}
		});
	</script>
		<script async src="https://www.googletagmanager.com/gtag/js?id=UA-155017871-1"></script>
		  	<script src="https://kit.fontawesome.com/242685ebbc.js" crossorigin="anonymous"></script>
<script type="text/javascript">window.$crisp=[];window.CRISP_WEBSITE_ID="a07a442c-a0e4-4d76-8f46-b031e5b3793c";(function(){d=document;s=d.createElement("script");s.src="https://client.crisp.chat/l.js";s.async=1;d.getElementsByTagName("head")[0].appendChild(s);})();</script>
</body>

</html>