<?php
session_start();
include_once "assets/config.php";

$info = getuserinfo();
$result = ["success" => true, "code" => 0 , "message"];
$conn = $info["conn"];


if(isset($info["a"])) {

    if (isset($_GET["get"])) {
        $offers = [];

        array_push($offers, array("text" => "Join the DISCORD", "award" => 1, "redeemed" => ($_SESSION['u']['joined_discord']), "task" => "DISCORD", "progress" => ($_SESSION['u']['joined_discord'] * 100)));
        array_push($offers, array("text" => "Complete 1 Offer", "award" => 1, "redeemed" => ($_SESSION['u']['quests_1']), "task" => "1 offer", "progress" => ($_SESSION['u']['quests_offer_count'] * 100)));
        array_push($offers, array("text" => "Complete 3 Offers", "award" => 5, "redeemed" => ($_SESSION['u']['quests_3']), "task" => "3 offers", "progress" => ($_SESSION['u']['quests_offer_count'] / 3 * 100)));
        array_push($offers, array("text" => "Complete 5 Offers", "award" => 10, "redeemed" => ($_SESSION['u']['quests_5']), "task" => "5 offers", "progress" => ($_SESSION['u']['quests_offer_count'] / 5 * 100)));

        $result["message"] = $offers;
    }

    if (isset($_GET["task"])) {
        $task = htmlspecialchars(urldecode($_GET["task"]));
        $id = $_SESSION['u']['id'];

        switch (strtolower($task)) {
            case "discord":
                
                if ($_SESSION['u']['joined_discord'] == 0) {
                    $_SESSION['u']['joined_discord'] += 1;
                    $_SESSION['u']['balance'] += 1;
                    $bal = $_SESSION['u']['balance'];
                    $result = firedb($conn, "UPDATE `users` SET `joined_discord` = 1 WHERE `id` = $id", "UPDATE");
                    $result2 = firedb($conn, "UPDATE `users` SET `balance` = $bal WHERE `id` = $id", "UPDATE");
                    $result["message"] = "updated user with id $id";
                } else {
                    $result["success"] = false;
                    $result["code"] = 1;
                    $result["message"] = "user with id $id already in discord";
                }
                break;
            case "1 offer":
                if ($_SESSION['u']['quests_1'] == 0) {
                    $_SESSION['u']['quests_offer_count'] += 1;
                    $_SESSION['u']['balance'] += 1;
                    $bal = $_SESSION['u']['balance'];
                    $result = firedb($conn, "UPDATE `users` SET `quests_1` = 1 WHERE `id` = $id", "UPDATE");
                    $result2 = firedb($conn, "UPDATE `users` SET `balance` = $bal WHERE `id` = $id", "UPDATE");
                    $result["message"] = "updated user with id $id";
                } else {
                    $result["success"] = false;
                    $result["code"] = 1;
                    $result["message"] = "user with id $id already completed task";
                }
                break;
            case "3 offers":
                if ($_SESSION['u']['quests_3'] == 0) {
                    $_SESSION['u']['quests_offer_count'] += 1;
                    $_SESSION['u']['balance'] += 5;
                    $bal = $_SESSION['u']['balance'];
                    $result = firedb($conn, "UPDATE `users` SET `quests_3` = 1 WHERE `id` = $id", "UPDATE");
                    $result2 = firedb($conn, "UPDATE `users` SET `balance` = $bal WHERE `id` = $id", "UPDATE");
                    $result["message"] = "updated user with id $id";
                } else {
                    $result["success"] = false;
                    $result["code"] = 1;
                    $result["message"] = "user with id $id already completed task";
                }
                break;
            case "5 offers":
                if ($_SESSION['u']['quests_5'] == 0) {
                    $_SESSION['u']['quests_offer_count'] += 1;
                    $_SESSION['u']['balance'] += 10;
                    $bal = $_SESSION['u']['balance'];
                    $result = firedb($conn, "UPDATE `users` SET `quests_5` = 1 WHERE `id` = $id", "UPDATE");
                    $result2 = firedb($conn, "UPDATE `users` SET `balance` = $bal WHERE `id` = $id", "UPDATE");
                    $result["message"] = "updated user with id $id";
                } else {
                    $result["success"] = false;
                    $result["code"] = 1;
                    $result["message"] = "user with id $id already completed task";
                }
                break;
        }
    }
} else {
    $result["success"] = false;
    $result["code"] = 1;
    $result["response"] = "Not logged in";
}

echo(json_encode($result, JSON_PRETTY_PRINT));