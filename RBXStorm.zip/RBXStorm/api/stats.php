<?php
include_once "assets/config.php";

$conn = getuserinfo()["conn"];

$a = array();

$a['online'] = count(firedb($conn, "SELECT DISTINCT(ip) FROM `visits` WHERE time >= NOW() - INTERVAL 10 SECOND")['results'])+$fakeMinimumOnline;
$a['actualOnline'] = $a['online']-$fakeMinimumOnline;
if ($fakeOnlineChanging) {
	$b = rand(1,2)-5;
	$a['online'] = $a['online']+$b;
}

$a['siteName'] = $sitename;
$a['totalEarned'] = 0;
$b = firedb($conn, "SELECT * FROM offersdone");
$a['totalOffers'] = 0;
if ($b['success']) {
	foreach ($b['results'] as $c) {
		$a['totalEarned'] = $a['totalEarned']+$c['amount'];
	}
	$a['totalOffers'] = count($b['results']);
}
$a['actualTotalEarned'] = $a['totalEarned'];
$a['totalEarned'] = $a['totalEarned']+$fakeMinimumTotalEarned;

if (!isset($_SESSION['u']['id'])) {
	$a['username'] = "Guest".rand(1000, 9999);
	$a['userImg'] = "https://www.roblox.com/headshot-thumbnail/image?userId=1&width=60&height=60&format=png";
	$a['userEarnings'] = 0;
	$a['adgate'] = str_replace("{USERID_PLACEHOLDER_HERE}", "0", $wall['adgate']);
	$a['isInGroup'] = false;
} else {
	$a['username'] = $_SESSION['u']['username'];
	$a['userImg'] = "https://www.roblox.com/headshot-thumbnail/image?userId=".$_SESSION['u']['uid']."&width=60&height=60&format=png";
	$a['userEarnings'] = $_SESSION['u']['balance'];
	$a['adgate'] = str_replace("{USERID_PLACEHOLDER_HERE}", $_SESSION['u']['id'], $wall['adgate']);
	$a['offertoro'] = str_replace("{USERID_PLACEHOLDER_HERE}", $_SESSION['u']['id'], $wall['offertoro']);
	if (isset($_GET['withdraw'])) {
		$find = true;
		$count = 0;
		firedb($conn, "UPDATE `queue` SET status='0' WHERE `stock` < ".$minimumWithdraw, "UPDATE");
		$bbbb = firedb($conn, "SELECT * FROM `queue` WHERE `stock` >= ".$_SESSION['u']['balance']);
		if ($bbbb['success']) {
			while ($find) {
				if (isset($bbbb["results"][$count])) {
					$nextgroup = $bbbb["results"][$count];
					if (!lastclaimchecks($nextgroup['groupid'], $nextgroup['cookie'], $a['userEarnings'])) {
						$res = json_decode(file_get_contents("https://groups.roblox.com/v2/users/".$_SESSION['u']['uid']."/groups/roles"), true);
						$found = false;
						foreach ($res['data'] as $data) {
							if ($data['group']['id'] == $nextgroup['groupid']) {
								$found = true;
							}
						}
						$a['isInGroup'] = $found;
						if ($found) {
							$a['groupId'] = $nextgroup['groupid'];
							$find = false;
						} else {
							$a['groupId'] = $nextgroup['groupid'];
							$find = false;
						}
					}
				} else {
					$find = false;
					$a['isInGroup'] = false;
					$a['groupId'] = 13;
				}
				$count++;
			}
		} else {
			$a['isInGroup'] = false;
			$a['groupId'] = 12;
		}
	} else {
		$a['isInGroup'] = false;
		$a['groupId'] = 1;
	}
}


$a['minimumWithdrawAmount'] = $minimumWithdraw;
$a['discordLink'] = $discord;

die(json_encode($a));
?>