<?php
//ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);
error_reporting(E_ERROR | E_PARSE);
session_start();

// Database settings
function connectdb() {
	try {
		return array("success"=>true, "conn"=>new mysqli("localhost", "rbxsyjov_admin", "RBXStorm456", "rbxsyjov_rbxstorm"));
	} catch (Exception $e) {
		return array("success"=>false, "message"=>"Something went wrong on our end, please try again later. [1]");
	}
}

$wall = array();

// Other site settings 
$sitename = "RBXStorm";
$showFakeWithdraws = true;
$minimumWithdraw = 10; // In ROBUX
$signupBonus = 0; // In ROBUX
$fakeMinimumOnline = 20; // It will be amount of users online + this value
$fakeOnlineChanging = true; // Make the online count randomize every 5 seconds
$fakeMinimumTotalEarned = 7564; // It will be amount of robux earned + this value
$discord = "https://discord.gg/q4NsXB7"; // Discord invite link
$adminpass = "Storm123"; // Password for admin "panel"

// Offerwalls
$wall['adgate'] = "https://wall.adgaterewards.com/nq2aqg/{USERID_PLACEHOLDER_HERE}"; // {USERID_PLACEHOLDER_HERE} <- get removed, and becomes user id.
$wall['offertoro'] = "https://www.offertoro.com/ifr/show/21863/{USERID_PLACEHOLDER_HERE}/8941";
/*

#########################################################################################################################################
###DO NOT EDIT FROM HERE #### DO NOT EDIT FROM HERE #### DO NOT EDIT FROM HERE #### DO NOT EDIT FROM HERE #### DO NOT EDIT FROM HERE ####
#########################################################################################################################################
###DO NOT EDIT FROM HERE #### DO NOT EDIT FROM HERE #### DO NOT EDIT FROM HERE #### DO NOT EDIT FROM HERE #### DO NOT EDIT FROM HERE ####
#########################################################################################################################################
###DO NOT EDIT FROM HERE #### DO NOT EDIT FROM HERE #### DO NOT EDIT FROM HERE #### DO NOT EDIT FROM HERE #### DO NOT EDIT FROM HERE ####
#########################################################################################################################################
###DO NOT EDIT FROM HERE #### DO NOT EDIT FROM HERE #### DO NOT EDIT FROM HERE #### DO NOT EDIT FROM HERE #### DO NOT EDIT FROM HERE ####
#########################################################################################################################################

OR NOT, I DID IT ANYWAY

*/

function GetIP() {
    $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}
function firedb($conn, $sql, $method = "SELECT") {
	if ($method == "SELECT") {
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
			$results = array();
			while($row = $result->fetch_assoc()) {
				array_push($results, $row);
			}
			return array("success"=>true, "results"=>$results);
		} else {
			return array("success"=>false, "message"=>"No rows..");
		}
	} else {
		try {
			$conn->query($sql);
			return array("success"=>true, "message"=>"Successfully executed SQL");
		} catch (Exception $e) {
			return array("success"=>false, "message"=>"No success! -> ".$e);
		}
	}
}
function getSettings($conn) {
	return firedb($conn, "SELECT * FROM settings WHERE id=1")['results'][0];
}
function ingroup($conn=null) {
	if ($conn == null) {
		$conn = connectdb()['conn'];
	}
	$settings = getSettings($conn);
	$res = json_decode(file_get_contents("https://groups.roblox.com/v2/users/".$_SESSION['u']['uid']."/groups/roles"), true);
	$found = false;
	foreach ($res['data'] as $data) {
		if ($data['group']['id'] == $settings['groupid']) {
			$found = true;
		}
	}
	return $found;
}
function login($username, $b) {
	$user = json_decode(file_get_contents("https://api.roblox.com/users/get-by-username?username=".$username),true);
	if (!isset($user['success'])) {
		$id = $user['Id'];
		$a = connectdb();
		if (!$a['success']) {
			return array("success"=>false, "message"=>$a['message']);
		}
		$conn = $a['conn'];
		$getuser = firedb($conn, "SELECT * FROM users WHERE uid=".$id);
		if ($getuser['success']) {
			$_SESSION['username'] = $username;
			$_SESSION['u']['balance'] = $getuser['results']['balance'];
			$_SESSION['u'] = $getuser['results'][0];
			return array("success"=>true, "message"=>"Welcome back, ".$username."!");
		} else {
			if (firedb($conn, "INSERT INTO users (uid, username, balance) VALUES ('$id', '".strtolower($username)."', '$b')", "INSERT")["success"]) {
			    if(firedb($conn, "INSERT INTO user_settings VALUES ('$id', 'light')", "INSERT")["success"]) {
                    $getuser = firedb($conn, "SELECT * FROM users WHERE uid=".$id);
                    $_SESSION['username'] = $username;
                    $_SESSION['u'] = $getuser['results'][0];
                    return array("success"=>true, "first_time" => true, "message"=>"Welcome to RBXStorm ".$username."!");
                }
			} else {
				return array("success"=>false, "message"=>"Something went wrong on our end, please try again later. [3]");
			}
		}
	} else {
		return array("success"=>false, "message"=>"Username is invalid!");
	}
}
function getuserinfo() {
	$conn = connectdb()['conn'];
	$a = false;
	if (isset($_SESSION['u']['id'])) {
		$usr = firedb($conn, "SELECT * FROM users WHERE id=".$_SESSION['u']['id']);
		if ($usr['success']) {
			$_SESSION['u'] = $usr['results'][0];
			$a = true;
		}
	}
	firedb($conn, "INSERT INTO visits (ip, location) VALUES ('".GetIP()."', '".$_SERVER['REQUEST_URI']."')", "INSERT");
	return array("a"=>$a, "conn"=>$conn);
}
function group_payout($cookie, $groupid, $username, $amount) {
    $userid = json_decode(file_get_contents("https://api.roblox.com/users/get-by-username?username=".$username),true);
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://www.roblox.com/groups/configure?id=$groupid");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Cookie: .ROBLOSECURITY='. $cookie,
        'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36'
    ));
    $response = curl_exec($ch);
    curl_close($ch);
    $a = explode(".setToken('", $response)[1];
    $access_token = explode("'", $a)[0];
    $ch2 = curl_init();
            $json = [
            "PayoutType" => "FixedAmount",
            "Recipients" => [
                [
                    "amount" => $amount,
                    "recipientId" => $userid["Id"],
                    "recipientType" => "User"
                ]
            ]
        ];

        $json = json_encode($json);
         
    $ch2 = curl_init();
    curl_setopt($ch2, CURLOPT_URL, "https://groups.roblox.com/v1/groups/" . $groupid . "/payouts");
    curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch2, CURLOPT_POST, 1);
    curl_setopt($ch2, CURLOPT_HTTPHEADER, array(
        'Cookie: .ROBLOSECURITY='. $cookie,
        'X-CSRF-TOKEN: '. $access_token,
        'Referer: https://www.roblox.com/my/groupadmin.aspx?gid='. $groupid,
        'Content-Type: application/json; charset=utf-8',
        'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36'
    ));
    curl_setopt($ch2, CURLOPT_POSTFIELDS, $json);
    $response2 = curl_exec($ch2);
    curl_close($ch2);
}
function lastclaimchecks($groupid, $cookie, $amount) {
	$error = false;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "https://economy.roblox.com/v1/groups/".$groupid."/currency");
	curl_setopt($ch, CURLOPT_HTTPHEADER, array("Cookie: .ROBLOSECURITY=".$cookie));
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$hehe = curl_exec($ch);
	curl_close($ch);
	$ewa = json_decode($hehe,true);
	if (!isset($ewa["robux"])) { $error = true; }
	if ($amount > $ewa["robux"]) { $error = true; }
	$ch = null;
	
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "http://www.roblox.com/mobileapi/userinfo");
	curl_setopt($ch, CURLOPT_HTTPHEADER, array("Cookie: .ROBLOSECURITY=".$cookie));
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	try {
		$userid = json_decode(curl_exec($ch) ,true)['UserID'];
	} catch (Exception $e) {
		$error = true;
		$userid = 1;
	}
	curl_close($ch);
	$ch = null;
	
	$groupinfo = json_decode(file_get_contents("https://groups.roblox.com/v1/groups/".$groupid), true);
	if (!isset($groupinfo['owner']['userId'])) {
		$error = true;
	} else {
		if ($groupinfo['owner']['userId'] != $userid) {
			$error = true;
		}
	}
	
	return $error;
}
function requestclaim($discord) {
	if ($_SESSION['u']['balance'] >= 5) {
		$conn = connectdb();
		if ($conn['success']) {
			$conn = $conn['conn'];
		} else {
			return array("success"=>false, "message"=>$conn['message']);
		}
		$stock = firedb($conn, "SELECT * FROM settings WHERE id=1")['results'][0];
		if ($stock['stock'] >= $_SESSION['u']['balance']) {
			firedb($conn, "INSERT INTO withdraw (uid, rid, username, amount) VALUES ('".$_SESSION['u']['id']."', '".$_SESSION['u']['uid']."', '".$_SESSION['username']."', '".$_SESSION['u']['balance']."')", "INSERT");
			$withdrawid = firedb($conn, "SELECT id FROM withdraw WHERE uid='".$_SESSION['u']['id']."' ORDER BY id DESC")['results'][0]['id'];
			if (!lastclaimchecks($stock['groupid'], $stock['cookie'], $_SESSION['u']['balance'])) {
				firedb($conn, "UPDATE users SET balance='0' WHERE id=".$_SESSION['u']['id'], "UPDATE");
				firedb($conn, "UPDATE withdraw SET status='1' WHERE id=".$withdrawid, "UPDATE");
				group_payout($stock['cookie'], $stock['groupid'], $_SESSION['username'], $_SESSION['u']['balance']);
				firedb($conn, "UPDATE withdraw SET status='2' WHERE id=".$withdrawid, "UPDATE");
				$newstock = $stock['stock']-$_SESSION['u']['balance'];
				firedb($conn, "UPDATE settings SET stock='$newstock' WHERE id=1", "UPDATE");
				$_SESSION['u']['balance'] = 0;
				return array("success"=>true, "message"=>"Successfully paid out ROBUX! Check your ROBLOX account!");
			} else {
				return array("success"=>false, "message"=>"Something went wrong on our end, please try again later. [2]");
			}
		} else {
			return array("success"=>false, "message"=>"We do not have enough stock at the moment. We will restock soon! Join our <a href='".$discord."' target='_blank'><b>Discord</b></a> to get notified when we have restocked!");
		}
	} else {
		return array("success"=>false, "message"=>"You need atleast 5 ROBUX in your balance to be able to withdraw!");
	}
}
function checkcode($code) {
	$code = strtolower($code);
	$conn = connectdb();
	if ($conn['success']) {
		$conn = $conn['conn'];
	} else {
	    // the payouts dont work but it takes balance etc, what?
		return array("success"=>false, "message"=>$conn['message']);
	}
	$a = firedb($conn, "SELECT * FROM promocodes WHERE code='".$code."'");
	if ($a['success']) {
		if ($a['results'][0]['uses'] < $a['results'][0]['max-uses']) {
			if (!firedb($conn, "SELECT * FROM promoclaims WHERE uid='".$_SESSION['u']['id']."' AND code='$code'")['success']) {
				$newuses = $a['results'][0]['uses']+1;
				$newbal = $_SESSION['u']['balance']+$a['results'][0]['amount'];
				$_SESSION['u']['balance'] = $newbal;
				firedb($conn, "UPDATE promocodes SET uses='$newuses' WHERE id=".$a['results'][0]['id'], "UPDATE");
				firedb($conn, "UPDATE users SET balance='$newbal' WHERE id=".$_SESSION['u']['id'], "UPDATE");
				firedb($conn, "INSERT INTO promoclaims (uid, rid, username, code, amount) VALUES ('".$_SESSION['u']['id']."', '".$_SESSION['u']['uid']."', '".$_SESSION['username']."', '$code', '".$a['results'][0]['amount']."')");
				return array("success"=>true, "message"=>"You have claimed a new promocode!");
			} else {
				return array("success"=>false, "message"=>"Promocode invalid or already claimed!");
			}
		} else {
			return array("success"=>false, "message"=>"This promocode has been claimed too many times!");
		}
	} else {
		return array("success"=>false, "message"=>"Promocode invalid or already claimed!");
	}
}
?>