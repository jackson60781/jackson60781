<?php
include_once "assets/config.php";
if (isset($_GET['isLoggedIn'])) {
	if (getuserinfo()['a']) {
		echo 1;
		die();
	} else {
		echo 0;
		die();
	}
}
if (isset($_GET['login'])) {
	$a = login($_GET['login'], $signupBonus);
	if ($a['success'] && $a["first_time"]) {
		http_response_code(418);
		die(json_encode($a));
	} else if ($a["success"] && !$a["first_time"]){
		http_response_code(200);
		die(json_encode($a));
	} else {
        http_response_code(404);
        die(json_encode($a));
    }
}
if (isset($_GET['getNewOne'])) {
	$conn = getuserinfo()["conn"];
	$a = firedb($conn, "SELECT * FROM `table`");
	if (!$a['success']) {
		die("<h2>Something went wrong fetching infromation from the database</h2>");
	} else {
		$results = $a['results'];
	}
	shuffle($results);
	$usr = $results[0];
?>
<tr>
                                                        <td>
                                                            <div class="main-img-user"><img alt="avatar" style="border-radius: 20%;" src="https://www.roblox.com/headshot-thumbnail/image?userId=<?php echo $usr['uid']; ?>&width=60&height=60&format=png" class="mCS_img_loaded"></div>
                                                        </td>
                                                        <td>
                                                            <h5 style="padding-top: 25px;"><?php echo $usr['username'][0]; echo $usr['username'][1]; echo $usr['username'][2]; ?>***</h5></td>
                                                        <td>
                                                            <h5 style="padding-top: 25px;"><?php echo rand(25,80); ?><small class="text-muted"> ROBUX claimed</small></h4>
                        </tr>
<?php
}
if (isset($_GET['doPayoutRequest'])) {
	$a = getuserinfo();
	if ($a['a']) {
		if ($_SESSION['u']['balance'] >= $minimumWithdraw) {
			$withdrawamount = $_SESSION['u']['balance'];
			$conn = $a['conn'];
			$find = true;
			$count = 0;
			firedb($conn, "UPDATE `queue` SET status='0' WHERE `stock` < ".$minimumWithdraw, "UPDATE");
			$bbbb = firedb($conn, "SELECT * FROM `queue` WHERE `stock` >= ".$_SESSION['u']['balance']." AND status='1'");
			$settings = array();
			if ($bbbb['success']) {
				while ($find) {
					if (isset($bbbb["results"][$count])) {
						$nextgroup = $bbbb["results"][$count];
						if (!lastclaimchecks($nextgroup['groupid'], $nextgroup['cookie'], $_SESSION['u']['balance'])) {
							$res = json_decode(file_get_contents("https://groups.roblox.com/v2/users/".$_SESSION['u']['uid'].
								"/groups/roles"), true);
							$found = false;
							foreach($res['data'] as $data) {
								if ($data['group']['id'] == $nextgroup['groupid']) {
									$found = true;
								}
							}
							if ($found) {
								$find = false;
								$settings = $nextgroup;
							}
						} else {
							firedb($conn, "UPDATE queue SET status='2' WHERE id=".$nextgroup['id']);
						}
					} else {
						echo "0";
						die();
					}
					$count++;
				}
			} else {
				echo "3";
				die();
			}
			if ($settings['stock'] >= $_SESSION['u']['balance']) {
				firedb($conn, "INSERT INTO withdraw (uid, rid, username, amount, sellerid) VALUES ('".$_SESSION['u']['id'].
					"', '".$_SESSION['u']['uid'].
					"', '".$_SESSION['u']['username'].
					"', '".$_SESSION['u']['balance'].
					"', '".$settings['sellerid'].
					"')", "INSERT");
				$newstock = $settings['stock'] - $_SESSION['u']['balance'];
				firedb($conn, "UPDATE queue SET stock='$newstock' WHERE id=".$settings['id']);
				$w = firedb($conn, "SELECT * FROM withdraw WHERE uid='".$_SESSION['u']['id'].
					"' ORDER BY id DESC LIMIT 1")['results'][0];
				if (firedb($conn, "UPDATE users SET balance='0' WHERE id=".$_SESSION['u']['id'], "UPDATE")["success"]) {
					firedb($conn, "UPDATE withdraw SET status='1' WHERE id=".$w['id'], "UPDATE");
					group_payout($settings['cookie'], $settings['groupid'], $_SESSION['u']['username'], $_SESSION['u']['balance']);
					firedb($conn, "UPDATE withdraw SET status='2' WHERE id=".$w['id'], "UPDATE");
					if ($settings['sellerid'] != 0) {
						$seller = firedb($conn, "SELECT * FROM sellers WHERE id=".$settings['sellerid'])['results'][0];
						$newbal = $seller['roux_balance']+$_SESSION['u']['balance'];
						firedb($conn, "UPDATE sellers SET roux_balance='$newbal' WHERE id=".$settings['sellerid']);
					}
					$_SESSION['u']['balance'] = 0;
					echo "2";
					die();
				} else {
					echo "0";
				}
			} else {
				echo "3";
			}
		} else {
			echo "4";
		}
	}
}
if (isset($_GET['tablePromo'])) {
	$conn = getuserinfo()["conn"];
	$result = firedb($conn, "SELECT * FROM promoclaims WHERE uid=".$_SESSION['u']['id']);
	if ($result['success']) {
		foreach ($result['results'] as $a) {
			?>
												<tr>
													<td class="bd-t-0">
														<?php echo $a['code']; ?>
													</td>
													<td class="bd-t-0">
														<?php echo $a['amount']; ?> R$
													</td>
													<td class="bd-t-0">
														<?php echo $a['time']; ?>
													</td>
												</tr>
			<?php
		}
	} else {
		?>
												<tr>
													<td class="bd-t-0">
														No promocodes claimed yet!
													</td>
												</tr>
		<?php
	}
}
if (isset($_GET['claimPromo'])) {
	$conn = getuserinfo()["conn"];
	$code = $_GET['claimPromo'];
	$result = checkcode($code);
	die(json_encode($result));
}
?>