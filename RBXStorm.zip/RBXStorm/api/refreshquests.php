<?php
session_start();
include_once "assets/config.php";

$info = getuserinfo();
$conn = $info["conn"];

// Terrible loop method but oh well
$sqlRes = firedb($conn, "UPDATE `users` SET quests_offer_count='0', quests_1='0', quests_3='0', quests_5='0' WHERE id > ''");

var_dump($sqlRes);

$url = "https://discordapp.com/api/webhooks/680463293197844481/q4pDDhR9LCld_8gGq7-I5WpNSw9ZJWTHN5w7VFaKqCc8gFYSKaXPhWph6ysrlEO9xcHL";

$hookObject = json_encode([
    /*
     * The general "message" shown above your embeds
     */
    /*
     * The username shown in the message
     */
    "username" => "RBXStorm",
    /*
     * The image location for the senders image
     */
    "avatar_url" => "https://rbxstorm.com/favicon.ico",
    /*
     * Whether or not to read the message in Text-to-speech
     */
    "tts" => false,
    /*
     * File contents to send to upload a file
     */
    // "file" => "",
    /*
     * An array of Embeds
     */
    "embeds" => [
        /*
         * Our first embed
         */
        [
            // Set the title for your embed
            "title" => "⚔ ️Daily Quest Reset",

            // The type of your embed, will ALWAYS be "rich"
            "type" => "rich",

            // A description for your embed
            "description" => "Quests have been restarted", 
            // The URL of where your title will be a link to
            "url" => "https://rbxstorm.com/",

            // The integer color to be used on the left side of the embed
            "color" => hexdec( "ffcd19" ),
        ]
    ]

], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );

$ch = curl_init();

curl_setopt_array( $ch, [
    CURLOPT_URL => $url,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $hookObject,
    CURLOPT_HTTPHEADER => [
        "Content-Type: application/json"
    ]
]);

$response = curl_exec( $ch );
curl_close( $ch );

?>