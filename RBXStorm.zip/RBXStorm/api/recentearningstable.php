<?php
include_once "assets/config.php";
$conn = connectdb();
if (!$conn['success']) {
	die("<h2>Something went wrong connection to the database</h2>");
} else {
	$conn = $conn['conn'];
}
if ($showFakeWithdraws) {
	$a = firedb($conn, "SELECT * FROM users");
	if (!$a['success']) {
		die("<h2>Something went wrong fetching infromation from the database</h2>");
	} else {
		$results = $a['results'];
	}
	shuffle($results);
	$withdraws = array();
	$max = 4;
	$c = 0;
	foreach ($results as $result) {
		$c++;
		if ($c < $max) {
			array_push($withdraws, array("rid"=>$result['uid'], "username"=>$result['username'], "earnings"=>rand(25,150)));
		}
	}
	shuffle($withdraws);
} else {
	$a = firedb($conn, "SELECT * FROM withdraw ORDER BY id DESC LIMIT 6");
	$withdraws = array();
	foreach ($a['results'] as $result) {
		array_push($withdraws, array("rid"=>$result['rid'], "username"=>$result['username'], "earnings"=>$result['amount']));
	}
}
foreach ($withdraws as $w) {
?>
                                                 
                                                        
                                                        
                                                        <td>
                                                            <div class="main-img-user"><img alt="avatar" style="border-radius: 20%;" src="https://www.roblox.com/headshot-thumbnail/image?userId=<?php echo $w['rid']; ?>&width=60&height=60&format=png" class="mCS_img_loaded"></div>
                                                        </td>
                                                        
                                                        <td>
                                                            <h5 style="padding-top: 25px;"><?php echo $w['username'][0]; echo $w['username'][1]; echo $w['username'][2]; ?>****</div>
                                                        </td>
                                                        
                                                        <td>
                                                            <h5 style="padding-top: 25px;"><?php echo $w['earnings']; ?><small class="text-muted"> ROBUX claimed</small></h4> 
                                                        </td>
                                                        
                                                        
                                                    </tr>
<?php
}
?>