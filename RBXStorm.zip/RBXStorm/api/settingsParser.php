<?php
session_start();
include_once "assets/config.php";

$info = getuserinfo();
$result = ["success" => true, "code" => 0 , "message"];
$conn = $info["conn"];

if(isset($info["a"])) {
    $id = $info["a"]["id"];
    $themeQuery = firedb($conn, "SELECT * FROM users WHERE id = " . $id);

    var_dump($themeQuery);
}