<html lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    <style data-styles="">
        ion-icon {
            visibility: hidden
        }
        
        .hydrated {
            visibility: inherit
        }
    </style>
    <!-- Global site tag (gtag.js) - Google Analytics -->
<meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Favicon -->
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <!-- Title -->
    
    <title>RBXStorm | Earn FREE ROBUX!</title>
    <!---Fontawesome css-->
    <link href="Proxima-Nova-Bold.otf" rel="stylesheet">
    <link href="assets/plugins/fontawesome-free/css/all.min.css" rel="stylesheet">
    <!---Ionicons css-->
    <link href="/assets/css/iconsmind.css" rel="stylesheet" type="text/css" media="all">
    <!---Feather css-->
    <link href="assets/plugins/feather/feather.css" rel="stylesheet">
    <!---Falg-icons css-->
    <link href="assets/plugins/flag-icon-css/css/flag-icon.min.css" rel="stylesheet">
    <link href="assets/css/flickity.css" rel="stylesheet">
    <link href="/assets/css/theme.css" rel="stylesheet" type="text/css" media="all">    <!---Style css-->
    <link href="assets/css/custom-style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,400i,700%7CRubik:300,400,500" rel="stylesheet">
    <link href="assets/css/font-rubiklato.css" rel="stylesheet" type="text/css" media="all">
    <!---Select2 css-->
    <link href="assets/plugins/select2/css/select2.min.css" rel="stylesheet">
    <!--Mutipleselect css-->
    <link rel="stylesheet" href="assets/plugins/multipleselect/multiple-select.css">
    <!---Jquery.mCustomScrollbar css-->
    <link href="assets/plugins/jquery.mCustomScrollbar/jquery.mCustomScrollbar.css" rel="stylesheet">
    <!---Sidebar css-->
    <link href="assets/plugins/sidebar/sidebar.css" rel="stylesheet">
    <!-- Switcher css -->
    <link href="assets/switcher/css/switcher.css" rel="stylesheet">
    <link href="assets/switcher/demo.css" rel="stylesheet">
    <meta http-equiv="imagetoolbar" content="no">
    <style type="text/css">
        /* Chart.js */
        
        @-webkit-keyframes chartjs-render-animation {
            from {
                opacity: 0.99
            }
            to {
                opacity: 1
            }
        }
        
        @keyframes chartjs-render-animation {
            from {
                opacity: 0.99
            }
            to {
                opacity: 1
            }
        }
        
        .chartjs-render-monitor {
            -webkit-animation: chartjs-render-animation 0.001s;
            animation: chartjs-render-animation 0.001s;
        }
    </style>
	<style>
	.adBanner {
		background-color: transparent;
		height: 1px;
		width: 1px;
	}
	* {
        margin: 0;
}
html, body {
        height: 100%;
}
.wrapper {
        min-height: 100%;
        margin: 0 auto -155px; /* the bottom margin is the negative value of the footer's height */
}
	</style>
</head>

<body>
    <!-- End Switcher -->
    <!-- Loader -->
    <div id="global-loader" style="display: none;"> <img src="assets/img/loader.svg" class="loader-img" alt="Loader"> </div>
    <!-- End Loader -->
    <!-- Page -->
    <div class="page">
        <!-- Main Header-->
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #23262A;">
<div class="container-fluid">
<a class="navbar-brand" href="https://rbxstorm.com"><img src="assets/img/logonav.png" style="width: 200px;"></a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample09" aria-controls="navbarsExample09" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarsExample09">
<ul class="navbar-nav mr-auto" style="font-size: 15px;">
<a style="text-decoration: none;" href="https://rbxstorm.com/">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-home" style="margin-right: 6px;" aria-hidden="true"></i> Home</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/earn">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-money-bill-alt" style="margin-right: 6px;" aria-hidden="true"></i> Earn</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/claim">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-hand-holding-usd" style="margin-right: 6px;" aria-hidden="true"></i> Withdraw</span>
</li>
</a>
<a style="text-decoration: none;" href="https://discord.gg/q4NsXB7">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-gift" style="margin-right: 6px;" aria-hidden="true"></i> Giveaways</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/promo">
<li class="nav-item">
<span class="nav-link"><i class="fas fa-shopping-cart" style="margin-right: 6px;" aria-hidden="true"></i> Promo Codes</span>
</li>
</a>
<a style="text-decoration: none;" href="https://rbxstorm.com/legal">
<li class="nav-item active">
<span class="nav-link"><i class="fas fa-gavel" style="margin-right: 6px;" aria-hidden="true"></i> Legal</span>
</li>
</a>

</ul>
<ul class="navbar-nav">
<li class="nav-item">
<button onclick="window.location='https://rbxstorm.com/logout.php';" class="btn btn-warning"><a style="font-size: 15px;padding: 10px;">LOGOUT<i class="fe fe-power" style="color: black; padding-left:7px;"></i></a></button>

</li>
</ul>
</div>
</div>
</nav>
    
    <script> 
        function Open() { 
            window.open("https://rbxstorm.com", "_blank"); 
        } 
    </script> 
    
    
    <div id="header">
	<br>
	<div class="container space-top-1">
	    	<div class="feature feature--featured feature-3 boxed boxed--border bg--white">


		<div class="d-sm-block d-md-flex justify-content-between align-items-center">

</div>

	<div class="container space-1">
		<br>
		<h3>End&shy;User License Agreement ("Agreement")</h3>
		<h4>Last updated: (19-12-2019)</h4>
		<br>
		
		<p>Please read this User License Agreement ("Agreement") carefully before downloading or using rbxstorm ("Service").</p>

		<p>By downloading or using the Service, you are agreeing to be bound by the terms and conditions of this Agreement.</p>

		<p>If you do not agree to the terms of this Agreement, do not download or use the Service.</p>

		<h3>License</h3>
		<p>rbxstorm grants you a revocable, non&shy;exclusive, non&shy;transferable, limited license to download, install and use the Service solely for your personal, non&shy;commercial purposes strictly in accordance with the terms of this Agreement.</p>

		<h3>Restrictions</h3>
		<p>You agree not to, and you will not permit others to:
			license, sell, rent, lease, assign, distribute, transmit, host, outsource, disclose or otherwise commercially exploit the Service or make the Service available to any third party.</p>

		<p>Any further restrictions or specifications will be according to the Terms &amp; Conditions of rbxstorm, available at: <a href="https://rbxstorm/terms.php">https://rbxstorm/terms</a></p>

		<h3>Modifications to Service</h3>
		<p>rbxstorm reserves the right to modify, suspend or discontinue, temporarily or permanently, the Service or any service to which it connects, with or without notice and without liability to you.</p>

		<h3>Term and Termination</h3>
		<p>This Agreement shall remain in effect until terminated by you or rbxstorm. rbxstorm may, in its sole discretion, at any time and for any or no reason, suspend or terminate this Agreement with or without prior notice.</p>

		<p>This Agreement will terminate immediately, without prior notice from rbxstorm, in the event that you fail to comply with any provision of this Agreement. You may also terminate this Agreement by deleting the Service and all copies thereof from your mobile device or from your desktop.</p>

		<p>Upon termination of this Agreement, you shall cease all use of the Service and delete all copies of the Service from your mobile device or from your desktop.</p>

		<h3>Privacy</h3>
		<p>In accordance to the privacy policy of rbxstorm, available at: <a href="https://rbxstorm.com/privacy-policy.php">https://rbxstorm.com/privacy-policy.php</a></p>

		<h3>Severability</h3>
		<p>If any provision of this Agreement is held to be unenforceable or invalid, such provision will be changed and interpreted to accomplish the objectives of such provision to the greatest extent possible under applicable law and the remaining provisions will continue in full force and effect.</p>

		<h3>Amendments to this Agreement</h3>
		<p>rbxstorm reserves the right, at its sole discretion, to modify or replace this Agreement at any time. If a revision is material we will provide at least 30 days' notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion.</p>

		<h3>Contact Information</h3>
		<p>If you have any questions about this Agreement, please contact us at: <a href="mailto:support@rbxstorm.com">support@rbxstorm.com</a></p>

	</div>
	</div>
	
	
	 <!-- End Page -->
    <!-- Back-to-top --><a href="#top" id="back-to-top"><i class="fe fe-arrow-up"></i></a>
    <!-- Jquery js-->
    <script src="assets/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap js-->
    <script src="assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Ionicons js-->
    <script src="assets/plugins/ionicons/ionicons.js"></script>
    <!-- Rating js-->
    <script src="assets/plugins/rating/jquery.rating-stars.js"></script>
    <!-- Chart.Bundle js-->
    <script src="assets/plugins/chart.js/Chart.bundle.min.js"></script>
    <!-- Apexcharts js-->
    <script src="assets/plugins/apexcharts/apexcharts.js"></script>
    <script src="assets/plugins/apexcharts/irregular-data-series.js"></script>
    <!-- Peity js-->
    <script src="assets/plugins/peity/jquery.peity.min.js"></script>
    <!-- Flot Chart js-->
    <script src="assets/plugins/jquery.flot/jquery.flot.js"></script>
    <script src="assets/plugins/jquery.flot/jquery.flot.pie.js"></script>
    <script src="assets/plugins/jquery.flot/jquery.flot.resize.js"></script>
    <!-- Jquery-Ui js-->
    <script src="assets/plugins/jquery-ui/ui/widgets/datepicker.js"></script>
    <!-- Select2 js-->
    <script src="assets/plugins/select2/js/select2.min.js"></script>
    <!--MutipleSelect js-->
    <script src="assets/plugins/multipleselect/multiple-select.js"></script>
    <script src="assets/plugins/multipleselect/multi-select.js"></script>
    <!-- Sidebar js-->
    <script src="assets/plugins/sidebar/sidebar.js"></script>
    <!-- Jquery.mCustomScrollbar js-->
    <script src="assets/plugins/jquery.mCustomScrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <!-- Perfect-scrollbar js-->
    <script src="assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <!-- Switcher js -->
    <script src="assets/switcher/js/switcher.js"></script>
    <!-- Sticky js-->
    <script src="assets/js/sticky.js"></script>
    <!-- Dashboard js-->
    <script src="assets/js/index.js"></script>
    <!-- Custom js-->
    <script src="assets/js/custom.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
    <svg id="SvgjsSvg1001" width="2" height="0" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" style="overflow: hidden; top: -100%; left: -100%; position: absolute; opacity: 0;">
        <defs id="SvgjsDefs1002"></defs>
        <polyline id="SvgjsPolyline1003" points="0,0"></polyline>
        <path id="SvgjsPath1004" d="M0 0 "></path>
    </svg>
    <div id="ui-datepicker-div" class="ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all"></div>
    <div class="main-navbar-backdrop"></div>
	<script>
		function httpGet(theUrl) {
			var xmlHttp = new XMLHttpRequest();
			xmlHttp.open( "GET", theUrl, false );
			xmlHttp.send( null );
			return xmlHttp.responseText;
		}
	
		function loadinfo() {
			var info = JSON.parse(httpGet("api/stats.php"));
				
			document.getElementById('username').innerHTML = info.username;
			document.getElementById('robloxUserIMG').src = info.userImg;
			var name = document.getElementsByClassName("siteName");
			for(var i=0; i<name.length; i++) {
				name[i].innerHTML = info.siteName;
			}
			var roux = document.getElementsByClassName("siteOnline");
			for(var i=0; i<roux.length; i++) {	
				roux[i].innerHTML = info.online;
			}
			var usr = document.getElementsByClassName("siteTotalEarned");
			for(var i=0; i<usr.length; i++) {	
				usr[i].innerHTML = info.totalEarned;
			}
			
			document.title = info.siteName+" | FREE ROBUX!";
			document.getElementById('recentClaims').innerHTML = httpGet("api/a.php?getNewOne") + document.getElementById('recentClaims').innerHTML
		}
		
		loadinfo();
		document.getElementById('recentClaims').innerHTML = httpGet("api/recentearningstable.php");
		var intervalID = window.setInterval(loadinfo, 5000);
		
		function goToEarn() {
			var info = httpGet("api/a.php?isLoggedIn");
			if (info == "1") {
				window.location.href = "earn";
			} else {
				Swal.fire({
				  title: 'Submit your ROBLOX username',
				  input: 'text',
				  imageUrl: 'logo.png',
				  imageWidth: 400,
				  imageHeight: "auto",
				  inputAttributes: {
					autocapitalize: 'off'
				  },
				  showCancelButton: false,
				  confirmButtonText: 'Login',
				  showLoaderOnConfirm: true,
				  preConfirm: (login) => {
					console.log("api/a.php?login=${login}");
					return fetch(`api/a.php?login=${login}`)
					  .then(response => {
						if (!response.ok) {
						  throw new Error(response.statusText)
						}
						return response.json()
					  })
					  .catch(error => {
						Swal.showValidationMessage(
						  `Request failed: ${error}`
						)
					  })
				  },
				  allowOutsideClick: () => !Swal.isLoading()
				}).then((result) => {
				  if (result.value) {
					window.location.href = "earn";
				  }
				})
			}
		}
		$(document).ready(function(){
			if($("#wrapfabtest").height() > 0) {
				console.log('No AdBlock :)');
				
			} else {
			Swal.fire({title: 'You are using an adblocker!', text: "Please disable your adblocker to continue", type: 'warning', showCancelButton: false, confirmButtonClass: 'btn btn-success', confirmButtonText: 'My adblock was disabled: Click to Continue'}).then(function () { location.reload() });
				
			}
			if($("#wrapfabtest").width() > 0) {
				console.log('No AdBlock :)');
				
			} else {
			Swal.fire({title: 'You are using an adblocker!', text: "Please disable your adblocker to continue", type: 'warning', showCancelButton: false, confirmButtonClass: 'btn btn-success', confirmButtonText: 'My adblock was disabled: Click to Continue'}).then(function () { location.reload() });
				
			}
		});
	</script>
</body>

</html>